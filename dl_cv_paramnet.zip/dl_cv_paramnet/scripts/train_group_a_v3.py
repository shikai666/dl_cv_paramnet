"""
A组实验（v3）：支持无重建损失（cont_only）

这版在 v2 基础上新增：
- cont_only: 仅保留对比损失，不使用重建损失

并修正 checkpoint 选择逻辑：
- rec_only: 按验证重建误差最小保存 best
- cont_only: 按验证对比损失最小保存 best
- full_ssl / full_ssl_tuned: 按加权验证总分最小保存 best

说明：
- 这里的“对比损失验证”通过在验证集上构造两路增强视图来计算。
- 这样才能公平地比较 cont_only，不会出现“训练时没有重建损失，但保存 best 却按重建误差”的问题。
"""

import os
import sys
import time
import json
import argparse
from datetime import datetime
from typing import Dict, Optional, List, Tuple

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from src.config import get_config, save_config, load_config, Config
from src.models import create_model
from src.losses import NTXentLoss, ReconstructionLoss
from src.data import create_dataloaders, QinBambooSlipDataset, SyntheticDataset
from src.metrics import MetricsCalculator, evaluate_model


VALID_MODES = {"rec_only", "cont_only", "full_ssl", "full_ssl_tuned"}


class GroupATrainer:
    def __init__(
        self,
        config: Config,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        val_pair_loader: DataLoader,
        device: str = "cuda",
        mode: str = "rec_only",
        lambda_cont_override: Optional[float] = None,
        lambda_rec_override: Optional[float] = None,
        cont_final_scale: float = 1.0,
        cont_warmup_epochs: int = 0,
        reconstruct_each_view: bool = True,
    ):
        assert mode in VALID_MODES
        self.config = config
        self.mode = mode
        self.device = torch.device(device)
        self.model = model.to(self.device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.val_pair_loader = val_pair_loader
        self.reconstruct_each_view = reconstruct_each_view

        base_lambda_cont = float(config.training.lambda_cont)
        base_lambda_rec = float(config.training.lambda_rec)
        self.base_lambda_cont = float(lambda_cont_override) if lambda_cont_override is not None else base_lambda_cont
        self.base_lambda_rec = float(lambda_rec_override) if lambda_rec_override is not None else base_lambda_rec
        self.cont_final_scale = float(cont_final_scale)
        self.cont_warmup_epochs = int(max(0, cont_warmup_epochs))

        self.cont_criterion = NTXentLoss(
            temperature=config.training.temperature,
        ).to(self.device)

        self.rec_criterion = ReconstructionLoss(
            gamma=config.training.gamma,
            sobel_threshold=config.eval.sobel_threshold,
        ).to(self.device)

        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        self.metrics = MetricsCalculator(sobel_threshold=config.eval.sobel_threshold)

        log_dir = os.path.join(
            config.log_dir,
            config.experiment_name,
            datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        self.writer = SummaryWriter(log_dir)

        self.checkpoint_dir = os.path.join(
            config.training.checkpoint_dir,
            config.experiment_name,
        )
        os.makedirs(self.checkpoint_dir, exist_ok=True)

        self.current_epoch = 0
        self.best_score = float("inf")
        self.early_stop_counter = 0

    def _create_optimizer(self) -> optim.Optimizer:
        if self.config.training.optimizer == "adam":
            return optim.Adam(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        if self.config.training.optimizer == "adamw":
            return optim.AdamW(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        if self.config.training.optimizer == "sgd":
            return optim.SGD(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                momentum=0.9,
                weight_decay=self.config.training.weight_decay,
            )
        raise ValueError(f"不支持的优化器: {self.config.training.optimizer}")

    def _create_scheduler(self) -> Optional[optim.lr_scheduler._LRScheduler]:
        if self.config.training.scheduler == "cosine":
            return optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.config.training.num_epochs,
                eta_min=self.config.training.learning_rate * 0.01,
            )
        if self.config.training.scheduler == "step":
            return optim.lr_scheduler.StepLR(self.optimizer, step_size=30, gamma=0.1)
        return None

    def _current_lambda_cont(self) -> float:
        if self.mode == "rec_only":
            return 0.0
        target = self.base_lambda_cont
        if self.mode == "full_ssl_tuned":
            target = self.base_lambda_cont * self.cont_final_scale
        if self.cont_warmup_epochs <= 0:
            return target
        progress = min(1.0, max(0.0, (self.current_epoch + 1) / float(self.cont_warmup_epochs)))
        return target * (progress ** 2)

    def _current_lambda_rec(self) -> float:
        if self.mode == "cont_only":
            return 0.0
        return self.base_lambda_rec

    def _compute_rec_loss(self, pred1: torch.Tensor, pred2: torch.Tensor, img1: torch.Tensor, img2: torch.Tensor):
        if self.reconstruct_each_view:
            rec_output1 = self.rec_criterion(pred1, img1)
            rec_output2 = self.rec_criterion(pred2, img2)
        else:
            rec_output1 = self.rec_criterion(pred1, img1)
            rec_output2 = self.rec_criterion(pred2, img1)

        rec_loss = (rec_output1["total"] + rec_output2["total"]) / 2
        l1_loss = (rec_output1["l1"] + rec_output2["l1"]) / 2
        grad_loss = (rec_output1["gradient"] + rec_output2["gradient"]) / 2
        return rec_loss, l1_loss, grad_loss

    def _compute_train_losses(self, images1: torch.Tensor, images2: torch.Tensor) -> Dict[str, torch.Tensor]:
        output1 = self.model(images1)
        output2 = self.model(images2)

        cont_loss = self.cont_criterion(output1["embedding"], output2["embedding"])
        rec_loss, l1_loss, grad_loss = self._compute_rec_loss(
            output1["contours"], output2["contours"], images1, images2
        )

        effective_lambda_cont = self._current_lambda_cont()
        effective_lambda_rec = self._current_lambda_rec()
        total_loss = effective_lambda_cont * cont_loss + effective_lambda_rec * rec_loss

        return {
            "total": total_loss,
            "contrastive": cont_loss,
            "reconstruction": rec_loss,
            "l1": l1_loss,
            "gradient": grad_loss,
            "effective_lambda_cont": total_loss.new_tensor(effective_lambda_cont),
            "effective_lambda_rec": total_loss.new_tensor(effective_lambda_rec),
        }

    def train_epoch(self) -> Dict[str, float]:
        self.model.train()
        total_loss = 0.0
        total_cont_loss = 0.0
        total_rec_loss = 0.0
        total_lambda_cont = 0.0
        total_lambda_rec = 0.0
        num_batches = 0

        for batch_idx, batch in enumerate(self.train_loader):
            images1, images2, _ = batch
            images1 = images1.to(self.device, non_blocking=True)
            images2 = images2.to(self.device, non_blocking=True)

            self.optimizer.zero_grad(set_to_none=True)
            losses = self._compute_train_losses(images1, images2)
            losses["total"].backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=self.config.training.grad_clip)
            self.optimizer.step()

            total_loss += float(losses["total"].item())
            total_cont_loss += float(losses["contrastive"].item())
            total_rec_loss += float(losses["reconstruction"].item())
            total_lambda_cont += float(losses["effective_lambda_cont"].item())
            total_lambda_rec += float(losses["effective_lambda_rec"].item())
            num_batches += 1

            if batch_idx % 50 == 0:
                print(
                    f"  Batch [{batch_idx}/{len(self.train_loader)}] "
                    f"Loss: {losses['total'].item():.4f} "
                    f"Cont(raw): {losses['contrastive'].item():.4f} "
                    f"Rec(raw): {losses['reconstruction'].item():.4f} "
                    f"λ_cont: {losses['effective_lambda_cont'].item():.4f} "
                    f"λ_rec: {losses['effective_lambda_rec'].item():.4f}"
                )

        denom = max(num_batches, 1)
        return {
            "loss": total_loss / denom,
            "contrastive_loss": total_cont_loss / denom,
            "reconstruction_loss": total_rec_loss / denom,
            "effective_lambda_cont": total_lambda_cont / denom,
            "effective_lambda_rec": total_lambda_rec / denom,
        }

    @torch.no_grad()
    def validate(self) -> Dict[str, float]:
        self.model.eval()
        total_rec_error = 0.0
        total_l1_error = 0.0
        total_grad_error = 0.0
        total_cont_error = 0.0
        num_rec_batches = 0
        num_cont_batches = 0

        # 1) 单视图验证：重建相关指标
        for batch in self.val_loader:
            images, _ = batch
            images = images.to(self.device, non_blocking=True)
            output = self.model(images)
            pred_contours = output["contours"]
            metrics = self.metrics.compute_all(pred_contours, None, images)
            total_rec_error += float(metrics["rec_total"])
            total_l1_error += float(metrics["rec_l1"])
            total_grad_error += float(metrics["rec_gradient"])
            num_rec_batches += 1

        # 2) 双视图验证：对比损失
        for batch in self.val_pair_loader:
            images1, images2, _ = batch
            images1 = images1.to(self.device, non_blocking=True)
            images2 = images2.to(self.device, non_blocking=True)
            output1 = self.model(images1)
            output2 = self.model(images2)
            cont_loss = self.cont_criterion(output1["embedding"], output2["embedding"])
            total_cont_error += float(cont_loss.item())
            num_cont_batches += 1

        rec_denom = max(num_rec_batches, 1)
        cont_denom = max(num_cont_batches, 1)
        val_rec_total = total_rec_error / rec_denom
        val_cont_total = total_cont_error / cont_denom

        # mode-dependent 验证总分（用于选 best）
        if self.mode == "rec_only":
            select_score = val_rec_total
        elif self.mode == "cont_only":
            select_score = val_cont_total
        else:
            select_score = self._current_lambda_cont() * val_cont_total + self._current_lambda_rec() * val_rec_total

        return {
            "rec_total": val_rec_total,
            "rec_l1": total_l1_error / rec_denom,
            "rec_gradient": total_grad_error / rec_denom,
            "cont_total": val_cont_total,
            "select_score": select_score,
        }

    def save_checkpoint(self, is_best: bool = False):
        checkpoint = {
            "epoch": self.current_epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "best_score": self.best_score,
            "config": self.config,
            "group_a_mode": self.mode,
            "base_lambda_cont": self.base_lambda_cont,
            "base_lambda_rec": self.base_lambda_rec,
            "cont_final_scale": self.cont_final_scale,
            "cont_warmup_epochs": self.cont_warmup_epochs,
            "reconstruct_each_view": self.reconstruct_each_view,
        }
        if self.scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.scheduler.state_dict()

        latest_path = os.path.join(self.checkpoint_dir, "latest.pth")
        torch.save(checkpoint, latest_path)

        if is_best:
            best_path = os.path.join(self.checkpoint_dir, "best.pth")
            torch.save(checkpoint, best_path)

        epoch_path = os.path.join(self.checkpoint_dir, f"epoch_{self.current_epoch + 1:03d}.pth")
        torch.save(checkpoint, epoch_path)

    def load_checkpoint(self, checkpoint_path: str):
        checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        for state in self.optimizer.state.values():
            for k, v in state.items():
                if torch.is_tensor(v):
                    state[k] = v.to(self.device)
        self.current_epoch = int(checkpoint["epoch"])
        self.best_score = float(checkpoint.get("best_score", checkpoint.get("best_loss", float("inf"))))
        if self.scheduler is not None and "scheduler_state_dict" in checkpoint:
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        print(f"从 epoch {self.current_epoch} 恢复训练")

    def train(self, resume_from: Optional[str] = None):
        if resume_from is not None:
            self.load_checkpoint(resume_from)

        print("开始训练...")
        print(f"模式: {self.mode}")
        print(f"设备: {self.device}")
        print(f"训练集大小: {len(self.train_loader.dataset)}")
        print(f"验证集大小: {len(self.val_loader.dataset)}")
        print(f"批次大小: {self.config.training.batch_size}")
        print(f"总 epoch 数: {self.config.training.num_epochs}")
        print(f"lambda_rec(base): {self.base_lambda_rec}")
        print(f"lambda_cont(base): {self.base_lambda_cont}")
        print(f"cont_final_scale: {self.cont_final_scale}")
        print(f"cont_warmup_epochs: {self.cont_warmup_epochs}")
        print(f"reconstruct_each_view: {self.reconstruct_each_view}")
        print("-" * 60)

        start_time = time.time()
        for epoch in range(self.current_epoch, self.config.training.num_epochs):
            self.current_epoch = epoch
            epoch_start = time.time()
            print(f"\nEpoch [{epoch + 1}/{self.config.training.num_epochs}]")

            train_metrics = self.train_epoch()
            val_metrics = self.validate()
            if self.scheduler is not None:
                self.scheduler.step()

            current_lr = self.optimizer.param_groups[0]["lr"]
            self.writer.add_scalar("Train/Loss", train_metrics["loss"], epoch)
            self.writer.add_scalar("Train/ContrastiveRaw", train_metrics["contrastive_loss"], epoch)
            self.writer.add_scalar("Train/ReconstructionRaw", train_metrics["reconstruction_loss"], epoch)
            self.writer.add_scalar("Train/EffectiveLambdaCont", train_metrics["effective_lambda_cont"], epoch)
            self.writer.add_scalar("Train/EffectiveLambdaRec", train_metrics["effective_lambda_rec"], epoch)
            self.writer.add_scalar("Val/RecError", val_metrics["rec_total"], epoch)
            self.writer.add_scalar("Val/ContLoss", val_metrics["cont_total"], epoch)
            self.writer.add_scalar("Val/SelectScore", val_metrics["select_score"], epoch)
            self.writer.add_scalar("LearningRate", current_lr, epoch)

            is_best = val_metrics["select_score"] < self.best_score
            if is_best:
                self.best_score = val_metrics["select_score"]
                self.early_stop_counter = 0
            else:
                self.early_stop_counter += 1

            self.save_checkpoint(is_best)
            epoch_time = time.time() - epoch_start
            print(
                f"  训练损失: {train_metrics['loss']:.4f} "
                f"(Cont(raw): {train_metrics['contrastive_loss']:.4f}, "
                f"Rec(raw): {train_metrics['reconstruction_loss']:.4f}, "
                f"λ_cont: {train_metrics['effective_lambda_cont']:.4f}, "
                f"λ_rec: {train_metrics['effective_lambda_rec']:.4f})"
            )
            print(
                f"  验证: Rec={val_metrics['rec_total']:.4f}, "
                f"Cont={val_metrics['cont_total']:.4f}, "
                f"SelectScore={val_metrics['select_score']:.4f}"
            )
            print(f"  学习率: {current_lr:.6f}")
            print(f"  Epoch 用时: {epoch_time:.1f}s")
            if is_best:
                print("  ✓ 新的最佳模型!")

            if self.early_stop_counter >= self.config.training.early_stopping_patience:
                print(f"\n早停触发，{self.config.training.early_stopping_patience} 个 epoch 无改善")
                break

        total_time = time.time() - start_time
        print(f"\n训练完成！总用时: {total_time / 3600:.2f} 小时")
        print(f"最佳选择分数: {self.best_score:.4f}")
        self.writer.close()


def _set_seed(seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _prepare_config(args, mode: str) -> Config:
    if args.config is not None:
        config = load_config(args.config)
    else:
        config = get_config()

    if args.epochs is not None:
        config.training.num_epochs = args.epochs
    if args.batch_size is not None:
        config.training.batch_size = args.batch_size
    if args.lr is not None:
        config.training.learning_rate = args.lr

    if args.exp_name is not None:
        config.experiment_name = f"{args.exp_name}_{mode}"
    else:
        config.experiment_name = f"group_a_{mode}"

    config.device = args.device
    return config


def _build_val_pair_loader(config: Config, use_synthetic: bool = False) -> DataLoader:
    target_size = (config.data.image_height, config.data.image_width)
    if use_synthetic:
        dataset = SyntheticDataset(num_samples=200, image_size=target_size, mode='train')
    else:
        dataset = QinBambooSlipDataset(
            root_dir=config.data.val_dir,
            target_size=target_size,
            mode='train',
        )
    return DataLoader(
        dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=config.data.num_workers,
        pin_memory=config.data.pin_memory,
        drop_last=False,
    )


def _run_one_mode(args, mode: str) -> Dict[str, float]:
    config = _prepare_config(args, mode)
    _set_seed(config.seed)

    if config.device == "cuda" and not torch.cuda.is_available():
        print("CUDA 不可用，使用 CPU")
        config.device = "cpu"

    print("=" * 60)
    print(f"A组实验: {mode}")
    print("=" * 60)
    print("创建数据加载器...")
    train_loader, val_loader, test_loader = create_dataloaders(config, use_synthetic=args.synthetic)
    val_pair_loader = _build_val_pair_loader(config, use_synthetic=args.synthetic)

    print("创建模型...")
    model = create_model(config)
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"总参数量: {total_params:,}")
    print(f"可训练参数量: {trainable_params:,}")

    config_save_path = os.path.join(config.training.checkpoint_dir, config.experiment_name, "config.json")
    os.makedirs(os.path.dirname(config_save_path), exist_ok=True)
    save_config(config, config_save_path)

    trainer = GroupATrainer(
        config=config,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        val_pair_loader=val_pair_loader,
        device=config.device,
        mode=mode,
        lambda_cont_override=args.lambda_cont,
        lambda_rec_override=args.lambda_rec,
        cont_final_scale=args.cont_final_scale,
        cont_warmup_epochs=args.cont_warmup_epochs,
        reconstruct_each_view=not args.reconstruct_first_view_only,
    )
    trainer.train(resume_from=args.resume)

    best_checkpoint = os.path.join(config.training.checkpoint_dir, config.experiment_name, "best.pth")
    if os.path.exists(best_checkpoint):
        checkpoint = torch.load(best_checkpoint, map_location=config.device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"加载最佳模型 (epoch {checkpoint['epoch'] + 1})")

    test_results = evaluate_model(
        model,
        test_loader,
        device=config.device,
        has_ground_truth=False,
        sobel_threshold=config.eval.sobel_threshold,
    )

    result_summary = {
        "mode": mode,
        "experiment_name": config.experiment_name,
        "best_select_score": trainer.best_score,
        "test_results": test_results,
        "lambda_cont": trainer.base_lambda_cont,
        "lambda_rec": trainer.base_lambda_rec,
        "cont_final_scale": trainer.cont_final_scale,
        "cont_warmup_epochs": trainer.cont_warmup_epochs,
        "reconstruct_each_view": trainer.reconstruct_each_view,
    }

    summary_path = os.path.join(config.training.checkpoint_dir, config.experiment_name, "group_a_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(result_summary, f, indent=2, ensure_ascii=False)

    print("\n测试集结果:")
    for key, value in test_results.items():
        try:
            print(f"  {key}: {float(value):.4f}")
        except Exception:
            print(f"  {key}: {value}")

    return result_summary


def main():
    parser = argparse.ArgumentParser(description="A组实验 v3：支持 rec_only / cont_only / full_ssl / full_ssl_tuned")
    parser.add_argument("--config", type=str, default=None, help="配置文件路径")
    parser.add_argument("--resume", type=str, default=None, help="恢复训练的检查点路径")
    parser.add_argument("--synthetic", action="store_true", help="使用合成数据")
    parser.add_argument("--epochs", type=int, default=None, help="训练 epoch 数")
    parser.add_argument("--batch_size", type=int, default=None, help="批次大小")
    parser.add_argument("--lr", type=float, default=None, help="学习率")
    parser.add_argument("--device", type=str, default="cuda", help="设备")
    parser.add_argument("--exp_name", type=str, default="paper_a_ssl_study", help="实验名前缀")
    parser.add_argument("--lambda_cont", type=float, default=None, help="覆盖默认对比损失权重")
    parser.add_argument("--lambda_rec", type=float, default=None, help="覆盖默认重建损失权重")
    parser.add_argument("--cont_final_scale", type=float, default=0.25, help="full_ssl_tuned 最终使用的对比损失缩放比例")
    parser.add_argument("--cont_warmup_epochs", type=int, default=10, help="对比损失 warmup epoch 数")
    parser.add_argument("--reconstruct_first_view_only", action="store_true", help="保持旧逻辑：两路都对齐到第一视图")
    parser.add_argument(
        "--mode",
        type=str,
        default="all",
        choices=["rec_only", "cont_only", "full_ssl", "full_ssl_tuned", "all"],
        help="cont_only=仅对比；rec_only=仅重建；full_ssl=原始重建+对比；full_ssl_tuned=降权+warmup；all=顺序跑四组",
    )
    args = parser.parse_args()

    modes: List[str] = [args.mode] if args.mode != "all" else ["rec_only", "cont_only", "full_ssl", "full_ssl_tuned"]
    all_results = []
    for mode in modes:
        result = _run_one_mode(args, mode)
        all_results.append(result)

    if len(all_results) > 1:
        print("\n" + "=" * 80)
        print("A组实验汇总")
        print("=" * 80)
        for item in all_results:
            print(f"- {item['mode']}: best_select_score={item['best_select_score']:.4f}")


if __name__ == "__main__":
    main()
