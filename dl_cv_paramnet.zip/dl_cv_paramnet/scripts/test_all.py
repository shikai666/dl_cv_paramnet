#!/usr/bin/env python
"""
DL-CV ParamNet 测试脚本

验证所有模块是否正常工作
"""

import sys
import os

# 设置路径 - 在任何其他导入之前
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
SRC_DIR = os.path.join(PROJECT_ROOT, 'src')
sys.path.insert(0, SRC_DIR)
sys.path.insert(0, PROJECT_ROOT)

import torch
import numpy as np

def test_imports():
    """测试所有模块导入"""
    print("="*60)
    print("测试模块导入...")
    print("="*60)
    
    modules = [
        ('config', ['ModelConfig', 'TrainingConfig', 'DataConfig', 'EvalConfig']),
        ('models', ['DLCVParamNet', 'create_model', 'FeatureExtractor', 
                    'ParameterPredictor', 'CVExecutionModule']),
        ('losses', ['SelfSupervisedLoss', 'NTXentLoss', 'ReconstructionLoss']),
        ('data', ['QinBambooSlipDataset', 'SyntheticDataset', 'create_dataloaders']),
        ('metrics', ['BoundaryF1Score', 'IoU', 'DiceCoefficient', 'MetricsCalculator']),
    ]
    
    success = True
    for module_name, classes in modules:
        try:
            module = __import__(module_name)
            for cls in classes:
                if not hasattr(module, cls):
                    print(f"  ✗ {module_name}.{cls} 不存在")
                    success = False
                else:
                    print(f"  ✓ {module_name}.{cls}")
        except Exception as e:
            print(f"  ✗ 导入 {module_name} 失败: {e}")
            success = False
    
    return success


def test_model_forward():
    """测试模型前向传播"""
    print("\n" + "="*60)
    print("测试模型前向传播...")
    print("="*60)
    
    from src.models import create_model
    from src.config import ModelConfig
    
    try:
        # 创建模型
        config = ModelConfig()
        model = create_model(config)
        model.eval()
        
        # 创建测试输入
        batch_size = 2
        x = torch.randn(batch_size, 1, 256, 256)
        
        # 前向传播
        with torch.no_grad():
            outputs = model(x)
        
        # 检查输出
        assert 'contours' in outputs, "缺少 contours 输出"
        assert 'params' in outputs, "缺少 params 输出"
        assert outputs['contours'].shape == (batch_size, 1, 256, 256), \
            f"contours 形状错误: {outputs['contours'].shape}"
        assert outputs['params'].shape == (batch_size, 3), \
            f"params 形状错误: {outputs['params'].shape}"
        
        print(f"  ✓ 输入形状: {x.shape}")
        print(f"  ✓ 轮廓输出形状: {outputs['contours'].shape}")
        print(f"  ✓ 参数输出形状: {outputs['params'].shape}")
        print(f"  ✓ 预测参数: t_l={outputs['params'][0,0]:.2f}, "
              f"t_h={outputs['params'][0,1]:.2f}, k_m={outputs['params'][0,2]:.2f}")
        
        return True
    except Exception as e:
        print(f"  ✗ 模型前向传播失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_loss_computation():
    """测试损失函数计算"""
    print("\n" + "="*60)
    print("测试损失函数...")
    print("="*60)
    
    from src.losses import SelfSupervisedLoss, NTXentLoss, ReconstructionLoss
    
    try:
        batch_size = 4
        
        # 测试对比损失
        contrastive_loss = NTXentLoss(temperature=0.1)
        embeddings = torch.randn(batch_size * 2, 128)  # 正样本对
        loss_cont = contrastive_loss(embeddings)
        print(f"  ✓ 对比损失 (NT-Xent): {loss_cont.item():.4f}")
        
        # 测试重建损失
        rec_loss = ReconstructionLoss(gamma=0.5)
        pred = torch.rand(batch_size, 1, 64, 64)
        images = torch.rand(batch_size, 1, 64, 64)
        loss_rec = rec_loss(pred, images)
        print(f"  ✓ 重建损失: {loss_rec.item():.4f}")
        
        # 测试总损失
        total_loss = SelfSupervisedLoss(
            lambda_contrastive=1.0,
            lambda_reconstruction=0.8,
            temperature=0.1
        )
        outputs = {
            'contours': pred,
            'embeddings': embeddings
        }
        loss_dict = total_loss(outputs, images)
        print(f"  ✓ 总损失: {loss_dict['total'].item():.4f}")
        
        return True
    except Exception as e:
        print(f"  ✗ 损失计算失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_metrics():
    """测试评估指标"""
    print("\n" + "="*60)
    print("测试评估指标...")
    print("="*60)
    
    from src.metrics import BoundaryF1Score, IoU, DiceCoefficient
    
    try:
        # 创建测试数据
        pred = torch.zeros(1, 1, 64, 64)
        gt = torch.zeros(1, 1, 64, 64)
        
        # 添加一些重叠区域
        pred[:, :, 10:30, 10:30] = 1
        gt[:, :, 15:35, 15:35] = 1
        
        # 测试 BF-Score
        bf_score = BoundaryF1Score(tolerance=2)
        bf_result = bf_score(pred, gt)
        print(f"  ✓ BF-Score F1: {bf_result['f1']:.4f}")
        
        # 测试 IoU
        iou_metric = IoU()
        iou_val = iou_metric(pred, gt)
        print(f"  ✓ IoU: {iou_val:.4f}")
        
        # 测试 Dice
        dice_metric = DiceCoefficient()
        dice_val = dice_metric(pred, gt)
        print(f"  ✓ Dice: {dice_val:.4f}")
        
        return True
    except Exception as e:
        print(f"  ✗ 指标计算失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_data_loading():
    """测试数据加载"""
    print("\n" + "="*60)
    print("测试数据加载...")
    print("="*60)
    
    from src.data import SyntheticDataset
    from torch.utils.data import DataLoader
    
    try:
        # 创建合成数据集
        dataset = SyntheticDataset(num_samples=10, image_size=128)
        dataloader = DataLoader(dataset, batch_size=2, shuffle=True)
        
        # 获取一个批次
        batch = next(iter(dataloader))
        
        print(f"  ✓ 数据集大小: {len(dataset)}")
        print(f"  ✓ 批次图像形状: {batch['image'].shape}")
        
        return True
    except Exception as e:
        print(f"  ✗ 数据加载失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_cv_execution():
    """测试 CV 执行模块"""
    print("\n" + "="*60)
    print("测试 CV 执行模块...")
    print("="*60)
    
    from src.models.cv_execution import CVExecutionModule
    
    try:
        cv_module = CVExecutionModule()
        
        # 测试输入
        images = torch.rand(2, 1, 64, 64)
        params = torch.tensor([[30.0, 100.0, 5.0], [40.0, 120.0, 7.0]])
        
        # 执行
        contours, intermediates = cv_module(images, params)
        
        print(f"  ✓ 输入图像形状: {images.shape}")
        print(f"  ✓ 输出轮廓形状: {contours.shape}")
        print(f"  ✓ 中间结果: {list(intermediates.keys())}")
        
        return True
    except Exception as e:
        print(f"  ✗ CV 执行失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_parameter_constraints():
    """测试参数约束（确保 t_h > t_l）"""
    print("\n" + "="*60)
    print("测试参数约束...")
    print("="*60)
    
    from src.models.parameter_predictor import ParameterPredictor
    
    try:
        predictor = ParameterPredictor(
            input_dim=512,
            alpha_l=100, beta_l=0,
            alpha_h=100, beta_h=50,
            alpha_k=10, beta_k=3
        )
        
        # 测试多个输入
        features = torch.randn(100, 512)
        params = predictor(features)
        
        t_l = params[:, 0]
        t_h = params[:, 1]
        k_m = params[:, 2]
        
        # 检查约束
        assert (t_h > t_l).all(), "约束违反: 存在 t_h <= t_l"
        assert (k_m >= 3).all() and (k_m <= 13).all(), f"k_m 超出范围: [{k_m.min():.1f}, {k_m.max():.1f}]"
        
        print(f"  ✓ t_l 范围: [{t_l.min():.2f}, {t_l.max():.2f}]")
        print(f"  ✓ t_h 范围: [{t_h.min():.2f}, {t_h.max():.2f}]")
        print(f"  ✓ k_m 范围: [{k_m.min():.2f}, {k_m.max():.2f}]")
        print(f"  ✓ 约束 t_h > t_l: 全部满足")
        
        return True
    except Exception as e:
        print(f"  ✗ 参数约束测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("DL-CV ParamNet 测试套件")
    print("="*60)
    
    results = {
        '模块导入': test_imports(),
        '模型前向传播': test_model_forward(),
        '损失函数': test_loss_computation(),
        '评估指标': test_metrics(),
        '数据加载': test_data_loading(),
        'CV 执行模块': test_cv_execution(),
        '参数约束': test_parameter_constraints(),
    }
    
    # 汇总
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    passed = sum(results.values())
    total = len(results)
    
    for name, result in results.items():
        status = "✓ 通过" if result else "✗ 失败"
        print(f"  {status}: {name}")
    
    print(f"\n总计: {passed}/{total} 通过")
    
    if passed == total:
        print("\n所有测试通过! ✓")
        return 0
    else:
        print(f"\n{total - passed} 个测试失败! ✗")
        return 1


if __name__ == '__main__':
    sys.exit(run_all_tests())
