"""
DL-CV ParamNet 消融实验脚本

消融实验设计：
1. 组件消融
   - 移除对比损失（仅用 \(\mathcal{L}_{rec}\)）
   - 移除重建损失（仅用 \(\mathcal{L}_{cont}\)）
   - 固定 CV 参数（不使用 DL 预测）
   - 禁用注意力机制

2. 超参数消融
   - 温度参数 \(\tau\) 变化
   - 损失权重 \(\lambda_1, \lambda_2\) 变化
   - 参数映射范围变化

3. 架构消融
   - 不同骨干网络（ResNet-18/34/50）
   - 不同特征维度

评价指标：BF-Score、IoU、Dice、重建误差
"""

import os
import sys

# 设置路径 - 在任何其他导入之前
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, 'src')
sys.path.insert(0, _SRC_DIR)
sys.path.insert(0, _PROJECT_ROOT)

import torch
import torch.nn as nn
import numpy as np
import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
from tqdm import tqdm
import copy

# 导入项目模块
from src.models import DLCVParamNet, create_model
from src.models.feature_extractor import FeatureExtractor
from src.models.parameter_predictor import ParameterPredictor
from src.losses import SelfSupervisedLoss, NTXentLoss, ReconstructionLoss
from src.data import create_dataloaders, SyntheticDataset
from src.metrics import MetricsCalculator, evaluate_model
from src.config import ModelConfig, TrainingConfig, DataConfig
from train import Trainer


class AblationConfig:
    """
    消融实验配置
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        model_config: Optional[Dict] = None,
        training_config: Optional[Dict] = None,
        loss_config: Optional[Dict] = None
    ):
        self.name = name
        self.description = description
        self.model_config = model_config or {}
        self.training_config = training_config or {}
        self.loss_config = loss_config or {}
    
    def to_dict(self) -> Dict:
        return {
            'name': self.name,
            'description': self.description,
            'model_config': self.model_config,
            'training_config': self.training_config,
            'loss_config': self.loss_config
        }


# 预定义消融实验配置
ABLATION_CONFIGS = {
    # 完整模型（基线）
    'full': AblationConfig(
        name='full',
        description='完整 DL-CV ParamNet 模型',
        loss_config={'lambda1': 1.0, 'lambda2': 0.8}
    ),
    
    # 损失函数消融
    'no_contrastive': AblationConfig(
        name='no_contrastive',
        description='移除对比损失，仅用重建损失 L_rec',
        loss_config={'lambda1': 0.0, 'lambda2': 1.0}
    ),
    
    'no_reconstruction': AblationConfig(
        name='no_reconstruction',
        description='移除重建损失，仅用对比损失 L_cont',
        loss_config={'lambda1': 1.0, 'lambda2': 0.0}
    ),
    
    # 注意力机制消融
    'no_attention': AblationConfig(
        name='no_attention',
        description='禁用通道注意力机制',
        model_config={'use_attention': False}
    ),
    
    # 温度参数消融
    'tau_0.05': AblationConfig(
        name='tau_0.05',
        description='温度参数 τ=0.05',
        training_config={'temperature': 0.05}
    ),
    
    'tau_0.2': AblationConfig(
        name='tau_0.2',
        description='温度参数 τ=0.2',
        training_config={'temperature': 0.2}
    ),
    
    'tau_0.5': AblationConfig(
        name='tau_0.5',
        description='温度参数 τ=0.5',
        training_config={'temperature': 0.5}
    ),
    
    # 损失权重消融
    'lambda_equal': AblationConfig(
        name='lambda_equal',
        description='损失权重相等 λ1=λ2=1.0',
        loss_config={'lambda1': 1.0, 'lambda2': 1.0}
    ),
    
    'lambda_rec_heavy': AblationConfig(
        name='lambda_rec_heavy',
        description='重建损失权重加大 λ1=0.5, λ2=1.5',
        loss_config={'lambda1': 0.5, 'lambda2': 1.5}
    ),
    
    # 骨干网络消融
    'resnet34': AblationConfig(
        name='resnet34',
        description='使用 ResNet-34 骨干网络',
        model_config={'backbone': 'resnet34'}
    ),
    
    # 特征维度消融
    'feature_256': AblationConfig(
        name='feature_256',
        description='特征维度 D=256',
        model_config={'feature_dim': 256}
    ),
    
    'feature_1024': AblationConfig(
        name='feature_1024',
        description='特征维度 D=1024',
        model_config={'feature_dim': 1024}
    ),
}


class FixedParameterModel(nn.Module):
    """
    固定参数的 CV 模型（用于消融比较）
    
    使用固定的 CV 参数 (t_l=50, t_h=100, k_m=5)
    """
    
    def __init__(
        self,
        t_l: float = 50.0,
        t_h: float = 100.0,
        k_m: float = 5.0
    ):
        super().__init__()
        self.fixed_params = nn.Parameter(
            torch.tensor([t_l, t_h, k_m]),
            requires_grad=False
        )
        
        # CV 执行模块
        from src.models.cv_execution import CVExecutionModule
        self.cv_module = CVExecutionModule()
    
    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        batch_size = x.shape[0]
        
        # 复制固定参数
        params = self.fixed_params.unsqueeze(0).expand(batch_size, -1)
        
        # 执行 CV 操作
        contours = self.cv_module(x, params)
        
        return {
            'contours': contours,
            'params': params
        }


class AblationStudy:
    """
    消融实验管理器
    """
    
    def __init__(
        self,
        base_config: Dict[str, Any],
        output_dir: str,
        device: str = 'cuda',
        num_epochs: int = 50,
        batch_size: int = 32
    ):
        self.base_config = base_config
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        
        self.results = {}
    
    def create_model_with_ablation(
        self,
        ablation_config: AblationConfig
    ) -> nn.Module:
        """
        根据消融配置创建模型
        """
        # 合并配置
        model_config = ModelConfig()
        
        # 应用消融配置
        for key, value in ablation_config.model_config.items():
            if hasattr(model_config, key):
                setattr(model_config, key, value)
        
        # 创建模型
        model = create_model(model_config)
        
        return model
    
    def create_loss_with_ablation(
        self,
        ablation_config: AblationConfig
    ) -> nn.Module:
        """
        根据消融配置创建损失函数
        """
        loss_config = ablation_config.loss_config
        
        lambda1 = loss_config.get('lambda1', 1.0)
        lambda2 = loss_config.get('lambda2', 0.8)
        temperature = ablation_config.training_config.get('temperature', 0.1)
        
        loss_fn = SelfSupervisedLoss(
            lambda1=lambda1,
            lambda2=lambda2,
            temperature=temperature
        )
        
        return loss_fn
    
    def run_single_ablation(
        self,
        ablation_config: AblationConfig,
        train_loader,
        val_loader,
        test_loader
    ) -> Dict[str, Any]:
        """
        运行单个消融实验
        """
        print(f"\n{'='*60}")
        print(f"消融实验: {ablation_config.name}")
        print(f"描述: {ablation_config.description}")
        print(f"{'='*60}")
        
        # 创建模型
        model = self.create_model_with_ablation(ablation_config)
        model = model.to(self.device)
        
        # 创建损失函数
        loss_fn = self.create_loss_with_ablation(ablation_config)
        
        # 创建优化器
        optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
        
        # 训练
        best_val_loss = float('inf')
        training_history = []
        
        for epoch in range(self.num_epochs):
            # 训练阶段
            model.train()
            train_losses = []
            
            for batch in train_loader:
                images = batch[0].to(self.device)
                
                optimizer.zero_grad()
                outputs = model(images)
                
                # 计算损失
                loss_dict = loss_fn(
                    outputs['contours'],
                    outputs['contours'],  # 对比学习使用相同输出作为正样本
                    images
                )
                
                loss = loss_dict['total']
                loss.backward()
                optimizer.step()
                
                train_losses.append(loss.item())
            
            # 验证阶段
            model.eval()
            val_losses = []
            
            with torch.no_grad():
                for batch in val_loader:
                    images = batch[0].to(self.device)
                    outputs = model(images)
                    
                    loss_dict = loss_fn(
                        outputs['contours'],
                        outputs['contours'],
                        images
                    )
                    val_losses.append(loss_dict['total'].item())
            
            train_loss = np.mean(train_losses)
            val_loss = np.mean(val_losses)
            
            training_history.append({
                'epoch': epoch + 1,
                'train_loss': train_loss,
                'val_loss': val_loss
            })
            
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_model_state = copy.deepcopy(model.state_dict())
            
            if (epoch + 1) % 10 == 0:
                print(f"  Epoch {epoch+1}/{self.num_epochs}: "
                      f"Train={train_loss:.4f}, Val={val_loss:.4f}")
        
        # 加载最佳模型
        model.load_state_dict(best_model_state)
        
        # 测试阶段评估
        model.eval()
        metrics = MetricsCalculator()
        
        test_results = {
            'rec_total': [],
            'rec_l1': [],
            'rec_gradient': []
        }
        
        with torch.no_grad():
            for batch in test_loader:
                images = batch[0].to(self.device)
                outputs = model(images)
                
                batch_metrics = metrics.compute_all(
                    outputs['contours'],
                    None,  # 无监督，无地面真值
                    images
                )
                
                for key in test_results:
                    if key in batch_metrics:
                        test_results[key].append(batch_metrics[key])
        
        # 汇总结果
        final_results = {
            'config': ablation_config.to_dict(),
            'best_val_loss': best_val_loss,
            'training_history': training_history,
            'test_metrics': {
                key: {
                    'mean': float(np.mean(values)),
                    'std': float(np.std(values))
                }
                for key, values in test_results.items() if values
            }
        }
        
        # 保存模型
        model_path = self.output_dir / f'{ablation_config.name}_best.pth'
        torch.save({
            'model_state_dict': model.state_dict(),
            'config': ablation_config.to_dict(),
            'results': final_results
        }, model_path)
        
        print(f"\n  测试结果:")
        for key, value in final_results['test_metrics'].items():
            print(f"    {key}: {value['mean']:.4f} ± {value['std']:.4f}")
        
        return final_results
    
    def run_all_ablations(
        self,
        ablation_names: List[str] = None,
        data_config: DataConfig = None
    ) -> Dict[str, Any]:
        """
        运行所有消融实验
        """
        if ablation_names is None:
            ablation_names = list(ABLATION_CONFIGS.keys())
        
        # 创建数据加载器
        if data_config is None:
            print("使用合成数据...")
            from torch.utils.data import DataLoader, random_split
            
            dataset = SyntheticDataset(num_samples=500, image_size=256)
            train_size = int(0.7 * len(dataset))
            val_size = int(0.15 * len(dataset))
            test_size = len(dataset) - train_size - val_size
            
            train_dataset, val_dataset, test_dataset = random_split(
                dataset, [train_size, val_size, test_size]
            )
            
            train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True)
            val_loader = DataLoader(val_dataset, batch_size=self.batch_size)
            test_loader = DataLoader(test_dataset, batch_size=self.batch_size)
        else:
            train_loader, val_loader, test_loader = create_dataloaders(
                data_config, self.batch_size
            )
        
        # 运行消融实验
        all_results = {}
        
        for name in ablation_names:
            if name not in ABLATION_CONFIGS:
                print(f"警告: 未知的消融配置 '{name}'，跳过")
                continue
            
            config = ABLATION_CONFIGS[name]
            results = self.run_single_ablation(
                config, train_loader, val_loader, test_loader
            )
            all_results[name] = results
        
        self.results = all_results
        
        # 保存汇总结果
        self._save_summary()
        
        return all_results
    
    def _save_summary(self):
        """保存汇总结果"""
        summary = {
            'timestamp': datetime.now().isoformat(),
            'num_epochs': self.num_epochs,
            'batch_size': self.batch_size,
            'experiments': {}
        }
        
        for name, results in self.results.items():
            summary['experiments'][name] = {
                'description': results['config']['description'],
                'best_val_loss': results['best_val_loss'],
                'test_metrics': results['test_metrics']
            }
        
        summary_path = self.output_dir / 'ablation_summary.json'
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2, ensure_ascii=False)
        
        print(f"\n汇总结果已保存到: {summary_path}")
    
    def compare_results(self) -> str:
        """
        生成比较报告
        """
        if not self.results:
            return "没有可比较的结果"
        
        report = []
        report.append("\n" + "="*70)
        report.append("DL-CV ParamNet 消融实验比较报告")
        report.append("="*70)
        
        # 表头
        header = f"{'实验名称':<20} {'描述':<25} {'重建误差':<15} {'验证损失':<12}"
        report.append(header)
        report.append("-"*70)
        
        # 按重建误差排序
        sorted_results = sorted(
            self.results.items(),
            key=lambda x: x[1]['test_metrics'].get('rec_total', {}).get('mean', float('inf'))
        )
        
        for name, results in sorted_results:
            desc = results['config']['description'][:23]
            rec_error = results['test_metrics'].get('rec_total', {}).get('mean', float('nan'))
            val_loss = results['best_val_loss']
            
            row = f"{name:<20} {desc:<25} {rec_error:<15.4f} {val_loss:<12.4f}"
            report.append(row)
        
        report.append("-"*70)
        
        # 分析
        report.append("\n【分析】")
        
        # 找出最佳配置
        best_name = sorted_results[0][0]
        best_error = sorted_results[0][1]['test_metrics'].get('rec_total', {}).get('mean', float('nan'))
        
        report.append(f"  最佳配置: {best_name}")
        report.append(f"  最低重建误差: {best_error:.4f}")
        
        # 对比损失消融影响
        if 'full' in self.results and 'no_contrastive' in self.results:
            full_error = self.results['full']['test_metrics'].get('rec_total', {}).get('mean', 0)
            no_cont_error = self.results['no_contrastive']['test_metrics'].get('rec_total', {}).get('mean', 0)
            
            if full_error > 0:
                impact = (no_cont_error - full_error) / full_error * 100
                report.append(f"\n  对比损失影响: 移除后误差变化 {impact:+.2f}%")
        
        if 'full' in self.results and 'no_reconstruction' in self.results:
            full_error = self.results['full']['test_metrics'].get('rec_total', {}).get('mean', 0)
            no_rec_error = self.results['no_reconstruction']['test_metrics'].get('rec_total', {}).get('mean', 0)
            
            if full_error > 0:
                impact = (no_rec_error - full_error) / full_error * 100
                report.append(f"  重建损失影响: 移除后误差变化 {impact:+.2f}%")
        
        if 'full' in self.results and 'no_attention' in self.results:
            full_error = self.results['full']['test_metrics'].get('rec_total', {}).get('mean', 0)
            no_att_error = self.results['no_attention']['test_metrics'].get('rec_total', {}).get('mean', 0)
            
            if full_error > 0:
                impact = (no_att_error - full_error) / full_error * 100
                report.append(f"  注意力机制影响: 移除后误差变化 {impact:+.2f}%")
        
        report.append("\n" + "="*70)
        
        report_str = '\n'.join(report)
        
        # 保存报告
        report_path = self.output_dir / 'ablation_report.txt'
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_str)
        
        print(report_str)
        
        return report_str


def run_fixed_param_baseline(
    test_loader,
    device: str = 'cuda',
    params_list: List[Tuple[float, float, float]] = None
) -> Dict[str, Any]:
    """
    运行固定参数基线实验
    
    Args:
        test_loader: 测试数据加载器
        device: 计算设备
        params_list: 参数列表 [(t_l, t_h, k_m), ...]
    
    Returns:
        各参数组合的评估结果
    """
    if params_list is None:
        params_list = [
            (30, 80, 3),   # 低阈值
            (50, 100, 5),  # 标准参数
            (70, 150, 7),  # 高阈值
            (50, 100, 3),  # 小内核
            (50, 100, 9),  # 大内核
        ]
    
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    metrics = MetricsCalculator()
    
    results = {}
    
    for t_l, t_h, k_m in params_list:
        print(f"\n评估固定参数: t_l={t_l}, t_h={t_h}, k_m={k_m}")
        
        model = FixedParameterModel(t_l=float(t_l), t_h=float(t_h), k_m=float(k_m))
        model = model.to(device)
        model.eval()
        
        test_results = {
            'rec_total': [],
            'rec_l1': [],
            'rec_gradient': []
        }
        
        with torch.no_grad():
            for batch in tqdm(test_loader, desc=f"Testing ({t_l},{t_h},{k_m})"):
                images = batch[0].to(device)
                outputs = model(images)
                
                batch_metrics = metrics.compute_all(
                    outputs['contours'],
                    None,
                    images
                )
                
                for key in test_results:
                    if key in batch_metrics:
                        test_results[key].append(batch_metrics[key])
        
        param_key = f"t{t_l}_h{t_h}_k{k_m}"
        results[param_key] = {
            'params': {'t_l': t_l, 't_h': t_h, 'k_m': k_m},
            'metrics': {
                key: {
                    'mean': float(np.mean(values)),
                    'std': float(np.std(values))
                }
                for key, values in test_results.items() if values
            }
        }
        
        print(f"  重建误差: {results[param_key]['metrics']['rec_total']['mean']:.4f}")
    
    return results


def main():
    parser = argparse.ArgumentParser(description='DL-CV ParamNet 消融实验')
    
    # 实验参数
    parser.add_argument('--ablations', type=str, nargs='+', default=None,
                        help='要运行的消融实验（默认运行全部）')
    parser.add_argument('--list_ablations', action='store_true',
                        help='列出所有可用的消融配置')
    
    # 训练参数
    parser.add_argument('--epochs', type=int, default=50,
                        help='训练轮数')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='批次大小')
    parser.add_argument('--device', type=str, default='cuda',
                        help='计算设备')
    
    # 数据参数
    parser.add_argument('--data_dir', type=str, default=None,
                        help='数据目录')
    parser.add_argument('--synthetic', action='store_true',
                        help='使用合成数据')
    parser.add_argument('--num_samples', type=int, default=500,
                        help='合成数据样本数')
    
    # 输出参数
    parser.add_argument('--output_dir', type=str, default='./ablation_results',
                        help='输出目录')
    
    # 基线比较
    parser.add_argument('--run_baseline', action='store_true',
                        help='运行固定参数基线')
    
    args = parser.parse_args()
    
    # 列出消融配置
    if args.list_ablations:
        print("\n可用的消融配置:")
        print("-"*60)
        for name, config in ABLATION_CONFIGS.items():
            print(f"  {name:<20} - {config.description}")
        print("-"*60)
        return
    
    # 创建输出目录
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 数据配置
    data_config = None
    if args.data_dir:
        data_config = DataConfig(data_dir=args.data_dir)
    
    # 运行消融实验
    study = AblationStudy(
        base_config={},
        output_dir=args.output_dir,
        device=args.device,
        num_epochs=args.epochs,
        batch_size=args.batch_size
    )
    
    # 选择要运行的消融实验
    ablation_names = args.ablations
    if ablation_names is None:
        # 默认运行核心消融实验
        ablation_names = ['full', 'no_contrastive', 'no_reconstruction', 'no_attention']
    
    print(f"\n将运行以下消融实验: {ablation_names}")
    
    # 运行实验
    results = study.run_all_ablations(
        ablation_names=ablation_names,
        data_config=data_config
    )
    
    # 生成比较报告
    study.compare_results()
    
    # 运行固定参数基线
    if args.run_baseline:
        print("\n\n运行固定参数基线实验...")
        
        from torch.utils.data import DataLoader
        if args.synthetic or args.data_dir is None:
            dataset = SyntheticDataset(num_samples=200, image_size=256)
            test_loader = DataLoader(dataset, batch_size=args.batch_size)
        else:
            _, _, test_loader = create_dataloaders(data_config, args.batch_size)
        
        baseline_results = run_fixed_param_baseline(test_loader, args.device)
        
        # 保存基线结果
        baseline_path = output_dir / 'baseline_results.json'
        with open(baseline_path, 'w') as f:
            json.dump(baseline_results, f, indent=2)
        
        print(f"\n基线结果已保存到: {baseline_path}")
    
    print(f"\n所有结果已保存到: {output_dir}")


if __name__ == '__main__':
    main()
