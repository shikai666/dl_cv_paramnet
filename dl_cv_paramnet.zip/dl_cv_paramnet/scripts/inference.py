# -*- coding: utf-8 -*-
"""
ParamNet Inference (Per-Char Boxes Version)

核心策略：
- 列定位仍然用 mask（更稳）
- 切字与过滤改用原图灰度 Otsu 得到的“墨迹二值”(ink01)
  并在 mask 不太“满”(fg_ratio < 0.60)时与 mask 做交集抑制背景噪声
- 即使 mask 因阈值/闭运算变“实心”，也能靠原图墨迹投影分出每个字，并过滤空白框

升级：
- 解决“双列粘一起”：对过宽列span做二次分列（优先mask谷值，不行用ink01谷值）
- 新增：保存每张图的 bbox 数据到 pred_boxes.json（VOC <filename> 对齐，适合评估）
"""

import os
import sys
import time
import json
import argparse
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm


# -------------------- Path setup --------------------
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, "src")
sys.path.insert(0, _SRC_DIR)
sys.path.insert(0, _PROJECT_ROOT)

from src.models import create_model
from src.config import ModelConfig, DataConfig


# -------------------- IO --------------------

def load_image_gray_norm(path: str, target_size: Optional[Tuple[int, int]] = None) -> Tuple[np.ndarray, Tuple[int, int]]:
    """
    读入灰度图，归一化到 [0,1]，并可 resize 到 target_size (H,W)
    返回: img_norm(H,W), original_size(H,W)
    """
    import cv2
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError(f"Cannot read image: {path}")
    original_size = img.shape[:2]
    if target_size is not None:
        img = cv2.resize(img, (target_size[1], target_size[0]), interpolation=cv2.INTER_AREA)
    img = img.astype(np.float32) / 255.0
    return img, original_size


def preprocess_image(img_norm: np.ndarray) -> torch.Tensor:
    # (H,W) -> (1,1,H,W)
    x = img_norm[np.newaxis, np.newaxis, :, :]
    return torch.from_numpy(x).float()


# -------------------- Model output -> prob + threshold --------------------

def _to_prob_map(contour_tensor: torch.Tensor, activation: str = "auto") -> np.ndarray:
    """
    模型 contours 输出 -> 概率图 [0,1]
    activation:
      - auto: 若超出[0,1]，视为logits做sigmoid
      - sigmoid: 强制sigmoid
      - none: 不处理（假设已是概率）
    """
    t = contour_tensor.squeeze()

    if activation not in ("auto", "sigmoid", "none"):
        raise ValueError(f"Unknown mask_activation: {activation}")

    if activation == "sigmoid":
        t = torch.sigmoid(t)
    elif activation == "auto":
        t_min = float(t.min())
        t_max = float(t.max())
        if (t_min < -1e-3) or (t_max > 1.0 + 1e-3):
            t = torch.sigmoid(t)

    prob = t.detach().cpu().numpy().astype(np.float32)
    return np.clip(prob, 0.0, 1.0)


def _choose_threshold(
    prob: np.ndarray,
    mode: str = "auto",
    fixed: float = 0.5,
    quantile: float = 0.92,
    fg_ratio_target: float = 0.10,
    fg_ratio_min: float = 0.02,
    fg_ratio_max: float = 0.35,
) -> float:
    """
    阈值选择策略：
      fixed / quantile / otsu / auto(按前景比例选最接近目标)
    """
    import cv2

    if mode == "fixed":
        return float(fixed)

    if mode == "quantile":
        return float(np.quantile(prob, quantile))

    if mode == "otsu":
        u8 = (prob * 255.0).astype(np.uint8)
        _, th = cv2.threshold(u8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        return float(th) / 255.0

    if mode != "auto":
        raise ValueError(f"Unknown threshold_mode: {mode}")

    candidates = [fixed]
    for q in (0.80, 0.85, 0.88, 0.90, 0.92, 0.94, 0.96, 0.97, 0.98):
        candidates.append(float(np.quantile(prob, q)))

    best_t = candidates[0]
    best_score = 1e9
    for t in candidates:
        fg = float((prob > t).mean())
        if fg_ratio_min <= fg <= fg_ratio_max:
            score = abs(fg - fg_ratio_target)
            if score < best_score:
                best_score = score
                best_t = t

    if best_score >= 1e8:
        best_t = float(np.quantile(prob, quantile))

    return float(best_t)


def postprocess_contour_to_mask(
    contour_tensor: torch.Tensor,
    original_size: Tuple[int, int],
    mask_activation: str = "auto",
    threshold_mode: str = "auto",
    threshold: float = 0.5,
    threshold_quantile: float = 0.92,
    fg_ratio_target: float = 0.10,
    fg_ratio_min: float = 0.02,
    fg_ratio_max: float = 0.35,
    return_prob: bool = False,
) -> Dict[str, Any]:
    """
    返回:
      mask: uint8 0/255 (resize回原图)
      used_threshold: float
      prob(optional): float32 [H,W] (resize回原图)
    """
    import cv2
    prob = _to_prob_map(contour_tensor, activation=mask_activation)
    used_t = _choose_threshold(
        prob,
        mode=threshold_mode,
        fixed=threshold,
        quantile=threshold_quantile,
        fg_ratio_target=fg_ratio_target,
        fg_ratio_min=fg_ratio_min,
        fg_ratio_max=fg_ratio_max,
    )

    mask = (prob > used_t).astype(np.uint8) * 255

    if mask.shape != original_size:
        mask = cv2.resize(mask, (original_size[1], original_size[0]), interpolation=cv2.INTER_NEAREST)

    out: Dict[str, Any] = {"mask": mask, "used_threshold": used_t}

    if return_prob:
        if prob.shape != original_size:
            prob_r = cv2.resize(prob, (original_size[1], original_size[0]), interpolation=cv2.INTER_LINEAR)
        else:
            prob_r = prob
        out["prob"] = prob_r

    return out


# -------------------- Morphology --------------------

def _make_kernel(close_kernel: str, close_rect_w: int, close_rect_h: int, close_size: int):
    import cv2
    close_kernel = close_kernel.lower()
    if close_kernel == "rect":
        w = max(1, int(close_rect_w))
        h = max(1, int(close_rect_h))
        return cv2.getStructuringElement(cv2.MORPH_RECT, (w, h))
    if close_kernel == "ellipse":
        s = max(1, int(close_size))
        return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (s, s))
    if close_kernel == "cross":
        s = max(1, int(close_size))
        return cv2.getStructuringElement(cv2.MORPH_CROSS, (s, s))
    raise ValueError(f"Unknown close_kernel: {close_kernel}")


def clean_mask(
    mask: np.ndarray,
    open_size: int = 0,
    open_iter: int = 0,
    close_kernel: str = "rect",
    close_rect_w: int = 7,
    close_rect_h: int = 1,
    close_size: int = 9,
    close_iter: int = 1,
) -> np.ndarray:
    """
    mask: uint8 0/255
    """
    import cv2
    binary = (mask > 127).astype(np.uint8) * 255

    if close_iter > 0:
        k_close = _make_kernel(close_kernel, close_rect_w, close_rect_h, close_size)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, k_close, iterations=int(close_iter))

    if open_size > 0 and open_iter > 0:
        k_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (int(open_size), int(open_size)))
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, k_open, iterations=int(open_iter))

    return binary


# -------------------- Orientation --------------------

def detect_text_orientation(mask: np.ndarray) -> str:
    h, w = mask.shape[:2]
    if w < h * 0.6:
        return "vertical"
    if h < w * 0.6:
        return "horizontal"

    b = (mask > 127).astype(np.uint8)
    h_proj = b.sum(axis=1)
    v_proj = b.sum(axis=0)
    return "vertical" if np.var(h_proj) > np.var(v_proj) else "horizontal"


# -------------------- Helpers --------------------

def _smooth_1d_np(x: np.ndarray, k: int) -> np.ndarray:
    if k <= 1 or x.size < k:
        return x.astype(np.float32)
    if k % 2 == 0:
        k += 1
    ker = np.ones(int(k), dtype=np.float32) / float(k)
    return np.convolve(x.astype(np.float32), ker, mode="same")


def _runs_from_bool(arr: np.ndarray) -> List[Tuple[int, int]]:
    runs: List[Tuple[int, int]] = []
    s = None
    for i, v in enumerate(arr.tolist()):
        if v and s is None:
            s = i
        elif (not v) and (s is not None):
            runs.append((s, i))
            s = None
    if s is not None:
        runs.append((s, int(arr.shape[0])))
    return runs


# -------------------- Column split by x-projection --------------------

def split_columns_by_x_projection(
    mask: np.ndarray,
    smooth_k: int = 11,
    fg_threshold_ratio: float = 0.10,
    min_col_width: int = 16,
    gap_min_width: int = 6,
) -> List[Tuple[int, int]]:
    """
    用 mask 的 x 投影切“列”
    返回 [(x0,x1), ...]
    """
    b = (mask > 127).astype(np.uint8)
    proj = b.sum(axis=0).astype(np.float32)
    proj = _smooth_1d_np(proj, max(3, smooth_k))

    if proj.size == 0:
        return []

    mx = float(proj.max())
    if mx <= 0:
        return []

    thr = max(1.0, float(fg_threshold_ratio) * mx)
    active = (proj >= thr)

    spans = _runs_from_bool(active)
    if not spans:
        return []

    merged: List[Tuple[int, int]] = [spans[0]]
    for (s, e) in spans[1:]:
        ps, pe = merged[-1]
        if s - pe <= gap_min_width:
            merged[-1] = (ps, e)
        else:
            merged.append((s, e))

    merged = [(s, e) for (s, e) in merged if (e - s) >= min_col_width]
    return merged


def bbox_from_x_span(mask: np.ndarray, span: Tuple[int, int]) -> Optional[Tuple[int, int, int, int]]:
    """
    给定 x 范围，返回在该列范围内的紧 bbox (x,y,w,h)
    """
    x0, x1 = span
    H, W = mask.shape[:2]
    x0 = max(0, int(x0))
    x1 = min(W, int(x1))
    if x1 <= x0:
        return None

    roi = (mask[:, x0:x1] > 127).astype(np.uint8)
    ys, xs = np.where(roi > 0)
    if ys.size == 0:
        return None

    y0 = int(ys.min())
    y1 = int(ys.max()) + 1
    rx0 = int(xs.min())
    rx1 = int(xs.max()) + 1

    bx0 = x0 + rx0
    bx1 = x0 + rx1
    return (bx0, y0, bx1 - bx0, y1 - y0)


# -------------------- Double-column refinement (NEW) --------------------

def refine_double_columns_by_valley(
    col_spans: List[Tuple[int, int]],
    mask_for_columns: np.ndarray,
    ink01_global: np.ndarray,
    smooth_k: int,
    min_col_width: int,
    min_gap: int,
    max_col_width_ratio: float = 1.6,
    valley_ratio: float = 0.25,
    max_depth: int = 2,
) -> List[Tuple[int, int]]:
    """
    对“疑似双列合一”的 span 做二次分列：
    - 先用 mask 的 x 投影找 valley
    - 若 mask 太满，则改用 ink01_global 的 x 投影
    """
    def _find_cut_from_proj(proj: np.ndarray, min_gap: int, valley_ratio: float) -> Optional[int]:
        if proj.size < 2 * min_col_width:
            return None
        mx = float(proj.max())
        if mx <= 1e-6:
            return None

        low_thr = mx * float(valley_ratio)
        low = (proj <= low_thr)

        runs = []
        s = None
        for i, v in enumerate(low.tolist()):
            if v and s is None:
                s = i
            elif (not v) and (s is not None):
                runs.append((s, i))
                s = None
        if s is not None:
            runs.append((s, int(low.shape[0])))

        runs = [(a, b) for (a, b) in runs if (b - a) >= min_gap]
        if runs:
            center = proj.size * 0.5
            a, b = min(runs, key=lambda ab: abs((ab[0] + ab[1]) * 0.5 - center))
            return int((a + b) * 0.5)

        L = int(proj.size * 0.25)
        R = int(proj.size * 0.75)
        if R <= L + 1:
            return int(proj.argmin())
        return int(L + np.argmin(proj[L:R]))

    spans = sorted(col_spans, key=lambda s: s[0])
    if not spans:
        return spans

    widths = np.array([e - s for s, e in spans], dtype=np.float32)
    med_w = float(np.median(widths)) if widths.size else 0.0
    if med_w <= 0:
        return spans

    max_w = max(min_col_width * 2, int(med_w * float(max_col_width_ratio)))

    refined: List[Tuple[int, int]] = []
    for (xs, xe) in spans:
        w = int(xe - xs)
        if w <= max_w or max_depth <= 0:
            refined.append((xs, xe))
            continue

        m = (mask_for_columns[:, xs:xe] > 127).astype(np.uint8)
        proj_m = _smooth_1d_np(m.sum(axis=0).astype(np.float32), max(3, smooth_k))
        cut = _find_cut_from_proj(proj_m, min_gap=min_gap, valley_ratio=valley_ratio)

        if cut is None:
            i01 = (ink01_global[:, xs:xe] > 0).astype(np.uint8)
            proj_i = _smooth_1d_np(i01.sum(axis=0).astype(np.float32), max(3, smooth_k))
            cut = _find_cut_from_proj(proj_i, min_gap=min_gap, valley_ratio=valley_ratio)

        if cut is None:
            refined.append((xs, xe))
            continue

        xcut = xs + int(cut)
        left = (xs, xcut)
        right = (xcut, xe)

        if (left[1] - left[0]) >= min_col_width and (right[1] - right[0]) >= min_col_width:
            refined.extend(
                refine_double_columns_by_valley(
                    [left, right],
                    mask_for_columns=mask_for_columns,
                    ink01_global=ink01_global,
                    smooth_k=smooth_k,
                    min_col_width=min_col_width,
                    min_gap=min_gap,
                    max_col_width_ratio=max_col_width_ratio,
                    valley_ratio=valley_ratio,
                    max_depth=max_depth - 1,
                )
            )
        else:
            refined.append((xs, xe))

    refined = sorted(refined, key=lambda s: s[0])
    return refined


# -------------------- Ink binary (Otsu) --------------------

def _ink_binary_otsu(gray_roi: np.ndarray, mask_roi: Optional[np.ndarray] = None) -> np.ndarray:
    """
    用原图灰度做 Otsu 得到“墨迹”二值：
      - 黑字 -> 1
      - mask_roi 不太满(前景比例<0.60)时才做交集抑制噪声
    返回 0/1 uint8

    用轻微 dilate 代替 open，避免细笔画被吃导致漏字/投影不稳
    """
    import cv2
    _, bin_inv = cv2.threshold(gray_roi, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    ink = (bin_inv > 0).astype(np.uint8)

    if mask_roi is not None:
        fg_ratio = float((mask_roi > 127).mean())
        if fg_ratio < 0.60:
            ink = ink & (mask_roi > 127).astype(np.uint8)

    ink_u8 = ink * 255
    ink_u8 = cv2.dilate(ink_u8, cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2)), iterations=1)
    return (ink_u8 > 0).astype(np.uint8)


def _tight_bbox_from_binary(bin01: np.ndarray, x_off: int, y_off: int) -> Optional[Tuple[int, int, int, int]]:
    ys, xs = np.where(bin01 > 0)
    if ys.size == 0:
        return None
    x0 = int(xs.min()) + x_off
    x1 = int(xs.max()) + 1 + x_off
    y0 = int(ys.min()) + y_off
    y1 = int(ys.max()) + 1 + y_off
    return (x0, y0, x1 - x0, y1 - y0)


def _split_segment_by_expected_and_valleys(
    signal: np.ndarray,
    seg0: int,
    seg1: int,
    ref_char_h: float,
    min_char_size: int,
    smooth_k: int,
    valley_prominence: float,
    valley_depth: float,
    force_split_ratio: float
) -> List[Tuple[int, int]]:
    sig = signal[seg0:seg1].astype(np.float32)
    sig = _smooth_1d_np(sig, max(3, smooth_k))
    maxv = float(sig.max()) if sig.size else 0.0
    h = int(seg1 - seg0)

    if maxv <= 1e-6:
        return [(seg0, seg1)]

    if h < ref_char_h * float(force_split_ratio):
        return [(seg0, seg1)]

    n_chars = max(1, int(round(float(h) / float(ref_char_h))))
    n_chars = min(n_chars, max(1, h // max(1, min_char_size)))
    if n_chars <= 1:
        return [(seg0, seg1)]

    depth_thr = maxv * float(valley_depth)
    prom_thr = maxv * float(valley_prominence)

    unit = float(h) / float(n_chars)
    search = int(max(2, 0.35 * unit))

    cuts = [seg0]
    for i in range(1, n_chars):
        expected = int(seg0 + i * unit)
        lo = max(seg0 + 1, expected - search)
        hi = min(seg1 - 1, expected + search)

        local = sig[(lo - seg0):(hi - seg0)]
        if local.size == 0:
            cut = expected
        else:
            idx = int(local.argmin())
            cut = lo + idx

            v = float(sig[cut - seg0])
            l0 = max(seg0, cut - int(0.4 * unit))
            l1 = cut
            r0 = cut
            r1 = min(seg1, cut + int(0.4 * unit))

            left_mean = float(sig[(l0 - seg0):(l1 - seg0)].mean()) if l1 > l0 else v
            right_mean = float(sig[(r0 - seg0):(r1 - seg0)].mean()) if r1 > r0 else v
            shoulder = 0.5 * (left_mean + right_mean)

            if not (v <= depth_thr and (shoulder - v) >= prom_thr):
                cut = expected

        cuts.append(cut)

    cuts.append(seg1)
    cuts = sorted(list(dict.fromkeys(cuts)))

    spans: List[Tuple[int, int]] = []
    for a, b in zip(cuts[:-1], cuts[1:]):
        if (b - a) >= min_char_size:
            spans.append((a, b))

    if len(spans) <= 1 and n_chars > 1:
        spans = []
        for i in range(n_chars):
            a = seg0 + int(i * unit)
            b = seg0 + int((i + 1) * unit) if i < n_chars - 1 else seg1
            if (b - a) >= min_char_size:
                spans.append((a, b))
        if not spans:
            spans = [(seg0, seg1)]

    return spans


def split_characters_per_char(
    mask_for_columns: np.ndarray,
    original_gray: np.ndarray,
    orientation: str = "auto",
    char_aspect_ratio: float = 1.0,
    min_char_size: int = 28,
    min_box_area: int = 180,
    min_density: float = 0.10,
    min_pixel_count: int = 30,
    box_padding: int = 2,
    smooth_k: int = 7,
    valley_prominence: float = 0.25,
    valley_depth: float = 0.30,
    force_split_ratio: float = 1.6,
    max_aspect_deviation: float = 2.2,
    # double-column refine knobs
    col_refine: bool = True,
    col_max_width_ratio: float = 1.6,
    col_valley_ratio: float = 0.25,
    col_refine_depth: int = 2,
) -> List[Tuple[int, int, int, int]]:
    import cv2

    H, W = original_gray.shape[:2]

    def _aspect_ok(box: Tuple[int, int, int, int], ori: str) -> bool:
        x, y, w, h = box
        if w <= 0 or h <= 0:
            return False
        if ori == "vertical":
            expected = (w / max(char_aspect_ratio, 1e-6))
            ratio = h / max(expected, 1e-6)
        else:
            expected = (h * max(char_aspect_ratio, 1e-6))
            ratio = w / max(expected, 1e-6)
        return (1.0 / max_aspect_deviation) <= ratio <= max_aspect_deviation

    def _filter_and_pad(boxes: List[Tuple[int, int, int, int]], ink01_global: np.ndarray) -> List[Tuple[int, int, int, int]]:
        out: List[Tuple[int, int, int, int]] = []
        for (x, y, w, h) in boxes:
            x1 = max(0, x - box_padding)
            y1 = max(0, y - box_padding)
            x2 = min(W, x + w + box_padding)
            y2 = min(H, y + h + box_padding)
            ww, hh = x2 - x1, y2 - y1
            if ww * hh < min_box_area:
                continue
            region = ink01_global[y1:y2, x1:x2]
            pc = int(region.sum())
            if pc < min_pixel_count:
                continue
            dens = float(pc) / float(max(1, ww * hh))
            if dens < min_density:
                continue
            out.append((x1, y1, ww, hh))
        return out

    if orientation == "auto":
        orientation = detect_text_orientation(mask_for_columns)

    ink01_global = _ink_binary_otsu(original_gray, mask_for_columns)

    boxes: List[Tuple[int, int, int, int]] = []

    if orientation == "vertical":
        min_col_w = max(10, min_char_size // 2)
        min_gap = max(4, min_char_size // 6)

        col_spans = split_columns_by_x_projection(
            mask_for_columns,
            smooth_k=max(5, smooth_k),
            fg_threshold_ratio=0.10,
            min_col_width=min_col_w,
            gap_min_width=min_gap,
        )

        if col_refine and col_spans:
            col_spans = refine_double_columns_by_valley(
                col_spans,
                mask_for_columns=mask_for_columns,
                ink01_global=ink01_global,
                smooth_k=max(5, smooth_k),
                min_col_width=min_col_w,
                min_gap=min_gap,
                max_col_width_ratio=col_max_width_ratio,
                valley_ratio=col_valley_ratio,
                max_depth=int(col_refine_depth),
            )

        if not col_spans:
            col_spans = [(0, W)]

        for (xs, xe) in col_spans:
            xs = int(max(0, xs))
            xe = int(min(W, xe))
            if xe - xs < max(8, min_char_size // 3):
                continue

            y0, y1 = 0, H
            bb = bbox_from_x_span(mask_for_columns, (xs, xe))
            if bb is not None:
                _, by, _, bh = bb
                y0 = max(0, int(by))
                y1 = min(H, int(by + bh))
                if y1 - y0 < min_char_size:
                    continue

            gray_roi = original_gray[y0:y1, xs:xe]
            mask_roi = mask_for_columns[y0:y1, xs:xe]

            ink01 = _ink_binary_otsu(gray_roi, mask_roi)

            row_sum = ink01.sum(axis=1).astype(np.float32)
            row_sum = _smooth_1d_np(row_sum, max(3, smooth_k))
            mx = float(row_sum.max()) if row_sum.size else 0.0
            if mx <= 0:
                continue

            thr = max(3.0, 0.12 * mx)
            active = (row_sum >= thr)

            a = (active.astype(np.uint8) * 255).reshape(-1, 1)
            a = cv2.morphologyEx(a, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (1, 11)), iterations=1)
            active2 = (a[:, 0] > 0)
            spans = _runs_from_bool(active2)

            ref_char_h = max(float(xe - xs) / max(char_aspect_ratio, 1e-6), float(min_char_size))

            for (a0, a1) in spans:
                if (a1 - a0) < max(6, min_char_size // 2):
                    continue

                sub_spans = _split_segment_by_expected_and_valleys(
                    signal=row_sum,
                    seg0=a0,
                    seg1=a1,
                    ref_char_h=ref_char_h,
                    min_char_size=min_char_size,
                    smooth_k=max(3, smooth_k),
                    valley_prominence=valley_prominence,
                    valley_depth=valley_depth,
                    force_split_ratio=force_split_ratio
                )

                for (b0, b1) in sub_spans:
                    if (b1 - b0) < min_char_size:
                        continue
                    sub = ink01[b0:b1, :]
                    tb = _tight_bbox_from_binary(sub, x_off=xs, y_off=y0 + b0)
                    if tb is None:
                        continue
                    boxes.append(tb)

        boxes = _filter_and_pad(boxes, ink01_global)
        boxes = [b for b in boxes if _aspect_ok(b, "vertical")]
        boxes.sort(key=lambda bb: (bb[0], bb[1]))

    else:
        ink01 = _ink_binary_otsu(original_gray, mask_for_columns)
        col_sum = ink01.sum(axis=0).astype(np.float32)
        col_sum = _smooth_1d_np(col_sum, max(3, smooth_k))
        mx = float(col_sum.max()) if col_sum.size else 0.0
        if mx > 0:
            thr = max(3.0, 0.12 * mx)
            active = (col_sum >= thr)

            a = (active.astype(np.uint8) * 255).reshape(1, -1)
            a = cv2.morphologyEx(a, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (11, 1)), iterations=1)
            active2 = (a[0, :] > 0)
            spans = _runs_from_bool(active2)

            ref_char_w = max(float(H) * max(char_aspect_ratio, 1e-6), float(min_char_size))

            for (a0, a1) in spans:
                if (a1 - a0) < max(6, min_char_size // 2):
                    continue

                sub_spans = _split_segment_by_expected_and_valleys(
                    signal=col_sum,
                    seg0=a0,
                    seg1=a1,
                    ref_char_h=ref_char_w,
                    min_char_size=min_char_size,
                    smooth_k=max(3, smooth_k),
                    valley_prominence=valley_prominence,
                    valley_depth=valley_depth,
                    force_split_ratio=force_split_ratio
                )

                for (b0, b1) in sub_spans:
                    if (b1 - b0) < min_char_size:
                        continue
                    sub = ink01[:, b0:b1]
                    tb = _tight_bbox_from_binary(sub, x_off=b0, y_off=0)
                    if tb is None:
                        continue
                    boxes.append(tb)

        boxes = _filter_and_pad(boxes, ink01_global)
        boxes = [b for b in boxes if _aspect_ok(b, "horizontal")]
        boxes.sort(key=lambda bb: (bb[1], bb[0]))

    return boxes


# -------------------- Visualization --------------------

def save_overlay_and_boxes(
    original_bgr: np.ndarray,
    mask_cleaned: np.ndarray,
    boxes: List[Tuple[int, int, int, int]],
    out_path: str,
    box_padding: int = 1,
    draw_mask_overlay: bool = False,
):
    import cv2
    vis = original_bgr.copy()
    H, W = vis.shape[:2]

    if draw_mask_overlay:
        overlay = vis.copy()
        overlay[mask_cleaned > 127] = (0, 255, 0)
        vis = cv2.addWeighted(vis, 0.6, overlay, 0.4, 0)

    for (x, y, w, h) in boxes:
        x1 = max(0, x - box_padding)
        y1 = max(0, y - box_padding)
        x2 = min(W, x + w + box_padding)
        y2 = min(H, y + h + box_padding)
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 255, 0), thickness=2)

    cv2.imwrite(out_path, vis)


# -------------------- Inferencer --------------------

class Inferencer:
    def __init__(self, checkpoint_path: str, device: str = "cuda", target_size: Tuple[int, int] = (256, 256)):
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.target_size = target_size
        self.model = self._load_model(checkpoint_path)

    def _build_config_like(self, raw_cfg: Any) -> Any:
        if hasattr(raw_cfg, "model") and hasattr(raw_cfg, "data"):
            return raw_cfg

        if isinstance(raw_cfg, dict):
            model_dict = raw_cfg.get("model", raw_cfg)
            data_dict = raw_cfg.get("data", {})

            if isinstance(model_dict, dict):
                model_cfg = ModelConfig(**model_dict)
            elif isinstance(model_dict, ModelConfig):
                model_cfg = model_dict
            else:
                model_cfg = ModelConfig()

            if isinstance(data_dict, dict):
                data_cfg = DataConfig(**data_dict)
            else:
                data_cfg = DataConfig()

            class Dummy:
                pass
            cfg = Dummy()
            cfg.model = model_cfg
            cfg.data = data_cfg
            return cfg

        class Dummy:
            pass
        cfg = Dummy()
        cfg.model = ModelConfig()
        cfg.data = DataConfig()
        return cfg

    def _load_model(self, checkpoint_path: str) -> nn.Module:
        print(f"Loading checkpoint: {checkpoint_path}")
        ckpt = torch.load(checkpoint_path, map_location=self.device, weights_only=False)

        raw_cfg = ckpt.get("config", None)
        if raw_cfg is None:
            class Dummy:
                pass
            cfg = Dummy()
            cfg.model = ModelConfig()
            cfg.data = DataConfig()
        else:
            cfg = self._build_config_like(raw_cfg)

        model = create_model(cfg)

        if "state_dict" in ckpt:
            sd = ckpt["state_dict"]
        elif "model_state_dict" in ckpt:
            sd = ckpt["model_state_dict"]
        else:
            raise KeyError("Checkpoint missing state dict (state_dict/model_state_dict).")

        model.load_state_dict(sd, strict=True)
        model.to(self.device)
        model.eval()
        print(f"Model loaded on {self.device}")
        return model

    def _extract_params(self, outputs: Dict[str, Any], index: int = 0) -> Dict[str, float]:
        params_obj = outputs.get("params", None)
        if params_obj is None:
            return {"t_l": 0.0, "t_h": 0.0, "k_m": 0.0}

        if isinstance(params_obj, torch.Tensor):
            if params_obj.dim() == 2 and params_obj.size(1) >= 3:
                return {"t_l": float(params_obj[index, 0].item()),
                        "t_h": float(params_obj[index, 1].item()),
                        "k_m": float(params_obj[index, 2].item())}
            if params_obj.dim() == 1 and params_obj.numel() >= 3:
                return {"t_l": float(params_obj[0].item()),
                        "t_h": float(params_obj[1].item()),
                        "k_m": float(params_obj[2].item())}

        if isinstance(params_obj, dict):
            def sg(k: str) -> float:
                v = params_obj.get(k, 0.0)
                if isinstance(v, torch.Tensor):
                    flat = v.flatten()
                    idx = min(index, flat.numel() - 1) if flat.numel() > 0 else 0
                    return float(flat[idx].item()) if flat.numel() > 0 else 0.0
                try:
                    return float(v)
                except Exception:
                    return 0.0
            return {"t_l": sg("t_l"), "t_h": sg("t_h"), "k_m": sg("k_m")}

        return {"t_l": 0.0, "t_h": 0.0, "k_m": 0.0}

    def infer_batch(
        self,
        image_paths: List[str],
        batch_size: int = 8,
        mask_activation: str = "auto",
        threshold_mode: str = "auto",
        threshold: float = 0.5,
        threshold_quantile: float = 0.92,
        fg_ratio_target: float = 0.10,
        fg_ratio_min: float = 0.02,
        fg_ratio_max: float = 0.35,
        progress: bool = True,
    ) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []

        iterator = range(0, len(image_paths), batch_size)
        if progress:
            iterator = tqdm(iterator, desc="Infer", total=(len(image_paths) + batch_size - 1) // batch_size)

        for start in iterator:
            end = min(start + batch_size, len(image_paths))
            batch_paths = image_paths[start:end]

            imgs = []
            orig_sizes = []
            for p in batch_paths:
                img_norm, osz = load_image_gray_norm(p, self.target_size)
                imgs.append(img_norm)
                orig_sizes.append(osz)

            x = torch.stack([preprocess_image(im).squeeze(0) for im in imgs], dim=0).to(self.device)

            t0 = time.time()
            with torch.no_grad():
                outputs = self.model(x)
            dt = time.time() - t0

            contours = outputs["contours"]
            if not isinstance(contours, torch.Tensor):
                raise TypeError("outputs['contours'] should be a torch.Tensor")

            for i, p in enumerate(batch_paths):
                ct = contours[i:i+1] if contours.dim() >= 3 else contours
                pp = postprocess_contour_to_mask(
                    ct,
                    original_size=orig_sizes[i],
                    mask_activation=mask_activation,
                    threshold_mode=threshold_mode,
                    threshold=threshold,
                    threshold_quantile=threshold_quantile,
                    fg_ratio_target=fg_ratio_target,
                    fg_ratio_min=fg_ratio_min,
                    fg_ratio_max=fg_ratio_max,
                    return_prob=False,
                )
                params = self._extract_params(outputs, index=i)
                results.append({
                    "path": p,
                    "mask": pp["mask"],
                    "used_threshold": float(pp["used_threshold"]),
                    "params": params,
                    "inference_time": float(dt) / max(1, len(batch_paths)),
                })

        return results


# -------------------- Main processing --------------------

def process_directory(args):
    import cv2

    inferencer = Inferencer(args.checkpoint, device=args.device, target_size=tuple(args.target_size))

    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    xml_dir = output_dir / args.xml_dirname
    if args.save_xml:
        xml_dir.mkdir(parents=True, exist_ok=True)

    exts = [".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"]
    paths: List[Path] = []
    for ext in exts:
        paths.extend(input_dir.glob(f"*{ext}"))
        paths.extend(input_dir.glob(f"*{ext.upper()}"))
    paths = sorted(paths)

    if not paths:
        print(f"No images found in {input_dir}")
        return

    image_paths = [str(p) for p in paths]
    print(f"Found {len(image_paths)} images.")

    results = inferencer.infer_batch(
        image_paths=image_paths,
        batch_size=args.batch_size,
        mask_activation=args.mask_activation,
        threshold_mode=args.threshold_mode,
        threshold=args.threshold,
        threshold_quantile=args.threshold_quantile,
        fg_ratio_target=args.fg_ratio_target,
        fg_ratio_min=args.fg_ratio_min,
        fg_ratio_max=args.fg_ratio_max,
        progress=True,
    )

    all_params: Dict[str, Any] = {}
    all_boxes: Dict[str, Any] = {}   # ✅ 新增：保存每张图 bbox（key=文件名，和VOC filename对齐）
    total_boxes = 0

    for r in tqdm(results, desc="Save"):
        in_path = Path(r["path"])
        stem = in_path.stem

        original_bgr = cv2.imread(str(in_path))
        if original_bgr is None:
            continue
        gray = cv2.cvtColor(original_bgr, cv2.COLOR_BGR2GRAY)
        H, W = gray.shape[:2]

        # 保存 mask
        mask_path = output_dir / f"{stem}_contour.png"
        cv2.imwrite(str(mask_path), r["mask"])

        # cleaned mask（列定位）
        cleaned = clean_mask(
            r["mask"],
            open_size=args.open_size,
            open_iter=args.open_iter,
            close_kernel=args.close_kernel,
            close_rect_w=args.close_rect_w,
            close_rect_h=args.close_rect_h,
            close_size=args.close_size,
            close_iter=args.close_iter,
        )

        # per-char boxes（切字用灰度Otsu）
        boxes = split_characters_per_char(
            mask_for_columns=cleaned,
            original_gray=gray,
            orientation=args.orientation,
            char_aspect_ratio=args.char_aspect_ratio,
            min_char_size=args.min_char_size,
            min_box_area=args.min_box_area,
            min_density=args.min_density,
            min_pixel_count=args.min_pixel_count,
            box_padding=args.box_padding,
            smooth_k=args.smooth_k,
            valley_prominence=args.valley_prominence,
            valley_depth=args.valley_depth,
            force_split_ratio=args.force_split_ratio,
            max_aspect_deviation=args.max_aspect_deviation,
            col_refine=args.col_refine,
            col_max_width_ratio=args.col_max_width_ratio,
            col_valley_ratio=args.col_valley_ratio,
            col_refine_depth=args.col_refine_depth,
        )

        total_boxes += len(boxes)

        # ✅ 新增：保存 bbox 数据（用文件名做 key，和 VOC 的 <filename> 对齐，比如 1138.bmp）
        all_boxes[in_path.name] = {
            "size": [int(H), int(W)],
            "boxes_xywh": [[int(x), int(y), int(w), int(h)] for (x, y, w, h) in boxes],
            "boxes_xyxy": [[int(x), int(y), int(x + w), int(y + h)] for (x, y, w, h) in boxes],
        }

        if args.save_xml:
            depth = 1 if len(original_bgr.shape) == 2 else int(original_bgr.shape[2])
            xml_path = xml_dir / f"{stem}.xml"
            _write_voc_xml(
                xml_path=xml_path,
                image_filename=in_path.name,
                width=W,
                height=H,
                depth=depth,
                boxes=boxes,
                object_name=args.xml_object_name,
            )

        # overlay 输出
        if args.overlay:
            overlay_path = output_dir / f"{stem}_overlay.png"
            save_overlay_and_boxes(
                original_bgr=original_bgr,
                mask_cleaned=cleaned,
                boxes=boxes,
                out_path=str(overlay_path),
                box_padding=args.box_padding,
                draw_mask_overlay=False,
            )

        # debug 输出
        if args.save_debug:
            dbg = output_dir / "debug"
            dbg.mkdir(exist_ok=True)
            cv2.imwrite(str(dbg / f"{stem}_1_mask.png"), r["mask"])
            cv2.imwrite(str(dbg / f"{stem}_2_cleaned.png"), cleaned)
            ink01 = _ink_binary_otsu(gray, cleaned)
            cv2.imwrite(str(dbg / f"{stem}_ink01.png"), ink01 * 255)
            with open(dbg / f"{stem}_threshold.txt", "w", encoding="utf-8") as f:
                f.write(f"used_threshold={r['used_threshold']}\n")

        all_params[stem] = r["params"]

    if args.save_params:
        with open(output_dir / "predicted_params.json", "w", encoding="utf-8") as f:
            json.dump(all_params, f, ensure_ascii=False, indent=2)

    # ✅ 新增：写出 pred_boxes.json
    with open(output_dir / "pred_boxes.json", "w", encoding="utf-8") as f:
        json.dump(all_boxes, f, ensure_ascii=False, indent=2)

    print(f"\nDone. total_boxes={total_boxes}, output_dir={output_dir}")
    print(f"Saved bbox data: {output_dir / 'pred_boxes.json'}")
    if args.save_xml:
        print(f"Saved VOC XML dir: {xml_dir}")



# -------------------- VOC XML export --------------------

def _indent_xml(elem, level: int = 0):
    i = "\n" + level * "\t"
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "\t"
        for child in elem:
            _indent_xml(child, level + 1)
        if not elem[-1].tail or not elem[-1].tail.strip():
            elem[-1].tail = i
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = i


def _write_voc_xml(
    xml_path: Path,
    image_filename: str,
    width: int,
    height: int,
    depth: int,
    boxes: List[Tuple[int, int, int, int]],
    object_name: str = "char",
):
    root = ET.Element("annotation")

    filename_el = ET.SubElement(root, "filename")
    filename_el.text = str(image_filename)

    source_el = ET.SubElement(root, "source")
    database_el = ET.SubElement(source_el, "database")
    database_el.text = "Unknown"

    size_el = ET.SubElement(root, "size")
    width_el = ET.SubElement(size_el, "width")
    width_el.text = str(int(width))
    height_el = ET.SubElement(size_el, "height")
    height_el.text = str(int(height))
    depth_el = ET.SubElement(size_el, "depth")
    depth_el.text = str(int(depth))

    segmented_el = ET.SubElement(root, "segmented")
    segmented_el.text = "0"

    for (x, y, w, h) in boxes:
        xmin = max(0, int(x))
        ymin = max(0, int(y))
        xmax = min(int(width), int(x + w))
        ymax = min(int(height), int(y + h))
        if xmax <= xmin or ymax <= ymin:
            continue

        obj_el = ET.SubElement(root, "object")
        name_el = ET.SubElement(obj_el, "name")
        name_el.text = object_name
        pose_el = ET.SubElement(obj_el, "pose")
        pose_el.text = "Unspecified"
        truncated_el = ET.SubElement(obj_el, "truncated")
        truncated_el.text = "0"
        difficult_el = ET.SubElement(obj_el, "difficult")
        difficult_el.text = "0"

        bndbox_el = ET.SubElement(obj_el, "bndbox")
        xmin_el = ET.SubElement(bndbox_el, "xmin")
        xmin_el.text = str(xmin)
        ymin_el = ET.SubElement(bndbox_el, "ymin")
        ymin_el.text = str(ymin)
        xmax_el = ET.SubElement(bndbox_el, "xmax")
        xmax_el.text = str(xmax)
        ymax_el = ET.SubElement(bndbox_el, "ymax")
        ymax_el.text = str(ymax)

    _indent_xml(root)
    tree = ET.ElementTree(root)
    xml_path.parent.mkdir(parents=True, exist_ok=True)
    tree.write(str(xml_path), encoding="utf-8", xml_declaration=False)



def build_parser():
    p = argparse.ArgumentParser("ParamNet inference (per-char + save boxes)")

    # paths / runtime
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--device", type=str, default="cuda")
    p.add_argument("--input_dir", type=str, required=True)
    p.add_argument("--output_dir", type=str, required=True)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--target_size", type=int, nargs=2, default=[256, 256], help="H W")

    # outputs
    p.add_argument("--overlay", action="store_true")
    p.add_argument("--save_params", action="store_true")
    p.add_argument("--save_debug", action="store_true")
    p.add_argument("--save_xml", action="store_true", default=True, help="save per-image VOC XML with bbox coordinates")
    p.add_argument("--xml_object_name", type=str, default="char", help="object name written into VOC XML <name>")
    p.add_argument("--xml_dirname", type=str, default="xml", help="subdirectory name for saved VOC XML files")

    # mask activation & threshold
    p.add_argument("--mask_activation", type=str, default="auto", choices=["auto", "sigmoid", "none"])
    p.add_argument("--threshold_mode", type=str, default="auto", choices=["auto", "fixed", "quantile", "otsu"])
    p.add_argument("--threshold", type=float, default=0.5)
    p.add_argument("--threshold_quantile", type=float, default=0.92)
    p.add_argument("--fg_ratio_target", type=float, default=0.10)
    p.add_argument("--fg_ratio_min", type=float, default=0.02)
    p.add_argument("--fg_ratio_max", type=float, default=0.35)

    # orientation & char geometry
    p.add_argument("--orientation", type=str, default="auto", choices=["auto", "vertical", "horizontal"])
    p.add_argument("--char_aspect_ratio", type=float, default=1.0)

    # morphology (mask cleanup)
    p.add_argument("--open_size", type=int, default=0)
    p.add_argument("--open_iter", type=int, default=0)

    p.add_argument("--close_kernel", type=str, default="rect", choices=["rect", "ellipse", "cross"])
    p.add_argument("--close_rect_w", type=int, default=7)
    p.add_argument("--close_rect_h", type=int, default=1)
    p.add_argument("--close_size", type=int, default=9, help="used when close_kernel!=rect")
    p.add_argument("--close_iter", type=int, default=1)

    # per-char splitting & filtering
    p.add_argument("--box_padding", type=int, default=1)
    p.add_argument("--min_char_size", type=int, default=24)
    p.add_argument("--min_box_area", type=int, default=120)
    p.add_argument("--min_density", type=float, default=0.08)
    p.add_argument("--min_pixel_count", type=int, default=20)

    p.add_argument("--smooth_k", type=int, default=7)
    p.add_argument("--valley_prominence", type=float, default=0.25)
    p.add_argument("--valley_depth", type=float, default=0.30)
    p.add_argument("--force_split_ratio", type=float, default=1.6)
    p.add_argument("--max_aspect_deviation", type=float, default=2.2)

    # double-column refinement args
    p.add_argument("--col_refine", action="store_true", default=True,
                   help="Enable double-column refinement (default enabled)")
    p.add_argument("--no_col_refine", action="store_false", dest="col_refine",
                   help="Disable double-column refinement")

    p.add_argument("--col_max_width_ratio", type=float, default=1.6,
                   help="If span width > median_width * ratio, treat as suspect and try split")
    p.add_argument("--col_valley_ratio", type=float, default=0.25,
                   help="Valley threshold ratio; larger => more aggressive splitting (0.20~0.35)")
    p.add_argument("--col_refine_depth", type=int, default=2,
                   help="Max recursive splits inside a wide span")

    return p


def main():
    args = build_parser().parse_args()
    process_directory(args)


if __name__ == "__main__":
    main()