"""
DL-CV ParamNet 评估脚本

完整的模型评估流程，包含：
1. 定量指标：BF-Score、IoU、Dice、重建误差、计算效率
2. 定性分析：轮廓可视化、中间结果、参数分布
3. 基线比较：与传统 CV 方法比较
4. 结果导出：JSON/CSV 格式的评估报告

数学定义：
- BF-Score: F1 = 2·P·R/(P+R)，其中 P = |∂C ∩ ∂G_δ|/|∂C|, R = |∂C ∩ ∂G_δ|/|∂G|
- IoU: |C ∩ G| / |C ∪ G|
- Dice: 2·|C ∩ G| / (|C| + |G|)
- 重建误差: \(L_{rec} = ||C - S(I)||_1 + γ||∇C - ∇I||_2^2\)
"""

import os
import sys

# 设置路径 - 在任何其他导入之前
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, 'src')
sys.path.insert(0, _SRC_DIR)
sys.path.insert(0, _PROJECT_ROOT)

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import argparse
import json
import csv
from pathlib import Path
from tqdm import tqdm
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime
import time

# 导入项目模块
from src.models import DLCVParamNet, create_model
from src.data import create_dataloaders, QinBambooSlipDataset, SyntheticDataset
from src.metrics import (
    BoundaryF1Score, IoU, DiceCoefficient,
    ReconstructionError, ComputationalEfficiency, MetricsCalculator
)
# 【修复1】添加 Config 导入
from src.config import ModelConfig, TrainingConfig, DataConfig, EvalConfig, Config


class BaselineCV:
    """
    传统 CV 基线方法

    使用固定参数的 Canny + 形态学操作
    参数设置：
    - 低阈值 \(t_l = 50\)
    - 高阈值 \(t_h = 100\)
    - 内核大小 \(k_m = 5\)
    """

    def __init__(
        self,
        low_threshold: int = 50,
        high_threshold: int = 100,
        kernel_size: int = 5
    ):
        self.low_threshold = low_threshold
        self.high_threshold = high_threshold
        self.kernel_size = kernel_size

    def __call__(self, image: np.ndarray) -> np.ndarray:
        """
        应用传统 CV 处理

        Args:
            image: 输入灰度图像 [H, W] 或 [H, W, 1]

        Returns:
            轮廓掩码 {0, 1}^{H×W}
        """
        import cv2

        # 确保图像格式正确
        if image.ndim == 3:
            image = image[:, :, 0]

        # 转换为 uint8
        if image.dtype != np.uint8:
            if image.max() <= 1.0:
                image = (image * 255).astype(np.uint8)
            else:
                image = image.astype(np.uint8)

        # Canny 边缘检测
        edges = cv2.Canny(image, self.low_threshold, self.high_threshold)

        # 形态学闭运算
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (self.kernel_size, self.kernel_size)
        )
        closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

        # 二值化
        contour_mask = (closed > 0).astype(np.float32)

        return contour_mask


class ConnectedComponentAnalyzer:
    """
    连通组件分析器

    用于下游分割性能评估
    """

    def __init__(self, min_area: int = 10, max_area: int = 10000):
        self.min_area = min_area
        self.max_area = max_area

    def analyze(self, mask: np.ndarray) -> Dict[str, Any]:
        """
        分析连通组件

        Args:
            mask: 二值掩码

        Returns:
            分析结果字典
        """
        from scipy import ndimage

        # 标记连通组件
        labeled, num_features = ndimage.label(mask)

        # 过滤组件
        valid_components = []
        areas = []

        for i in range(1, num_features + 1):
            component = (labeled == i)
            area = component.sum()

            if self.min_area <= area <= self.max_area:
                valid_components.append(component)
                areas.append(area)

        return {
            'num_components': len(valid_components),
            'total_detected': num_features,
            'areas': areas,
            'mean_area': np.mean(areas) if areas else 0,
            'std_area': np.std(areas) if areas else 0
        }


class ModelEvaluator:
    """
    模型评估器

    整合所有评估功能
    """

    def __init__(
        self,
        model: nn.Module,
        device: str = 'cuda',
        boundary_tolerance: int = 2,
        sobel_threshold: float = 0.2,
        gamma: float = 0.5
    ):
        self.model = model
        self.device = device

        # 指标计算器
        self.bf_score = BoundaryF1Score(tolerance=boundary_tolerance)
        self.iou_metric = IoU()
        self.dice_metric = DiceCoefficient()
        self.rec_error = ReconstructionError(gamma=gamma)
        self.efficiency = ComputationalEfficiency(device=device)
        self.cc_analyzer = ConnectedComponentAnalyzer()

        self.sobel_threshold = sobel_threshold

        # 基线方法
        self.baseline_cv = BaselineCV()

    def _extract_params(self, pred_params) -> Dict[str, float]:
        """
        【修复2】从预测结果中提取参数，兼容字典和张量两种格式

        Args:
            pred_params: 可能是 dict 或 tensor

        Returns:
            包含 t_l, t_h, k_m 的字典
        """
        if isinstance(pred_params, dict):
            # 如果是字典格式
            return {
                't_l': pred_params['t_l'].mean().item() if torch.is_tensor(pred_params['t_l']) else float(np.mean(pred_params['t_l'])),
                't_h': pred_params['t_h'].mean().item() if torch.is_tensor(pred_params['t_h']) else float(np.mean(pred_params['t_h'])),
                'k_m': pred_params['k_m'].mean().item() if torch.is_tensor(pred_params['k_m']) else float(np.mean(pred_params['k_m']))
            }
        elif torch.is_tensor(pred_params):
            # 如果是张量格式 [B, 3]
            return {
                't_l': pred_params[:, 0].mean().item(),
                't_h': pred_params[:, 1].mean().item(),
                'k_m': pred_params[:, 2].mean().item()
            }
        else:
            # 其他情况返回默认值
            return {'t_l': 0.0, 't_h': 0.0, 'k_m': 0.0}

    def evaluate_batch(
        self,
        images: torch.Tensor,
        targets: Optional[torch.Tensor] = None
    ) -> Dict[str, Any]:
        """
        评估单个批次

        Args:
            images: 输入图像 [B, 1, H, W]
            targets: 地面真值（可选）[B, 1, H, W]

        Returns:
            批次评估结果
        """
        self.model.eval()

        images = images.to(self.device)
        if targets is not None:
            targets = targets.to(self.device)

        results = {}

        with torch.no_grad():
            # 模型推理
            outputs = self.model(images)
            pred_contours = outputs['contours']
            pred_params = outputs.get('params', outputs)  # 【修复3】安全获取 params

            # 重建误差（无监督指标）
            rec_results = self.rec_error(pred_contours, images, self.sobel_threshold)
            results['rec_total'] = rec_results['total']
            results['rec_l1'] = rec_results['l1']
            results['rec_gradient'] = rec_results['gradient']

            # 如果有地面真值
            if targets is not None:
                # BF-Score
                bf_results = self.bf_score(pred_contours, targets)
                results['bf_precision'] = bf_results['precision']
                results['bf_recall'] = bf_results['recall']
                results['bf_f1'] = bf_results['f1']

                # IoU
                results['iou'] = self.iou_metric(pred_contours, targets)

                # Dice
                results['dice'] = self.dice_metric(pred_contours, targets)

            # 【修复4】参数统计 - 使用兼容方法
            results['params'] = self._extract_params(pred_params)

            # 连通组件分析
            pred_np = (pred_contours > 0.5).cpu().numpy()
            cc_results = []
            for i in range(pred_np.shape[0]):
                cc_results.append(self.cc_analyzer.analyze(pred_np[i, 0]))

            results['cc_num_mean'] = np.mean([r['num_components'] for r in cc_results])
            results['cc_area_mean'] = np.mean([r['mean_area'] for r in cc_results])

        return results

    def evaluate_baseline(
        self,
        images: torch.Tensor,
        targets: Optional[torch.Tensor] = None
    ) -> Dict[str, Any]:
        """
        评估基线方法
        """
        results = {}

        images_np = images.cpu().numpy()
        batch_size = images.shape[0]

        # 处理每张图像
        baseline_contours = []
        for i in range(batch_size):
            img = images_np[i, 0]
            contour = self.baseline_cv(img)
            baseline_contours.append(contour)

        baseline_contours = np.stack(baseline_contours)[:, np.newaxis, :, :]
        baseline_contours = torch.from_numpy(baseline_contours).float().to(self.device)

        images = images.to(self.device)
        if targets is not None:
            targets = targets.to(self.device)

        # 重建误差
        rec_results = self.rec_error(baseline_contours, images, self.sobel_threshold)
        results['rec_total'] = rec_results['total']
        results['rec_l1'] = rec_results['l1']
        results['rec_gradient'] = rec_results['gradient']

        # 如果有地面真值
        if targets is not None:
            bf_results = self.bf_score(baseline_contours, targets)
            results['bf_precision'] = bf_results['precision']
            results['bf_recall'] = bf_results['recall']
            results['bf_f1'] = bf_results['f1']
            results['iou'] = self.iou_metric(baseline_contours, targets)
            results['dice'] = self.dice_metric(baseline_contours, targets)

        return results

    def evaluate_full(
        self,
        dataloader,
        has_ground_truth: bool = False,
        compare_baseline: bool = True,
        progress: bool = True
    ) -> Dict[str, Any]:
        """
        完整评估

        Args:
            dataloader: 数据加载器
            has_ground_truth: 是否有地面真值
            compare_baseline: 是否比较基线
            progress: 是否显示进度

        Returns:
            完整评估结果
        """
        all_results = {
            'model': {
                'rec_total': [], 'rec_l1': [], 'rec_gradient': [],
                'params_t_l': [], 'params_t_h': [], 'params_k_m': [],
                'cc_num': [], 'cc_area': []
            }
        }

        if has_ground_truth:
            all_results['model'].update({
                'bf_precision': [], 'bf_recall': [], 'bf_f1': [],
                'iou': [], 'dice': []
            })

        if compare_baseline:
            all_results['baseline'] = {
                'rec_total': [], 'rec_l1': [], 'rec_gradient': []
            }
            if has_ground_truth:
                all_results['baseline'].update({
                    'bf_precision': [], 'bf_recall': [], 'bf_f1': [],
                    'iou': [], 'dice': []
                })

        iterator = tqdm(dataloader, desc="Evaluating") if progress else dataloader

        for batch in iterator:
            # 解析批次数据
            if isinstance(batch, (list, tuple)):
                images = batch[0]
                targets = batch[1] if len(batch) > 1 and has_ground_truth else None
            else:
                images = batch
                targets = None

            # 模型评估
            model_results = self.evaluate_batch(images, targets)

            all_results['model']['rec_total'].append(model_results['rec_total'])
            all_results['model']['rec_l1'].append(model_results['rec_l1'])
            all_results['model']['rec_gradient'].append(model_results['rec_gradient'])
            all_results['model']['params_t_l'].append(model_results['params']['t_l'])
            all_results['model']['params_t_h'].append(model_results['params']['t_h'])
            all_results['model']['params_k_m'].append(model_results['params']['k_m'])
            all_results['model']['cc_num'].append(model_results['cc_num_mean'])
            all_results['model']['cc_area'].append(model_results['cc_area_mean'])

            if has_ground_truth:
                all_results['model']['bf_precision'].append(model_results['bf_precision'])
                all_results['model']['bf_recall'].append(model_results['bf_recall'])
                all_results['model']['bf_f1'].append(model_results['bf_f1'])
                all_results['model']['iou'].append(model_results['iou'])
                all_results['model']['dice'].append(model_results['dice'])

            # 基线评估
            if compare_baseline:
                baseline_results = self.evaluate_baseline(images, targets)

                all_results['baseline']['rec_total'].append(baseline_results['rec_total'])
                all_results['baseline']['rec_l1'].append(baseline_results['rec_l1'])
                all_results['baseline']['rec_gradient'].append(baseline_results['rec_gradient'])

                if has_ground_truth:
                    all_results['baseline']['bf_precision'].append(baseline_results['bf_precision'])
                    all_results['baseline']['bf_recall'].append(baseline_results['bf_recall'])
                    all_results['baseline']['bf_f1'].append(baseline_results['bf_f1'])
                    all_results['baseline']['iou'].append(baseline_results['iou'])
                    all_results['baseline']['dice'].append(baseline_results['dice'])

        # 汇总统计
        summary = {
            'model': {},
            'metadata': {
                'num_batches': len(dataloader),
                'has_ground_truth': has_ground_truth,
                'compare_baseline': compare_baseline,
                'timestamp': datetime.now().isoformat()
            }
        }

        for key, values in all_results['model'].items():
            if values:
                summary['model'][f'{key}_mean'] = float(np.mean(values))
                summary['model'][f'{key}_std'] = float(np.std(values))

        if compare_baseline:
            summary['baseline'] = {}
            for key, values in all_results['baseline'].items():
                if values:
                    summary['baseline'][f'{key}_mean'] = float(np.mean(values))
                    summary['baseline'][f'{key}_std'] = float(np.std(values))

        # 计算效率指标
        summary['efficiency'] = self.compute_efficiency()

        return summary

    def compute_efficiency(
        self,
        input_shape: Tuple[int, ...] = (1, 1, 256, 256),
        num_runs: int = 100
    ) -> Dict[str, float]:
        """
        计算效率指标
        """
        params = self.efficiency.count_parameters(self.model)
        timing = self.efficiency.measure_inference_time(
            self.model, input_shape, num_runs
        )

        return {
            'total_params': params['total'],
            'trainable_params': params['trainable'],
            'inference_time_ms': timing['mean'] * 1000,
            'inference_time_std_ms': timing['std'] * 1000,
            'fps': timing['fps']
        }


def save_results(
    results: Dict[str, Any],
    output_dir: str,
    prefix: str = 'eval'
) -> None:
    """
    保存评估结果

    Args:
        results: 评估结果
        output_dir: 输出目录
        prefix: 文件前缀
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 保存 JSON
    json_path = output_dir / f'{prefix}_{timestamp}.json'
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"Results saved to {json_path}")

    # 保存 CSV（扁平化结果）
    csv_path = output_dir / f'{prefix}_{timestamp}.csv'
    flat_results = {}

    def flatten_dict(d, parent_key=''):
        for k, v in d.items():
            new_key = f'{parent_key}_{k}' if parent_key else k
            if isinstance(v, dict):
                flatten_dict(v, new_key)
            else:
                flat_results[new_key] = v

    flatten_dict(results)

    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Metric', 'Value'])
        for key, value in flat_results.items():
            writer.writerow([key, value])

    print(f"Results saved to {csv_path}")


def print_results(results: Dict[str, Any]) -> None:
    """
    打印评估结果
    """
    print("\n" + "="*60)
    print("DL-CV ParamNet 评估结果")
    print("="*60)

    # 模型结果
    print("\n【模型指标】")
    model_results = results.get('model', {})

    # 重建误差
    print("\n  伪地面真值重建误差:")
    print(f"    总误差: {model_results.get('rec_total_mean', 0):.4f} ± {model_results.get('rec_total_std', 0):.4f}")
    print(f"    L1 误差: {model_results.get('rec_l1_mean', 0):.4f} ± {model_results.get('rec_l1_std', 0):.4f}")
    print(f"    梯度误差: {model_results.get('rec_gradient_mean', 0):.4f} ± {model_results.get('rec_gradient_std', 0):.4f}")

    # 监督指标
    if 'bf_f1_mean' in model_results:
        print("\n  边界 F1 分数 (BF-Score):")
        print(f"    Precision: {model_results.get('bf_precision_mean', 0):.4f} ± {model_results.get('bf_precision_std', 0):.4f}")
        print(f"    Recall: {model_results.get('bf_recall_mean', 0):.4f} ± {model_results.get('bf_recall_std', 0):.4f}")
        print(f"    F1: {model_results.get('bf_f1_mean', 0):.4f} ± {model_results.get('bf_f1_std', 0):.4f}")

        print("\n  区域指标:")
        print(f"    IoU: {model_results.get('iou_mean', 0):.4f} ± {model_results.get('iou_std', 0):.4f}")
        print(f"    Dice: {model_results.get('dice_mean', 0):.4f} ± {model_results.get('dice_std', 0):.4f}")

    # 参数分布
    print("\n  预测 CV 参数分布:")
    print(f"    低阈值 t_l: {model_results.get('params_t_l_mean', 0):.2f} ± {model_results.get('params_t_l_std', 0):.2f}")
    print(f"    高阈值 t_h: {model_results.get('params_t_h_mean', 0):.2f} ± {model_results.get('params_t_h_std', 0):.2f}")
    print(f"    内核大小 k_m: {model_results.get('params_k_m_mean', 0):.2f} ± {model_results.get('params_k_m_std', 0):.2f}")

    # 连通组件
    print("\n  连通组件分析:")
    print(f"    平均组件数: {model_results.get('cc_num_mean', 0):.2f} ± {model_results.get('cc_num_std', 0):.2f}")
    print(f"    平均组件面积: {model_results.get('cc_area_mean', 0):.2f} ± {model_results.get('cc_area_std', 0):.2f}")

    # 基线比较
    if 'baseline' in results:
        print("\n【基线方法对比】(固定参数 CV: t_l=50, t_h=100, k_m=5)")
        baseline = results['baseline']

        print("\n  伪地面真值重建误差:")
        print(f"    总误差: {baseline.get('rec_total_mean', 0):.4f} ± {baseline.get('rec_total_std', 0):.4f}")

        if 'bf_f1_mean' in baseline:
            print("\n  边界 F1 分数:")
            print(f"    F1: {baseline.get('bf_f1_mean', 0):.4f} ± {baseline.get('bf_f1_std', 0):.4f}")
            print(f"    IoU: {baseline.get('iou_mean', 0):.4f} ± {baseline.get('iou_std', 0):.4f}")

        # 改进率
        if model_results.get('rec_total_mean') and baseline.get('rec_total_mean'):
            improvement = (baseline['rec_total_mean'] - model_results['rec_total_mean']) / baseline['rec_total_mean'] * 100
            print(f"\n  改进率 (重建误差): {improvement:.2f}%")

    # 效率指标
    if 'efficiency' in results:
        print("\n【计算效率】")
        eff = results['efficiency']
        print(f"  总参数量: {eff.get('total_params', 0):,}")
        print(f"  可训练参数: {eff.get('trainable_params', 0):,}")
        print(f"  推理时间: {eff.get('inference_time_ms', 0):.2f} ± {eff.get('inference_time_std_ms', 0):.2f} ms")
        print(f"  FPS: {eff.get('fps', 0):.2f}")

    print("\n" + "="*60)


def main():
    parser = argparse.ArgumentParser(description='DL-CV ParamNet 评估脚本')

    # 模型参数
    parser.add_argument('--checkpoint', type=str, required=True,
                        help='模型检查点路径')
    parser.add_argument('--device', type=str, default='cuda',
                        help='计算设备')

    # 数据参数
    parser.add_argument('--data_dir', type=str, default=None,
                        help='数据目录')
    parser.add_argument('--synthetic', action='store_true',
                        help='使用合成数据')
    parser.add_argument('--batch_size', type=int, default=16,
                        help='批次大小')
    parser.add_argument('--num_workers', type=int, default=4,
                        help='数据加载工作进程数')

    # 评估参数
    parser.add_argument('--has_gt', action='store_true',
                        help='数据集包含地面真值')
    parser.add_argument('--no_baseline', action='store_true',
                        help='不进行基线比较')
    parser.add_argument('--boundary_tolerance', type=int, default=2,
                        help='边界匹配容差（像素）')
    parser.add_argument('--sobel_threshold', type=float, default=0.2,
                        help='Sobel 边缘阈值')

    # 输出参数
    parser.add_argument('--output_dir', type=str, default='./eval_results',
                        help='结果输出目录')
    parser.add_argument('--no_save', action='store_true',
                        help='不保存结果到文件')

    args = parser.parse_args()

    # 设置设备
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    # 加载模型
    print(f"\nLoading model from {args.checkpoint}...")

    # 【修复5】添加 weights_only=False
    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)

    # 【修复6】正确获取 config 并创建模型
    config = checkpoint.get('config', None)
    if config is None:
        config = Config()

    # 创建模型 - 传入完整的 config
    model = create_model(config)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()

    print(f"Model loaded successfully")

    # 创建数据加载器
    print("\nPreparing data...")
    if args.synthetic:
        from torch.utils.data import DataLoader
        # 【修复7】image_size 使用元组
        dataset = SyntheticDataset(num_samples=200, image_size=(256, 256))
        dataloader = DataLoader(
            dataset,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=args.num_workers
        )
        print(f"Using synthetic dataset with {len(dataset)} samples")
    elif args.data_dir:
        data_config = DataConfig(data_dir=args.data_dir)
        _, _, dataloader = create_dataloaders(data_config, args.batch_size, args.num_workers)
        print(f"Using data from {args.data_dir}")
    else:
        print("Error: Please specify --data_dir or --synthetic")
        return

    # 创建评估器
    evaluator = ModelEvaluator(
        model=model,
        device=str(device),
        boundary_tolerance=args.boundary_tolerance,
        sobel_threshold=args.sobel_threshold
    )

    # 执行评估
    print("\nRunning evaluation...")
    results = evaluator.evaluate_full(
        dataloader=dataloader,
        has_ground_truth=args.has_gt,
        compare_baseline=not args.no_baseline,
        progress=True
    )

    # 打印结果
    print_results(results)

    # 保存结果
    if not args.no_save:
        save_results(results, args.output_dir)


if __name__ == '__main__':
    main()

