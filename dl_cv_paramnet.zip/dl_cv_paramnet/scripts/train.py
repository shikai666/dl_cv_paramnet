"""
DL-CV ParamNet 训练脚本

实现自监督对比学习训练流程
"""

import os
import sys
import time
import argparse
from datetime import datetime
from typing import Dict, Optional

# 设置路径 - 在任何其他导入之前
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, "src")
sys.path.insert(0, _SRC_DIR)
sys.path.insert(0, _PROJECT_ROOT)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
import numpy as np

from src.config import Config, get_config, save_config
from src.models import create_model
from src.losses import SelfSupervisedLoss
from src.data import create_dataloaders
from src.metrics import MetricsCalculator, evaluate_model


class Trainer:
    """
    训练器类

    管理训练循环、验证、检查点保存等
    """

    def __init__(
        self,
        config: Config,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: str = "cuda",
    ):
        self.config = config

        # 统一 device（字符串 -> torch.device）
        self.device = torch.device(device)

        # 模型迁移到 device
        self.model = model.to(self.device)

        self.train_loader = train_loader
        self.val_loader = val_loader

        # 损失函数：必须迁移到 device（否则 sobel/laplacian buffer 在 CPU）
        self.criterion = SelfSupervisedLoss(
            lambda_cont=config.training.lambda_cont,
            lambda_rec=config.training.lambda_rec,
            temperature=config.training.temperature,
            gamma=config.training.gamma,
        ).to(self.device)

        # 优化器
        self.optimizer = self._create_optimizer()

        # 学习率调度器
        self.scheduler = self._create_scheduler()

        # 指标计算器
        self.metrics = MetricsCalculator(sobel_threshold=config.eval.sobel_threshold)

        # TensorBoard
        log_dir = os.path.join(
            config.log_dir,
            config.experiment_name,
            datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        self.writer = SummaryWriter(log_dir)

        # 检查点目录
        self.checkpoint_dir = os.path.join(
            config.training.checkpoint_dir,
            config.experiment_name,
        )
        os.makedirs(self.checkpoint_dir, exist_ok=True)

        # 训练状态
        self.current_epoch = 0
        self.best_loss = float("inf")
        self.early_stop_counter = 0

    def _create_optimizer(self) -> optim.Optimizer:
        """创建优化器"""
        if self.config.training.optimizer == "adam":
            return optim.Adam(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        elif self.config.training.optimizer == "adamw":
            return optim.AdamW(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        elif self.config.training.optimizer == "sgd":
            return optim.SGD(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                momentum=0.9,
                weight_decay=self.config.training.weight_decay,
            )
        else:
            raise ValueError(f"不支持的优化器: {self.config.training.optimizer}")

    def _create_scheduler(self) -> Optional[optim.lr_scheduler._LRScheduler]:
        """创建学习率调度器"""
        if self.config.training.scheduler == "cosine":
            return optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.config.training.num_epochs,
                eta_min=self.config.training.learning_rate * 0.01,
            )
        elif self.config.training.scheduler == "step":
            return optim.lr_scheduler.StepLR(self.optimizer, step_size=30, gamma=0.1)
        elif self.config.training.scheduler == "none":
            return None
        else:
            return None

    def train_epoch(self) -> Dict[str, float]:
        """
        训练一个 epoch

        Returns:
            训练指标字典
        """
        self.model.train()

        total_loss = 0.0
        total_cont_loss = 0.0
        total_rec_loss = 0.0
        num_batches = 0

        for batch_idx, batch in enumerate(self.train_loader):
            # 获取正样本对
            images1, images2, _ = batch
            images1 = images1.to(self.device, non_blocking=True)
            images2 = images2.to(self.device, non_blocking=True)

            # 原始图像（用于重建损失）
            original_images = images1

            # 前向传播
            self.optimizer.zero_grad(set_to_none=True)

            output1 = self.model(images1)
            output2 = self.model(images2)

            # 计算损失
            losses = self.criterion(output1, output2, original_images)

            # ===== 每个 epoch 只打印一次：重建损失梯度（在第一个 batch）=====
            if batch_idx == 0:
                rec_term = self.config.training.lambda_rec * losses["reconstruction"]

                rec_grads = torch.autograd.grad(
                    rec_term,
                    self.model.parameters(),
                    retain_graph=True,
                    allow_unused=True,
                )

                # 只打印几个关键参数（按需增删）
                KEY_NAMES = {
                    "feature_extractor.conv1.weight",
                    "feature_extractor.layer4.1.conv2.weight",
                    "param_predictor.mlp.0.weight",
                    "param_predictor.mlp.2.weight",
                    "param_predictor.mlp.2.bias",
                }

                # 全局 norm
                total_sq = 0.0
                for g in rec_grads:
                    if g is None:
                        continue
                    total_sq += g.detach().float().pow(2).sum().item()
                total_norm = total_sq ** 0.5

                print("\n========== [DEBUG] Rec grad (per-epoch) ==========")
                print(f"Epoch={self.current_epoch}  rec_term={rec_term.item():.6f}")
                print(f"TOTAL rec_grad_norm(all params) = {total_norm:.6e}")

                # 关键层统计
                for (name, _), g in zip(self.model.named_parameters(), rec_grads):
                    if g is None or name not in KEY_NAMES:
                        continue
                    gd = g.detach()
                    zero_ratio = (gd == 0).float().mean().item()
                    print(
                        f"{name:40s} "
                        f"norm={gd.norm().item():.3e} abs_mean={gd.abs().mean().item():.3e} "
                        f"min={gd.min().item():.3e} max={gd.max().item():.3e} "
                        f"zero_ratio={zero_ratio:.3f}"
                    )
                    if name == "param_predictor.mlp.2.weight":
                        row_norm = gd.view(gd.shape[0], -1).norm(dim=1)
                        print(
                            f"  mlp.2.weight row_norm(3 outputs) = {[float(x) for x in row_norm]}"
                        )

                print("==================================================\n")
            # ===== 打印结束 =====

            # 反向传播（总损失）
            losses["total"].backward()

            # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)

            # 更新参数
            self.optimizer.step()

            # 累积损失
            total_loss += float(losses["total"].item())
            total_cont_loss += float(losses["contrastive"].item())
            total_rec_loss += float(losses["reconstruction"].item())
            num_batches += 1

            # 打印进度
            if batch_idx % 50 == 0:
                print(
                    f"  Batch [{batch_idx}/{len(self.train_loader)}] "
                    f"Loss: {losses['total'].item():.4f} "
                    f"Cont: {losses['contrastive'].item():.4f} "
                    f"Rec: {losses['reconstruction'].item():.4f}"
                )

        # 计算平均损失
        avg_loss = total_loss / max(num_batches, 1)
        avg_cont_loss = total_cont_loss / max(num_batches, 1)
        avg_rec_loss = total_rec_loss / max(num_batches, 1)

        return {
            "loss": avg_loss,
            "contrastive_loss": avg_cont_loss,
            "reconstruction_loss": avg_rec_loss,
        }

    @torch.no_grad()
    def validate(self) -> Dict[str, float]:
        """
        验证模型

        Returns:
            验证指标字典
        """
        self.model.eval()

        total_rec_error = 0.0
        total_l1_error = 0.0
        total_grad_error = 0.0
        num_batches = 0

        for batch in self.val_loader:
            images, _ = batch
            images = images.to(self.device, non_blocking=True)

            output = self.model(images)
            pred_contours = output["contours"]

            metrics = self.metrics.compute_all(
                pred_contours,
                None,  # 无地面真值
                images,
            )

            total_rec_error += float(metrics["rec_total"])
            total_l1_error += float(metrics["rec_l1"])
            total_grad_error += float(metrics["rec_gradient"])
            num_batches += 1

        denom = max(num_batches, 1)
        return {
            "rec_total": total_rec_error / denom,
            "rec_l1": total_l1_error / denom,
            "rec_gradient": total_grad_error / denom,
        }

    def save_checkpoint(self, is_best: bool = False):
        """保存检查点"""
        checkpoint = {
            "epoch": self.current_epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "best_loss": self.best_loss,
            "config": self.config,
        }

        if self.scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.scheduler.state_dict()

        latest_path = os.path.join(self.checkpoint_dir, "latest.pth")
        torch.save(checkpoint, latest_path)

        if is_best:
            best_path = os.path.join(self.checkpoint_dir, "best.pth")
            torch.save(checkpoint, best_path)

        if self.current_epoch % self.config.training.save_interval == 0:
            epoch_path = os.path.join(
                self.checkpoint_dir, f"epoch_{self.current_epoch}.pth"
            )
            torch.save(checkpoint, epoch_path)

    def load_checkpoint(self, checkpoint_path: str):
        """加载检查点"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)

        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        # 把 optimizer state 里的 tensor 迁移到当前 device（避免后续 device mismatch）
        for state in self.optimizer.state.values():
            for k, v in state.items():
                if torch.is_tensor(v):
                    state[k] = v.to(self.device)

        self.current_epoch = int(checkpoint["epoch"])
        self.best_loss = float(checkpoint["best_loss"])

        if self.scheduler is not None and "scheduler_state_dict" in checkpoint:
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])

        print(f"从 epoch {self.current_epoch} 恢复训练")

    def train(self, resume_from: Optional[str] = None):
        """
        完整训练流程

        Args:
            resume_from: 恢复训练的检查点路径
        """
        if resume_from is not None:
            self.load_checkpoint(resume_from)

        print("开始训练...")
        print(f"设备: {self.device}")
        print(f"训练集大小: {len(self.train_loader.dataset)}")
        print(f"验证集大小: {len(self.val_loader.dataset)}")
        print(f"批次大小: {self.config.training.batch_size}")
        print(f"总 epoch 数: {self.config.training.num_epochs}")
        print("-" * 50)

        start_time = time.time()

        for epoch in range(self.current_epoch, self.config.training.num_epochs):
            self.current_epoch = epoch
            epoch_start = time.time()

            print(f"\nEpoch [{epoch+1}/{self.config.training.num_epochs}]")

            train_metrics = self.train_epoch()
            val_metrics = self.validate()

            if self.scheduler is not None:
                self.scheduler.step()

            current_lr = self.optimizer.param_groups[0]["lr"]

            self.writer.add_scalar("Train/Loss", train_metrics["loss"], epoch)
            self.writer.add_scalar(
                "Train/Contrastive", train_metrics["contrastive_loss"], epoch
            )
            self.writer.add_scalar(
                "Train/Reconstruction", train_metrics["reconstruction_loss"], epoch
            )
            self.writer.add_scalar("Val/RecError", val_metrics["rec_total"], epoch)
            self.writer.add_scalar("LearningRate", current_lr, epoch)

            is_best = val_metrics["rec_total"] < self.best_loss
            if is_best:
                self.best_loss = val_metrics["rec_total"]
                self.early_stop_counter = 0
            else:
                self.early_stop_counter += 1

            self.save_checkpoint(is_best)

            epoch_time = time.time() - epoch_start
            print(
                f"  训练损失: {train_metrics['loss']:.4f} "
                f"(Cont: {train_metrics['contrastive_loss']:.4f}, "
                f"Rec: {train_metrics['reconstruction_loss']:.4f})"
            )
            print(f"  验证重建误差: {val_metrics['rec_total']:.4f}")
            print(f"  学习率: {current_lr:.6f}")
            print(f"  Epoch 用时: {epoch_time:.1f}s")
            if is_best:
                print("  ✓ 新的最佳模型!")

            if self.early_stop_counter >= self.config.training.early_stopping_patience:
                print(
                    f"\n早停触发，{self.config.training.early_stopping_patience} 个 epoch 无改善"
                )
                break

        total_time = time.time() - start_time
        print(f"\n训练完成！总用时: {total_time/3600:.2f} 小时")
        print(f"最佳验证损失: {self.best_loss:.4f}")

        self.writer.close()


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="DL-CV ParamNet 训练")
    parser.add_argument("--config", type=str, default=None, help="配置文件路径")
    parser.add_argument("--resume", type=str, default=None, help="恢复训练的检查点路径")
    parser.add_argument("--synthetic", action="store_true", help="使用合成数据")
    parser.add_argument("--epochs", type=int, default=None, help="训练 epoch 数")
    parser.add_argument("--batch_size", type=int, default=None, help="批次大小")
    parser.add_argument("--lr", type=float, default=None, help="学习率")
    parser.add_argument("--device", type=str, default="cuda", help="设备")
    parser.add_argument("--exp_name", type=str, default=None, help="实验名称")

    args = parser.parse_args()

    # 加载配置
    if args.config is not None:
        from src.config import load_config

        config = load_config(args.config)
    else:
        config = get_config()

    # 覆盖配置
    if args.epochs is not None:
        config.training.num_epochs = args.epochs
    if args.batch_size is not None:
        config.training.batch_size = args.batch_size
    if args.lr is not None:
        config.training.learning_rate = args.lr
    if args.exp_name is not None:
        config.experiment_name = args.exp_name

    config.device = args.device

    # 设置随机种子
    torch.manual_seed(config.seed)
    np.random.seed(config.seed)

    # 检查设备
    if config.device == "cuda" and not torch.cuda.is_available():
        print("CUDA 不可用，使用 CPU")
        config.device = "cpu"

    print("=" * 50)
    print("DL-CV ParamNet 训练")
    print("=" * 50)

    # 创建数据加载器
    print("\n创建数据加载器...")
    train_loader, val_loader, test_loader = create_dataloaders(
        config, use_synthetic=args.synthetic
    )

    # 创建模型
    print("创建模型...")
    model = create_model(config)

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"总参数量: {total_params:,}")
    print(f"可训练参数量: {trainable_params:,}")

    # 保存配置
    config_save_path = os.path.join(
        config.training.checkpoint_dir, config.experiment_name, "config.json"
    )
    os.makedirs(os.path.dirname(config_save_path), exist_ok=True)
    save_config(config, config_save_path)

    trainer = Trainer(
        config=config,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=config.device,
    )

    trainer.train(resume_from=args.resume)

    # 最终评估
    print("\n" + "=" * 50)
    print("最终评估")
    print("=" * 50)

    best_checkpoint = os.path.join(
        config.training.checkpoint_dir, config.experiment_name, "best.pth"
    )
    if os.path.exists(best_checkpoint):
        # 修复后
        checkpoint = torch.load(best_checkpoint, map_location=config.device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"加载最佳模型 (epoch {checkpoint['epoch']})")

    test_results = evaluate_model(
        model,
        test_loader,
        device=config.device,
        has_ground_truth=False,
        sobel_threshold=config.eval.sobel_threshold,
    )

    print("\n测试集结果:")
    for key, value in test_results.items():
        print(f"  {key}: {value:.4f}")


if __name__ == "__main__":
    main()
