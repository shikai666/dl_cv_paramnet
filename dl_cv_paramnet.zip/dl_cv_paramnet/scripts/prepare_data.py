"""
DL-CV ParamNet 数据准备脚本

功能：
1. 从 PDF 扫描文档提取灰度图像
2. 图像预处理（裁剪、调整大小、标准化）
3. 数据集划分（训练/验证/测试）
4. 数据增强预览
5. 数据集统计分析

里耶秦简数据特点：
- 灰度图像 I ∈ [0, 255]^{H×W×1}
- 无纹理干扰（干净的扫描背景）
- 文字大小变异（不同竹简上的文字尺寸不一）
- 低对比度边缘（需要直方图均衡化增强）
"""

import os
import shutil
import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
from tqdm import tqdm
import random


def check_dependencies():
    """检查依赖库"""
    required = {
        'cv2': 'opencv-python',
        'PIL': 'Pillow',
        'pdf2image': 'pdf2image',
        'numpy': 'numpy'
    }
    
    missing = []
    for module, package in required.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"缺少依赖库: {', '.join(missing)}")
        print(f"请运行: pip install {' '.join(missing)}")
        return False
    return True


def extract_images_from_pdf(
    pdf_path: str,
    output_dir: str,
    dpi: int = 300,
    grayscale: bool = True,
    prefix: str = 'page'
) -> List[str]:
    """
    从 PDF 文件提取图像
    
    Args:
        pdf_path: PDF 文件路径
        output_dir: 输出目录
        dpi: 分辨率
        grayscale: 是否转换为灰度
        prefix: 输出文件名前缀
    
    Returns:
        提取的图像路径列表
    """
    try:
        from pdf2image import convert_from_path
    except ImportError:
        print("请安装 pdf2image: pip install pdf2image")
        print("同时需要安装 poppler: ")
        print("  Ubuntu: sudo apt-get install poppler-utils")
        print("  macOS: brew install poppler")
        print("  Windows: 下载 poppler 并添加到 PATH")
        return []
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"提取 PDF: {pdf_path}")
    print(f"DPI: {dpi}, 灰度: {grayscale}")
    
    # 转换 PDF 到图像
    images = convert_from_path(pdf_path, dpi=dpi, grayscale=grayscale)
    
    output_paths = []
    for i, image in enumerate(tqdm(images, desc="保存图像")):
        output_path = output_dir / f"{prefix}_{i+1:04d}.png"
        image.save(str(output_path))
        output_paths.append(str(output_path))
    
    print(f"提取完成，共 {len(output_paths)} 张图像")
    return output_paths


def preprocess_image(
    image_path: str,
    target_size: Tuple[int, int] = (256, 256),
    apply_histogram_eq: bool = True,
    apply_denoise: bool = False,
    denoise_strength: int = 10
) -> np.ndarray:
    """
    预处理单张图像
    
    Args:
        image_path: 图像路径
        target_size: 目标尺寸 (H, W)
        apply_histogram_eq: 是否应用直方图均衡化
        apply_denoise: 是否去噪
        denoise_strength: 去噪强度
    
    Returns:
        预处理后的图像
    """
    import cv2
    
    # 读取灰度图
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        raise ValueError(f"无法读取图像: {image_path}")
    
    # 直方图均衡化
    # 数学: HistEq(I)_{i,j} = 255 · Σ_{k=0}^{I_{i,j}} p(k)
    if apply_histogram_eq:
        image = cv2.equalizeHist(image)
    
    # 去噪（可选）
    if apply_denoise:
        image = cv2.fastNlMeansDenoising(image, None, denoise_strength)
    
    # 调整大小
    if image.shape[:2] != target_size:
        image = cv2.resize(image, (target_size[1], target_size[0]))  # cv2 用 (W, H)
    
    return image


def crop_text_regions(
    image: np.ndarray,
    min_area: int = 100,
    padding: int = 10
) -> List[np.ndarray]:
    """
    自动裁剪文字区域
    
    使用 Sobel 边缘检测和连通组件分析
    
    Args:
        image: 输入灰度图像
        min_area: 最小区域面积
        padding: 裁剪边距
    
    Returns:
        裁剪后的图像列表
    """
    import cv2
    
    # Sobel 边缘检测
    sobelx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    gradient = np.sqrt(sobelx**2 + sobely**2)
    
    # 二值化
    _, binary = cv2.threshold(
        (gradient / gradient.max() * 255).astype(np.uint8),
        50, 255, cv2.THRESH_BINARY
    )
    
    # 形态学闭运算连接断裂区域
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (20, 20))
    closed = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
    
    # 查找轮廓
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # 裁剪区域
    crops = []
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < min_area:
            continue
        
        x, y, w, h = cv2.boundingRect(cnt)
        
        # 添加边距
        x1 = max(0, x - padding)
        y1 = max(0, y - padding)
        x2 = min(image.shape[1], x + w + padding)
        y2 = min(image.shape[0], y + h + padding)
        
        crop = image[y1:y2, x1:x2]
        crops.append(crop)
    
    return crops


def split_dataset(
    image_paths: List[str],
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15,
    seed: int = 42
) -> Dict[str, List[str]]:
    """
    划分数据集
    
    Args:
        image_paths: 图像路径列表
        train_ratio: 训练集比例
        val_ratio: 验证集比例
        test_ratio: 测试集比例
        seed: 随机种子
    
    Returns:
        划分后的数据集字典
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6
    
    random.seed(seed)
    shuffled = image_paths.copy()
    random.shuffle(shuffled)
    
    n = len(shuffled)
    train_end = int(n * train_ratio)
    val_end = train_end + int(n * val_ratio)
    
    return {
        'train': shuffled[:train_end],
        'val': shuffled[train_end:val_end],
        'test': shuffled[val_end:]
    }


def organize_dataset(
    splits: Dict[str, List[str]],
    output_dir: str,
    target_size: Tuple[int, int] = (256, 256),
    apply_histogram_eq: bool = True
) -> None:
    """
    组织数据集目录结构
    
    Args:
        splits: 数据集划分
        output_dir: 输出目录
        target_size: 目标图像尺寸
        apply_histogram_eq: 是否应用直方图均衡化
    """
    import cv2
    
    output_dir = Path(output_dir)
    
    for split_name, paths in splits.items():
        split_dir = output_dir / split_name / 'images'
        split_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"\n处理 {split_name} 集 ({len(paths)} 张图像)...")
        
        for i, src_path in enumerate(tqdm(paths, desc=split_name)):
            # 预处理
            image = preprocess_image(
                src_path,
                target_size=target_size,
                apply_histogram_eq=apply_histogram_eq
            )
            
            # 保存
            filename = f"{split_name}_{i:05d}.png"
            dst_path = split_dir / filename
            cv2.imwrite(str(dst_path), image)
    
    # 保存元数据
    metadata = {
        'target_size': list(target_size),
        'histogram_eq': apply_histogram_eq,
        'splits': {k: len(v) for k, v in splits.items()}
    }
    
    with open(output_dir / 'metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\n数据集已保存到: {output_dir}")
    print(f"训练: {len(splits['train'])}, 验证: {len(splits['val'])}, 测试: {len(splits['test'])}")


def analyze_dataset(data_dir: str) -> Dict[str, Any]:
    """
    分析数据集统计信息
    
    Args:
        data_dir: 数据集目录
    
    Returns:
        统计信息字典
    """
    import cv2
    
    data_dir = Path(data_dir)
    stats = {
        'total_images': 0,
        'splits': {},
        'image_sizes': [],
        'mean_intensity': [],
        'std_intensity': []
    }
    
    for split in ['train', 'val', 'test']:
        split_dir = data_dir / split / 'images'
        if not split_dir.exists():
            continue
        
        images = list(split_dir.glob('*.png'))
        stats['splits'][split] = len(images)
        stats['total_images'] += len(images)
        
        for img_path in tqdm(images, desc=f"分析 {split}"):
            img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
            if img is not None:
                stats['image_sizes'].append(img.shape)
                stats['mean_intensity'].append(img.mean())
                stats['std_intensity'].append(img.std())
    
    # 汇总统计
    if stats['mean_intensity']:
        stats['avg_mean_intensity'] = np.mean(stats['mean_intensity'])
        stats['avg_std_intensity'] = np.mean(stats['std_intensity'])
        stats['unique_sizes'] = list(set(stats['image_sizes']))
    
    # 移除详细列表
    del stats['image_sizes']
    del stats['mean_intensity']
    del stats['std_intensity']
    
    return stats


def preview_augmentations(
    image_path: str,
    output_path: str = None,
    num_samples: int = 6
) -> None:
    """
    预览数据增强效果
    
    Args:
        image_path: 输入图像路径
        output_path: 输出路径（可选）
        num_samples: 样本数量
    """
    import cv2
    import matplotlib.pyplot as plt
    
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    
    # 定义增强变换
    def rotate(img, angle):
        h, w = img.shape[:2]
        M = cv2.getRotationMatrix2D((w/2, h/2), angle, 1.0)
        return cv2.warpAffine(img, M, (w, h))
    
    def scale(img, factor):
        h, w = img.shape[:2]
        new_h, new_w = int(h * factor), int(w * factor)
        scaled = cv2.resize(img, (new_w, new_h))
        # 裁剪或填充到原始大小
        if factor > 1:
            start_h = (new_h - h) // 2
            start_w = (new_w - w) // 2
            return scaled[start_h:start_h+h, start_w:start_w+w]
        else:
            result = np.zeros((h, w), dtype=img.dtype)
            start_h = (h - new_h) // 2
            start_w = (w - new_w) // 2
            result[start_h:start_h+new_h, start_w:start_w+new_w] = scaled
            return result
    
    def flip_h(img):
        return cv2.flip(img, 1)
    
    def flip_v(img):
        return cv2.flip(img, 0)
    
    # 生成增强样本
    augmented = [
        ('原图', image),
        ('旋转 +15°', rotate(image, 15)),
        ('旋转 -15°', rotate(image, -15)),
        ('缩放 0.8x', scale(image, 0.8)),
        ('缩放 1.2x', scale(image, 1.2)),
        ('水平翻转', flip_h(image)),
    ]
    
    # 可视化
    fig, axes = plt.subplots(2, 3, figsize=(12, 8))
    axes = axes.flatten()
    
    for i, (title, img) in enumerate(augmented):
        axes[i].imshow(img, cmap='gray')
        axes[i].set_title(title)
        axes[i].axis('off')
    
    plt.suptitle('数据增强预览\n几何变换: 旋转 [-15°, +15°], 缩放 [0.8, 1.2]', fontsize=12)
    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        print(f"预览图已保存到: {output_path}")
    else:
        plt.show()


def create_synthetic_dataset(
    output_dir: str,
    num_samples: int = 1000,
    image_size: int = 256,
    seed: int = 42
) -> None:
    """
    创建合成数据集（用于测试）
    
    生成模拟秦简文字的合成图像
    
    Args:
        output_dir: 输出目录
        num_samples: 样本数量
        image_size: 图像尺寸
        seed: 随机种子
    """
    import cv2
    
    np.random.seed(seed)
    output_dir = Path(output_dir)
    
    # 划分
    train_size = int(num_samples * 0.7)
    val_size = int(num_samples * 0.15)
    test_size = num_samples - train_size - val_size
    
    splits = {
        'train': train_size,
        'val': val_size,
        'test': test_size
    }
    
    for split, count in splits.items():
        split_dir = output_dir / split / 'images'
        split_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"生成 {split} 集 ({count} 张)...")
        
        for i in tqdm(range(count)):
            # 创建背景
            bg_intensity = np.random.randint(200, 240)
            image = np.ones((image_size, image_size), dtype=np.uint8) * bg_intensity
            
            # 添加轻微噪声
            noise = np.random.normal(0, 5, image.shape).astype(np.int32)
            image = np.clip(image.astype(np.int32) + noise, 0, 255).astype(np.uint8)
            
            # 添加模拟文字笔画
            num_strokes = np.random.randint(3, 10)
            stroke_intensity = np.random.randint(30, 80)
            
            for _ in range(num_strokes):
                # 随机笔画位置和大小
                x1 = np.random.randint(20, image_size - 20)
                y1 = np.random.randint(20, image_size - 20)
                
                stroke_type = np.random.choice(['line', 'curve', 'dot'])
                
                if stroke_type == 'line':
                    length = np.random.randint(20, 80)
                    angle = np.random.uniform(0, np.pi)
                    x2 = int(x1 + length * np.cos(angle))
                    y2 = int(y1 + length * np.sin(angle))
                    thickness = np.random.randint(2, 5)
                    cv2.line(image, (x1, y1), (x2, y2), stroke_intensity, thickness)
                
                elif stroke_type == 'curve':
                    # 贝塞尔曲线近似
                    points = []
                    for j in range(4):
                        px = x1 + np.random.randint(-30, 30)
                        py = y1 + np.random.randint(-30, 30)
                        points.append([px, py])
                    points = np.array(points, dtype=np.int32)
                    cv2.polylines(image, [points], False, stroke_intensity, 2)
                
                else:  # dot
                    radius = np.random.randint(3, 8)
                    cv2.circle(image, (x1, y1), radius, stroke_intensity, -1)
            
            # 轻微模糊
            image = cv2.GaussianBlur(image, (3, 3), 0)
            
            # 保存
            cv2.imwrite(str(split_dir / f'{split}_{i:05d}.png'), image)
    
    # 保存元数据
    metadata = {
        'type': 'synthetic',
        'image_size': image_size,
        'num_samples': num_samples,
        'splits': splits,
        'seed': seed
    }
    
    with open(output_dir / 'metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\n合成数据集已创建: {output_dir}")


def main():
    parser = argparse.ArgumentParser(
        description='DL-CV ParamNet 数据准备工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 从 PDF 提取图像
  python prepare_data.py extract --pdf document.pdf --output ./extracted
  
  # 预处理和划分数据集
  python prepare_data.py prepare --input ./images --output ./dataset
  
  # 创建合成数据集（测试用）
  python prepare_data.py synthetic --output ./synthetic_data --num_samples 500
  
  # 分析数据集统计信息
  python prepare_data.py analyze --data_dir ./dataset
  
  # 预览数据增强效果
  python prepare_data.py preview --image sample.png --output preview.png
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='子命令')
    
    # extract 命令
    extract_parser = subparsers.add_parser('extract', help='从 PDF 提取图像')
    extract_parser.add_argument('--pdf', type=str, required=True, help='PDF 文件路径')
    extract_parser.add_argument('--output', type=str, required=True, help='输出目录')
    extract_parser.add_argument('--dpi', type=int, default=300, help='分辨率')
    
    # prepare 命令
    prepare_parser = subparsers.add_parser('prepare', help='预处理和划分数据集')
    prepare_parser.add_argument('--input', type=str, required=True, help='输入图像目录')
    prepare_parser.add_argument('--output', type=str, required=True, help='输出数据集目录')
    prepare_parser.add_argument('--size', type=int, nargs=2, default=[256, 256], help='目标尺寸 (H W)')
    prepare_parser.add_argument('--train_ratio', type=float, default=0.7, help='训练集比例')
    prepare_parser.add_argument('--val_ratio', type=float, default=0.15, help='验证集比例')
    prepare_parser.add_argument('--no_histeq', action='store_true', help='不使用直方图均衡化')
    
    # synthetic 命令
    synthetic_parser = subparsers.add_parser('synthetic', help='创建合成数据集')
    synthetic_parser.add_argument('--output', type=str, required=True, help='输出目录')
    synthetic_parser.add_argument('--num_samples', type=int, default=1000, help='样本数量')
    synthetic_parser.add_argument('--size', type=int, default=256, help='图像尺寸')
    synthetic_parser.add_argument('--seed', type=int, default=42, help='随机种子')
    
    # analyze 命令
    analyze_parser = subparsers.add_parser('analyze', help='分析数据集')
    analyze_parser.add_argument('--data_dir', type=str, required=True, help='数据集目录')
    
    # preview 命令
    preview_parser = subparsers.add_parser('preview', help='预览数据增强')
    preview_parser.add_argument('--image', type=str, required=True, help='输入图像')
    preview_parser.add_argument('--output', type=str, default=None, help='输出路径')
    
    args = parser.parse_args()
    
    if args.command == 'extract':
        if not check_dependencies():
            return
        extract_images_from_pdf(args.pdf, args.output, args.dpi)
    
    elif args.command == 'prepare':
        import cv2
        
        input_dir = Path(args.input)
        
        # 收集图像
        extensions = ['*.png', '*.jpg', '*.jpeg', '*.tif', '*.tiff', '*.bmp']
        image_paths = []
        for ext in extensions:
            image_paths.extend(input_dir.glob(ext))
            image_paths.extend(input_dir.glob(ext.upper()))
        
        image_paths = [str(p) for p in sorted(image_paths)]
        
        if not image_paths:
            print(f"在 {input_dir} 中未找到图像文件")
            return
        
        print(f"找到 {len(image_paths)} 张图像")
        
        # 划分数据集
        test_ratio = 1.0 - args.train_ratio - args.val_ratio
        splits = split_dataset(
            image_paths,
            train_ratio=args.train_ratio,
            val_ratio=args.val_ratio,
            test_ratio=test_ratio
        )
        
        # 组织数据集
        organize_dataset(
            splits,
            args.output,
            target_size=tuple(args.size),
            apply_histogram_eq=not args.no_histeq
        )
    
    elif args.command == 'synthetic':
        create_synthetic_dataset(
            args.output,
            num_samples=args.num_samples,
            image_size=args.size,
            seed=args.seed
        )
    
    elif args.command == 'analyze':
        stats = analyze_dataset(args.data_dir)
        
        print("\n数据集统计信息:")
        print(f"  总图像数: {stats['total_images']}")
        for split, count in stats.get('splits', {}).items():
            print(f"  {split}: {count}")
        
        if 'avg_mean_intensity' in stats:
            print(f"  平均亮度: {stats['avg_mean_intensity']:.2f}")
            print(f"  平均标准差: {stats['avg_std_intensity']:.2f}")
        
        if 'unique_sizes' in stats:
            print(f"  图像尺寸: {stats['unique_sizes']}")
    
    elif args.command == 'preview':
        preview_augmentations(args.image, args.output)
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
