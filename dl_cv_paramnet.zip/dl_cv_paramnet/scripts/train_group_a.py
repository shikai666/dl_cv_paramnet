"""
A组实验脚本：验证自监督是否有效

实验定义：
- ours_ssl: 你的原始自监督训练（对比损失 + 重建损失）
- wo_ssl: 去掉对比自监督，仅保留重建分支；模型、优化器、数据增强、CV 模块保持一致

设计原则：
1. 不改原项目 scripts/train.py，避免影响你现有训练流程
2. A1/A2 只改“是否使用对比自监督”，其余尽量保持一致，适合论文对照
3. 支持 --mode both 一次性顺序跑完两组实验
"""

import os
import sys
import time
import json
import copy
import argparse
from datetime import datetime
from typing import Dict, Optional, List

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_SCRIPT_DIR)
_SRC_DIR = os.path.join(_PROJECT_ROOT, "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter

from src.config import get_config, save_config, load_config, Config
from src.models import create_model
from src.losses import SelfSupervisedLoss, ReconstructionLoss
from src.data import create_dataloaders
from src.metrics import MetricsCalculator, evaluate_model


class GroupATrainer:
    """A组实验专用训练器。"""

    def __init__(
        self,
        config: Config,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: str = "cuda",
        mode: str = "ours_ssl",
    ):
        assert mode in {"ours_ssl", "wo_ssl"}
        self.config = config
        self.mode = mode
        self.device = torch.device(device)
        self.model = model.to(self.device)
        self.train_loader = train_loader
        self.val_loader = val_loader

        self.ssl_criterion = SelfSupervisedLoss(
            lambda_cont=config.training.lambda_cont,
            lambda_rec=config.training.lambda_rec,
            temperature=config.training.temperature,
            gamma=config.training.gamma,
            sobel_threshold=config.eval.sobel_threshold,
        ).to(self.device)

        self.rec_criterion = ReconstructionLoss(
            gamma=config.training.gamma,
            sobel_threshold=config.eval.sobel_threshold,
        ).to(self.device)

        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        self.metrics = MetricsCalculator(sobel_threshold=config.eval.sobel_threshold)

        log_dir = os.path.join(
            config.log_dir,
            config.experiment_name,
            datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        self.writer = SummaryWriter(log_dir)

        self.checkpoint_dir = os.path.join(
            config.training.checkpoint_dir,
            config.experiment_name,
        )
        os.makedirs(self.checkpoint_dir, exist_ok=True)

        self.current_epoch = 0
        self.best_loss = float("inf")
        self.early_stop_counter = 0

    def _create_optimizer(self) -> optim.Optimizer:
        if self.config.training.optimizer == "adam":
            return optim.Adam(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        elif self.config.training.optimizer == "adamw":
            return optim.AdamW(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                weight_decay=self.config.training.weight_decay,
            )
        elif self.config.training.optimizer == "sgd":
            return optim.SGD(
                self.model.parameters(),
                lr=self.config.training.learning_rate,
                momentum=0.9,
                weight_decay=self.config.training.weight_decay,
            )
        raise ValueError(f"不支持的优化器: {self.config.training.optimizer}")

    def _create_scheduler(self) -> Optional[optim.lr_scheduler._LRScheduler]:
        if self.config.training.scheduler == "cosine":
            return optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.config.training.num_epochs,
                eta_min=self.config.training.learning_rate * 0.01,
            )
        elif self.config.training.scheduler == "step":
            return optim.lr_scheduler.StepLR(self.optimizer, step_size=30, gamma=0.1)
        return None

    def _compute_train_losses(self, images1: torch.Tensor, images2: torch.Tensor) -> Dict[str, torch.Tensor]:
        """按实验模式计算训练损失。"""
        if self.mode == "ours_ssl":
            output1 = self.model(images1)
            output2 = self.model(images2)
            return self.ssl_criterion(output1, output2, images1)

        # wo_ssl：去掉对比自监督，只保留重建分支
        output = self.model(images1)
        rec_output = self.rec_criterion(output["contours"], images1)
        total_loss = self.config.training.lambda_rec * rec_output["total"]
        zero = total_loss.new_zeros(())
        return {
            "total": total_loss,
            "contrastive": zero,
            "reconstruction": rec_output["total"],
            "l1": rec_output["l1"],
            "gradient": rec_output["gradient"],
        }

    def train_epoch(self) -> Dict[str, float]:
        self.model.train()
        total_loss = 0.0
        total_cont_loss = 0.0
        total_rec_loss = 0.0
        num_batches = 0

        for batch_idx, batch in enumerate(self.train_loader):
            images1, images2, _ = batch
            images1 = images1.to(self.device, non_blocking=True)
            images2 = images2.to(self.device, non_blocking=True)

            self.optimizer.zero_grad(set_to_none=True)
            losses = self._compute_train_losses(images1, images2)
            losses["total"].backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=self.config.training.grad_clip)
            self.optimizer.step()

            total_loss += float(losses["total"].item())
            total_cont_loss += float(losses["contrastive"].item())
            total_rec_loss += float(losses["reconstruction"].item())
            num_batches += 1

            if batch_idx % 50 == 0:
                print(
                    f"  Batch [{batch_idx}/{len(self.train_loader)}] "
                    f"Loss: {losses['total'].item():.4f} "
                    f"Cont: {losses['contrastive'].item():.4f} "
                    f"Rec: {losses['reconstruction'].item():.4f}"
                )

        denom = max(num_batches, 1)
        return {
            "loss": total_loss / denom,
            "contrastive_loss": total_cont_loss / denom,
            "reconstruction_loss": total_rec_loss / denom,
        }

    @torch.no_grad()
    def validate(self) -> Dict[str, float]:
        self.model.eval()
        total_rec_error = 0.0
        total_l1_error = 0.0
        total_grad_error = 0.0
        num_batches = 0

        for batch in self.val_loader:
            images, _ = batch
            images = images.to(self.device, non_blocking=True)
            output = self.model(images)
            pred_contours = output["contours"]
            metrics = self.metrics.compute_all(pred_contours, None, images)
            total_rec_error += float(metrics["rec_total"])
            total_l1_error += float(metrics["rec_l1"])
            total_grad_error += float(metrics["rec_gradient"])
            num_batches += 1

        denom = max(num_batches, 1)
        return {
            "rec_total": total_rec_error / denom,
            "rec_l1": total_l1_error / denom,
            "rec_gradient": total_grad_error / denom,
        }

    def save_checkpoint(self, is_best: bool = False):
        checkpoint = {
            "epoch": self.current_epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "best_loss": self.best_loss,
            "config": self.config,
            "group_a_mode": self.mode,
        }
        if self.scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.scheduler.state_dict()

        latest_path = os.path.join(self.checkpoint_dir, "latest.pth")
        torch.save(checkpoint, latest_path)

        if is_best:
            best_path = os.path.join(self.checkpoint_dir, "best.pth")
            torch.save(checkpoint, best_path)

        if self.current_epoch % self.config.training.save_interval == 0:
            epoch_path = os.path.join(self.checkpoint_dir, f"epoch_{self.current_epoch}.pth")
            torch.save(checkpoint, epoch_path)

    def load_checkpoint(self, checkpoint_path: str):
        checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        for state in self.optimizer.state.values():
            for k, v in state.items():
                if torch.is_tensor(v):
                    state[k] = v.to(self.device)

        self.current_epoch = int(checkpoint["epoch"])
        self.best_loss = float(checkpoint["best_loss"])
        if self.scheduler is not None and "scheduler_state_dict" in checkpoint:
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        print(f"从 epoch {self.current_epoch} 恢复训练")

    def train(self, resume_from: Optional[str] = None):
        if resume_from is not None:
            self.load_checkpoint(resume_from)

        print("开始训练...")
        print(f"模式: {self.mode}")
        print(f"设备: {self.device}")
        print(f"训练集大小: {len(self.train_loader.dataset)}")
        print(f"验证集大小: {len(self.val_loader.dataset)}")
        print(f"批次大小: {self.config.training.batch_size}")
        print(f"总 epoch 数: {self.config.training.num_epochs}")
        print("-" * 50)

        start_time = time.time()
        for epoch in range(self.current_epoch, self.config.training.num_epochs):
            self.current_epoch = epoch
            epoch_start = time.time()
            print(f"\nEpoch [{epoch+1}/{self.config.training.num_epochs}]")

            train_metrics = self.train_epoch()
            val_metrics = self.validate()
            if self.scheduler is not None:
                self.scheduler.step()

            current_lr = self.optimizer.param_groups[0]["lr"]
            self.writer.add_scalar("Train/Loss", train_metrics["loss"], epoch)
            self.writer.add_scalar("Train/Contrastive", train_metrics["contrastive_loss"], epoch)
            self.writer.add_scalar("Train/Reconstruction", train_metrics["reconstruction_loss"], epoch)
            self.writer.add_scalar("Val/RecError", val_metrics["rec_total"], epoch)
            self.writer.add_scalar("LearningRate", current_lr, epoch)

            is_best = val_metrics["rec_total"] < self.best_loss
            if is_best:
                self.best_loss = val_metrics["rec_total"]
                self.early_stop_counter = 0
            else:
                self.early_stop_counter += 1

            self.save_checkpoint(is_best)
            epoch_time = time.time() - epoch_start
            print(
                f"  训练损失: {train_metrics['loss']:.4f} "
                f"(Cont: {train_metrics['contrastive_loss']:.4f}, "
                f"Rec: {train_metrics['reconstruction_loss']:.4f})"
            )
            print(f"  验证重建误差: {val_metrics['rec_total']:.4f}")
            print(f"  学习率: {current_lr:.6f}")
            print(f"  Epoch 用时: {epoch_time:.1f}s")
            if is_best:
                print("  ✓ 新的最佳模型!")

            if self.early_stop_counter >= self.config.training.early_stopping_patience:
                print(f"\n早停触发，{self.config.training.early_stopping_patience} 个 epoch 无改善")
                break

        total_time = time.time() - start_time
        print(f"\n训练完成！总用时: {total_time/3600:.2f} 小时")
        print(f"最佳验证损失: {self.best_loss:.4f}")
        self.writer.close()


def _set_seed(seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _prepare_config(args, mode: str) -> Config:
    if args.config is not None:
        config = load_config(args.config)
    else:
        config = get_config()

    if args.epochs is not None:
        config.training.num_epochs = args.epochs
    if args.batch_size is not None:
        config.training.batch_size = args.batch_size
    if args.lr is not None:
        config.training.learning_rate = args.lr
    if args.exp_name is not None:
        config.experiment_name = f"{args.exp_name}_{mode}"
    else:
        config.experiment_name = f"group_a_{mode}"

    config.device = args.device
    return config


def _run_one_mode(args, mode: str) -> Dict[str, float]:
    config = _prepare_config(args, mode)
    _set_seed(config.seed)

    if config.device == "cuda" and not torch.cuda.is_available():
        print("CUDA 不可用，使用 CPU")
        config.device = "cpu"

    print("=" * 60)
    print(f"A组实验: {mode}")
    print("=" * 60)
    print("创建数据加载器...")
    train_loader, val_loader, test_loader = create_dataloaders(config, use_synthetic=args.synthetic)

    print("创建模型...")
    model = create_model(config)
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"总参数量: {total_params:,}")
    print(f"可训练参数量: {trainable_params:,}")

    config_save_path = os.path.join(config.training.checkpoint_dir, config.experiment_name, "config.json")
    os.makedirs(os.path.dirname(config_save_path), exist_ok=True)
    save_config(config, config_save_path)

    trainer = GroupATrainer(
        config=config,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=config.device,
        mode=mode,
    )
    trainer.train(resume_from=args.resume)

    best_checkpoint = os.path.join(config.training.checkpoint_dir, config.experiment_name, "best.pth")
    if os.path.exists(best_checkpoint):
        checkpoint = torch.load(best_checkpoint, map_location=config.device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"加载最佳模型 (epoch {checkpoint['epoch']})")

    test_results = evaluate_model(
        model,
        test_loader,
        device=config.device,
        has_ground_truth=False,
        sobel_threshold=config.eval.sobel_threshold,
    )

    result_summary = {
        "mode": mode,
        "experiment_name": config.experiment_name,
        "best_val_rec_total": trainer.best_loss,
        "test_results": test_results,
    }

    summary_path = os.path.join(config.training.checkpoint_dir, config.experiment_name, "group_a_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(result_summary, f, indent=2, ensure_ascii=False)

    print("\n测试集结果:")
    for key, value in test_results.items():
        try:
            print(f"  {key}: {float(value):.4f}")
        except Exception:
            print(f"  {key}: {value}")

    return result_summary


def main():
    parser = argparse.ArgumentParser(description="A组实验：自监督有效性验证")
    parser.add_argument("--config", type=str, default=None, help="配置文件路径")
    parser.add_argument("--resume", type=str, default=None, help="恢复训练的检查点路径")
    parser.add_argument("--synthetic", action="store_true", help="使用合成数据")
    parser.add_argument("--epochs", type=int, default=None, help="训练 epoch 数")
    parser.add_argument("--batch_size", type=int, default=None, help="批次大小")
    parser.add_argument("--lr", type=float, default=None, help="学习率")
    parser.add_argument("--device", type=str, default="cuda", help="设备")
    parser.add_argument("--exp_name", type=str, default="paper_a_group", help="实验名前缀")
    parser.add_argument(
        "--mode",
        type=str,
        default="both",
        choices=["ours_ssl", "wo_ssl", "both"],
        help="A组模式：ours_ssl=原始自监督，wo_ssl=去掉对比自监督，both=依次跑两组",
    )
    args = parser.parse_args()

    modes: List[str] = [args.mode] if args.mode != "both" else ["wo_ssl", "ours_ssl"]
    all_results = []
    for mode in modes:
        result = _run_one_mode(args, mode)
        all_results.append(result)

    if len(all_results) > 1:
        merged_name = args.exp_name or "paper_a_group"
        merged_path = os.path.join(_PROJECT_ROOT, "experiments", "ablation", f"{merged_name}_group_a_results.json")
        os.makedirs(os.path.dirname(merged_path), exist_ok=True)
        with open(merged_path, "w", encoding="utf-8") as f:
            json.dump(all_results, f, indent=2, ensure_ascii=False)
        print(f"\nA组汇总结果已保存到: {merged_path}")


if __name__ == "__main__":
    main()
