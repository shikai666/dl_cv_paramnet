"""
DL-CV ParamNet 可视化工具

功能：
1. 轮廓可视化（叠加、并排比较）
2. 中间结果分析（Canny 边缘、闭运算）
3. 参数分布可视化
4. 评估结果可视化
5. 消融实验结果可视化

数学描述：
- 输入图像 I ∈ [0, 255]^{H×W×1}
- 预测轮廓 C ∈ {0, 1}^{H×W}
- CV 参数 P = [t_l, t_h, k_m]
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union
import json


def set_chinese_font():
    """设置中文字体"""
    plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans', 'Arial Unicode MS']
    plt.rcParams['axes.unicode_minus'] = False


def create_custom_colormap(name: str = 'contour') -> LinearSegmentedColormap:
    """
    创建自定义颜色映射
    
    Args:
        name: 颜色映射名称
    
    Returns:
        颜色映射对象
    """
    if name == 'contour':
        # 从透明到绿色
        colors = [(0, 0, 0, 0), (0, 1, 0, 0.7)]
        return LinearSegmentedColormap.from_list('contour', colors)
    elif name == 'edge':
        # 从透明到红色
        colors = [(0, 0, 0, 0), (1, 0, 0, 0.8)]
        return LinearSegmentedColormap.from_list('edge', colors)
    else:
        return plt.cm.viridis


class ContourVisualizer:
    """
    轮廓可视化器
    
    提供多种可视化方法
    """
    
    def __init__(
        self,
        figsize: Tuple[int, int] = (12, 8),
        dpi: int = 150,
        style: str = 'default'
    ):
        self.figsize = figsize
        self.dpi = dpi
        set_chinese_font()
        
        if style != 'default':
            plt.style.use(style)
    
    def visualize_single(
        self,
        image: np.ndarray,
        contour: np.ndarray,
        params: Optional[Dict[str, float]] = None,
        ground_truth: Optional[np.ndarray] = None,
        title: str = '',
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        单图像可视化
        
        Args:
            image: 原始灰度图像 [H, W]
            contour: 预测轮廓 [H, W]
            params: CV 参数字典
            ground_truth: 地面真值（可选）
            title: 标题
            save_path: 保存路径
        
        Returns:
            matplotlib Figure 对象
        """
        num_cols = 3 if ground_truth is None else 4
        fig, axes = plt.subplots(1, num_cols, figsize=(4 * num_cols, 4))
        
        # 原始图像
        axes[0].imshow(image, cmap='gray')
        axes[0].set_title('输入图像 $I$')
        axes[0].axis('off')
        
        # 预测轮廓
        axes[1].imshow(contour, cmap='gray')
        axes[1].set_title('预测轮廓 $C$')
        axes[1].axis('off')
        
        # 叠加显示
        axes[2].imshow(image, cmap='gray')
        contour_overlay = np.ma.masked_where(contour < 0.5, contour)
        axes[2].imshow(contour_overlay, cmap=create_custom_colormap('contour'), alpha=0.7)
        axes[2].set_title('轮廓叠加')
        axes[2].axis('off')
        
        # 地面真值比较
        if ground_truth is not None:
            axes[3].imshow(image, cmap='gray')
            # 预测（绿色）
            pred_overlay = np.ma.masked_where(contour < 0.5, contour)
            axes[3].imshow(pred_overlay, cmap=create_custom_colormap('contour'), alpha=0.5)
            # 真值（红色）
            gt_overlay = np.ma.masked_where(ground_truth < 0.5, ground_truth)
            axes[3].imshow(gt_overlay, cmap=create_custom_colormap('edge'), alpha=0.5)
            axes[3].set_title('预测 vs 真值')
            axes[3].axis('off')
            
            # 图例
            pred_patch = mpatches.Patch(color='green', alpha=0.7, label='预测')
            gt_patch = mpatches.Patch(color='red', alpha=0.7, label='真值')
            axes[3].legend(handles=[pred_patch, gt_patch], loc='upper right')
        
        # 添加参数信息
        if params:
            param_text = f"$t_l$={params.get('t_l', 0):.1f}, $t_h$={params.get('t_h', 0):.1f}, $k_m$={params.get('k_m', 0):.1f}"
            fig.text(0.5, 0.02, param_text, ha='center', fontsize=10)
        
        if title:
            fig.suptitle(title, fontsize=14)
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
            print(f"图像已保存到: {save_path}")
        
        return fig
    
    def visualize_intermediates(
        self,
        image: np.ndarray,
        intermediates: Dict[str, np.ndarray],
        params: Optional[Dict[str, float]] = None,
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        中间结果可视化
        
        显示 Canny 边缘、闭运算结果等中间步骤
        
        Args:
            image: 原始图像
            intermediates: 中间结果字典
            params: CV 参数
            save_path: 保存路径
        
        Returns:
            Figure 对象
        """
        # 预期的中间结果
        expected_keys = ['edges', 'gradient', 'closed', 'contours']
        available = [k for k in expected_keys if k in intermediates]
        
        num_plots = 1 + len(available)
        cols = min(4, num_plots)
        rows = (num_plots + cols - 1) // cols
        
        fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 4 * rows))
        if rows == 1:
            axes = [axes] if cols == 1 else axes
        else:
            axes = axes.flatten()
        
        # 原始图像
        axes[0].imshow(image, cmap='gray')
        axes[0].set_title('输入图像 $I$')
        axes[0].axis('off')
        
        # 中间结果
        titles = {
            'gradient': '梯度幅值 $G = \\sqrt{(\\nabla_x I)^2 + (\\nabla_y I)^2}$',
            'edges': 'Canny 边缘 $E$',
            'closed': '闭运算 $M = Closing(E, k_m)$',
            'contours': '最终轮廓 $C$'
        }
        
        for i, key in enumerate(available, 1):
            data = intermediates[key]
            if data.max() > 1.0:
                data = data / data.max()
            
            axes[i].imshow(data, cmap='gray')
            axes[i].set_title(titles.get(key, key))
            axes[i].axis('off')
        
        # 隐藏多余的子图
        for i in range(len(available) + 1, len(axes)):
            axes[i].axis('off')
        
        # 参数信息
        if params:
            param_text = f"预测参数: $t_l$={params.get('t_l', 0):.1f}, $t_h$={params.get('t_h', 0):.1f}, $k_m$={params.get('k_m', 0):.1f}"
            fig.text(0.5, 0.02, param_text, ha='center', fontsize=11)
        
        fig.suptitle('CV 执行模块中间结果分析', fontsize=14)
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def visualize_batch_comparison(
        self,
        images: List[np.ndarray],
        contours: List[np.ndarray],
        method_names: List[str] = None,
        titles: List[str] = None,
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        批量比较可视化
        
        并排显示多个方法的结果
        
        Args:
            images: 原始图像列表
            contours: 轮廓列表（每个图像可有多个方法的结果）
            method_names: 方法名称
            titles: 图像标题
            save_path: 保存路径
        """
        num_images = len(images)
        num_methods = len(contours[0]) if isinstance(contours[0], list) else 1
        
        if method_names is None:
            method_names = [f'方法 {i+1}' for i in range(num_methods)]
        
        fig, axes = plt.subplots(
            num_images, num_methods + 1,
            figsize=(4 * (num_methods + 1), 4 * num_images)
        )
        
        if num_images == 1:
            axes = axes[np.newaxis, :]
        
        for i, img in enumerate(images):
            # 原图
            axes[i, 0].imshow(img, cmap='gray')
            if titles and i < len(titles):
                axes[i, 0].set_title(titles[i])
            else:
                axes[i, 0].set_title(f'图像 {i+1}')
            axes[i, 0].axis('off')
            
            # 各方法结果
            current_contours = contours[i] if isinstance(contours[i], list) else [contours[i]]
            for j, (cnt, name) in enumerate(zip(current_contours, method_names)):
                axes[i, j+1].imshow(img, cmap='gray')
                cnt_overlay = np.ma.masked_where(cnt < 0.5, cnt)
                axes[i, j+1].imshow(cnt_overlay, cmap=create_custom_colormap('contour'), alpha=0.7)
                if i == 0:
                    axes[i, j+1].set_title(name)
                axes[i, j+1].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig


class ParameterVisualizer:
    """
    参数可视化器
    
    分析和可视化预测的 CV 参数分布
    """
    
    def __init__(self, figsize: Tuple[int, int] = (12, 4), dpi: int = 150):
        self.figsize = figsize
        self.dpi = dpi
        set_chinese_font()
    
    def plot_parameter_distribution(
        self,
        params_list: List[Dict[str, float]],
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制参数分布直方图
        
        Args:
            params_list: 参数字典列表
            save_path: 保存路径
        
        Returns:
            Figure 对象
        """
        # 提取参数
        t_l_values = [p.get('t_l', 0) for p in params_list]
        t_h_values = [p.get('t_h', 0) for p in params_list]
        k_m_values = [p.get('k_m', 0) for p in params_list]
        
        fig, axes = plt.subplots(1, 3, figsize=self.figsize)
        
        # t_l 分布
        axes[0].hist(t_l_values, bins=30, color='steelblue', edgecolor='white', alpha=0.8)
        axes[0].axvline(np.mean(t_l_values), color='red', linestyle='--', 
                        label=f'均值: {np.mean(t_l_values):.1f}')
        axes[0].set_xlabel('$t_l$ (低阈值)')
        axes[0].set_ylabel('频数')
        axes[0].set_title('低阈值分布\n$t_l = \\alpha_l \\cdot \\sigma(p_1) + \\beta_l$')
        axes[0].legend()
        
        # t_h 分布
        axes[1].hist(t_h_values, bins=30, color='darkorange', edgecolor='white', alpha=0.8)
        axes[1].axvline(np.mean(t_h_values), color='red', linestyle='--',
                        label=f'均值: {np.mean(t_h_values):.1f}')
        axes[1].set_xlabel('$t_h$ (高阈值)')
        axes[1].set_ylabel('频数')
        axes[1].set_title('高阈值分布\n$t_h = \\alpha_h \\cdot \\sigma(p_2) + \\beta_h + t_l$')
        axes[1].legend()
        
        # k_m 分布
        axes[2].hist(k_m_values, bins=range(3, 15), color='forestgreen', 
                     edgecolor='white', alpha=0.8, align='left')
        axes[2].axvline(np.mean(k_m_values), color='red', linestyle='--',
                        label=f'均值: {np.mean(k_m_values):.1f}')
        axes[2].set_xlabel('$k_m$ (内核大小)')
        axes[2].set_ylabel('频数')
        axes[2].set_title('内核大小分布\n$k_m = \\lfloor \\alpha_k \\cdot \\sigma(p_3) + \\beta_k \\rceil$')
        axes[2].legend()
        
        fig.suptitle('预测 CV 参数分布', fontsize=14, y=1.02)
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_parameter_correlation(
        self,
        params_list: List[Dict[str, float]],
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制参数相关性散点图
        
        Args:
            params_list: 参数字典列表
            save_path: 保存路径
        """
        t_l = [p.get('t_l', 0) for p in params_list]
        t_h = [p.get('t_h', 0) for p in params_list]
        k_m = [p.get('k_m', 0) for p in params_list]
        
        fig, axes = plt.subplots(1, 3, figsize=self.figsize)
        
        # t_l vs t_h
        axes[0].scatter(t_l, t_h, alpha=0.5, c='steelblue')
        # 添加 t_h > t_l 约束线
        x_line = np.linspace(min(t_l), max(t_l), 100)
        axes[0].plot(x_line, x_line + 50, 'r--', label='$t_h = t_l + 50$')
        axes[0].set_xlabel('$t_l$')
        axes[0].set_ylabel('$t_h$')
        axes[0].set_title('$t_l$ vs $t_h$')
        axes[0].legend()
        
        # t_l vs k_m
        axes[1].scatter(t_l, k_m, alpha=0.5, c='darkorange')
        axes[1].set_xlabel('$t_l$')
        axes[1].set_ylabel('$k_m$')
        axes[1].set_title('$t_l$ vs $k_m$')
        
        # t_h vs k_m
        axes[2].scatter(t_h, k_m, alpha=0.5, c='forestgreen')
        axes[2].set_xlabel('$t_h$')
        axes[2].set_ylabel('$k_m$')
        axes[2].set_title('$t_h$ vs $k_m$')
        
        fig.suptitle('CV 参数相关性分析', fontsize=14)
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_parameter_vs_metric(
        self,
        params_list: List[Dict[str, float]],
        metrics: List[float],
        metric_name: str = 'IoU',
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制参数与指标的关系
        
        Args:
            params_list: 参数列表
            metrics: 指标值列表
            metric_name: 指标名称
            save_path: 保存路径
        """
        t_l = [p.get('t_l', 0) for p in params_list]
        t_h = [p.get('t_h', 0) for p in params_list]
        k_m = [p.get('k_m', 0) for p in params_list]
        
        fig, axes = plt.subplots(1, 3, figsize=self.figsize)
        
        # t_l vs metric
        scatter1 = axes[0].scatter(t_l, metrics, c=k_m, cmap='viridis', alpha=0.6)
        axes[0].set_xlabel('$t_l$')
        axes[0].set_ylabel(metric_name)
        axes[0].set_title(f'$t_l$ vs {metric_name}')
        plt.colorbar(scatter1, ax=axes[0], label='$k_m$')
        
        # t_h vs metric
        scatter2 = axes[1].scatter(t_h, metrics, c=k_m, cmap='viridis', alpha=0.6)
        axes[1].set_xlabel('$t_h$')
        axes[1].set_ylabel(metric_name)
        axes[1].set_title(f'$t_h$ vs {metric_name}')
        plt.colorbar(scatter2, ax=axes[1], label='$k_m$')
        
        # k_m vs metric
        axes[2].boxplot([
            [m for m, k in zip(metrics, k_m) if int(k) == v]
            for v in sorted(set(int(k) for k in k_m))
        ], labels=[str(v) for v in sorted(set(int(k) for k in k_m))])
        axes[2].set_xlabel('$k_m$')
        axes[2].set_ylabel(metric_name)
        axes[2].set_title(f'$k_m$ vs {metric_name}')
        
        fig.suptitle(f'CV 参数与 {metric_name} 关系分析', fontsize=14)
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig


class MetricsVisualizer:
    """
    评估指标可视化器
    """
    
    def __init__(self, figsize: Tuple[int, int] = (10, 6), dpi: int = 150):
        self.figsize = figsize
        self.dpi = dpi
        set_chinese_font()
    
    def plot_metrics_comparison(
        self,
        results: Dict[str, Dict[str, float]],
        metrics: List[str] = ['bf_f1', 'iou', 'dice'],
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制不同方法的指标对比
        
        Args:
            results: {方法名: {指标名: 值}}
            metrics: 要显示的指标列表
            save_path: 保存路径
        """
        methods = list(results.keys())
        x = np.arange(len(metrics))
        width = 0.8 / len(methods)
        
        fig, ax = plt.subplots(figsize=self.figsize)
        
        colors = plt.cm.Set2(np.linspace(0, 1, len(methods)))
        
        for i, (method, color) in enumerate(zip(methods, colors)):
            values = [results[method].get(m, 0) for m in metrics]
            offset = (i - len(methods) / 2 + 0.5) * width
            bars = ax.bar(x + offset, values, width, label=method, color=color)
            
            # 添加数值标签
            for bar, val in zip(bars, values):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                       f'{val:.3f}', ha='center', va='bottom', fontsize=8)
        
        metric_labels = {
            'bf_f1': 'BF-Score (F1)',
            'bf_precision': 'BF-Precision',
            'bf_recall': 'BF-Recall',
            'iou': 'IoU',
            'dice': 'Dice',
            'rec_total': '重建误差'
        }
        
        ax.set_ylabel('分数')
        ax.set_xticks(x)
        ax.set_xticklabels([metric_labels.get(m, m) for m in metrics])
        ax.legend()
        ax.set_ylim(0, 1.1)
        ax.set_title('方法对比评估')
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_training_curves(
        self,
        history: Dict[str, List[float]],
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制训练曲线
        
        Args:
            history: {指标名: [值列表]}
            save_path: 保存路径
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        axes = axes.flatten()
        
        # 总损失
        if 'train_loss' in history or 'val_loss' in history:
            ax = axes[0]
            if 'train_loss' in history:
                ax.plot(history['train_loss'], label='训练损失', color='steelblue')
            if 'val_loss' in history:
                ax.plot(history['val_loss'], label='验证损失', color='darkorange')
            ax.set_xlabel('Epoch')
            ax.set_ylabel('损失 $\\mathcal{L}$')
            ax.set_title('总损失曲线\n$\\mathcal{L} = \\lambda_1 \\mathcal{L}_{cont} + \\lambda_2 \\mathcal{L}_{rec}$')
            ax.legend()
            ax.grid(True, alpha=0.3)
        
        # 对比损失
        if 'contrastive_loss' in history:
            ax = axes[1]
            ax.plot(history['contrastive_loss'], color='forestgreen')
            ax.set_xlabel('Epoch')
            ax.set_ylabel('$\\mathcal{L}_{cont}$')
            ax.set_title('对比损失 (NT-Xent)')
            ax.grid(True, alpha=0.3)
        
        # 重建损失
        if 'reconstruction_loss' in history:
            ax = axes[2]
            ax.plot(history['reconstruction_loss'], color='crimson')
            ax.set_xlabel('Epoch')
            ax.set_ylabel('$\\mathcal{L}_{rec}$')
            ax.set_title('重建损失\n$||C - S(I)||_1 + \\gamma ||\\nabla C - \\nabla I||_2^2$')
            ax.grid(True, alpha=0.3)
        
        # 验证指标
        val_metrics = ['val_iou', 'val_dice', 'val_bf_f1']
        ax = axes[3]
        for metric in val_metrics:
            if metric in history:
                label = metric.replace('val_', '').upper()
                ax.plot(history[metric], label=label)
        ax.set_xlabel('Epoch')
        ax.set_ylabel('分数')
        ax.set_title('验证指标')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        fig.suptitle('训练过程监控', fontsize=14, y=1.02)
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_ablation_results(
        self,
        ablation_results: Dict[str, Dict[str, float]],
        base_config: str = 'Full Model',
        save_path: Optional[str] = None
    ) -> plt.Figure:
        """
        绘制消融实验结果
        
        Args:
            ablation_results: {配置名: {指标名: 值}}
            base_config: 基准配置名称
            save_path: 保存路径
        """
        configs = list(ablation_results.keys())
        metrics = ['bf_f1', 'iou', 'dice']
        
        fig, ax = plt.subplots(figsize=self.figsize)
        
        x = np.arange(len(configs))
        width = 0.25
        
        colors = ['steelblue', 'darkorange', 'forestgreen']
        
        for i, (metric, color) in enumerate(zip(metrics, colors)):
            values = [ablation_results[c].get(metric, 0) for c in configs]
            offset = (i - 1) * width
            bars = ax.bar(x + offset, values, width, label=metric.upper(), color=color)
            
            # 添加数值
            for bar, val in zip(bars, values):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                       f'{val:.3f}', ha='center', va='bottom', fontsize=8)
        
        # 标记基准配置
        if base_config in configs:
            base_idx = configs.index(base_config)
            ax.axvline(base_idx, color='red', linestyle='--', alpha=0.5, label='基准配置')
        
        ax.set_ylabel('分数')
        ax.set_xticks(x)
        ax.set_xticklabels(configs, rotation=45, ha='right')
        ax.legend(loc='upper right')
        ax.set_ylim(0, 1.1)
        ax.set_title('消融实验结果')
        
        plt.tight_layout()
        
        if save_path:
            fig.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig


def generate_visualization_report(
    output_dir: str,
    images: List[np.ndarray],
    contours: List[np.ndarray],
    params_list: List[Dict[str, float]],
    metrics: Optional[Dict[str, float]] = None,
    ground_truths: Optional[List[np.ndarray]] = None,
    intermediates_list: Optional[List[Dict[str, np.ndarray]]] = None
) -> None:
    """
    生成完整的可视化报告
    
    Args:
        output_dir: 输出目录
        images: 图像列表
        contours: 轮廓列表
        params_list: 参数列表
        metrics: 评估指标
        ground_truths: 地面真值列表
        intermediates_list: 中间结果列表
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"生成可视化报告到: {output_dir}")
    
    # 初始化可视化器
    contour_viz = ContourVisualizer()
    param_viz = ParameterVisualizer()
    metrics_viz = MetricsVisualizer()
    
    # 1. 轮廓可视化（选择前 6 张）
    print("  生成轮廓可视化...")
    for i in range(min(6, len(images))):
        gt = ground_truths[i] if ground_truths else None
        contour_viz.visualize_single(
            images[i], contours[i],
            params=params_list[i] if i < len(params_list) else None,
            ground_truth=gt,
            title=f'样本 {i+1}',
            save_path=str(output_dir / f'contour_sample_{i+1}.png')
        )
    
    # 2. 中间结果可视化
    if intermediates_list:
        print("  生成中间结果可视化...")
        for i in range(min(3, len(intermediates_list))):
            contour_viz.visualize_intermediates(
                images[i], intermediates_list[i],
                params=params_list[i] if i < len(params_list) else None,
                save_path=str(output_dir / f'intermediates_sample_{i+1}.png')
            )
    
    # 3. 参数分布
    if params_list:
        print("  生成参数分布图...")
        param_viz.plot_parameter_distribution(
            params_list,
            save_path=str(output_dir / 'parameter_distribution.png')
        )
        param_viz.plot_parameter_correlation(
            params_list,
            save_path=str(output_dir / 'parameter_correlation.png')
        )
    
    # 4. 生成 HTML 报告
    print("  生成 HTML 报告...")
    generate_html_report(output_dir, params_list, metrics)
    
    print(f"报告生成完成: {output_dir}")


def generate_html_report(
    output_dir: Path,
    params_list: List[Dict[str, float]],
    metrics: Optional[Dict[str, float]] = None
) -> None:
    """
    生成 HTML 报告
    """
    html_content = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>DL-CV ParamNet 可视化报告</title>
    <style>
        body { font-family: 'SimHei', Arial, sans-serif; margin: 20px; }
        h1, h2 { color: #333; }
        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
        .metrics-table { border-collapse: collapse; width: 100%; max-width: 600px; }
        .metrics-table th, .metrics-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .metrics-table th { background-color: #f4f4f4; }
        .image-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .image-card { border: 1px solid #ddd; padding: 10px; border-radius: 5px; }
        .image-card img { max-width: 100%; height: auto; }
        .formula { font-style: italic; color: #666; }
    </style>
</head>
<body>
    <h1>DL-CV ParamNet 可视化报告</h1>
    
    <div class="section">
        <h2>1. 项目简介</h2>
        <p>DL-CV ParamNet 是一个基于自监督对比学习的深度学习控制 CV 参数化架构，
           用于里耶秦简灰度图像的文字轮廓检测。</p>
        <p class="formula">数学框架: f<sub>θ</sub>: ℝ<sup>H×W×1</sup> → ℝ<sup>D</sup>, 
           g<sub>φ</sub>: ℝ<sup>D</sup> → ℝ<sup>K</sup></p>
    </div>
"""
    
    # 添加指标部分
    if metrics:
        html_content += """
    <div class="section">
        <h2>2. 评估指标</h2>
        <table class="metrics-table">
            <tr><th>指标</th><th>值</th></tr>
"""
        for key, value in metrics.items():
            html_content += f"            <tr><td>{key}</td><td>{value:.4f}</td></tr>\n"
        html_content += """
        </table>
    </div>
"""
    
    # 添加参数统计
    if params_list:
        t_l_mean = np.mean([p.get('t_l', 0) for p in params_list])
        t_h_mean = np.mean([p.get('t_h', 0) for p in params_list])
        k_m_mean = np.mean([p.get('k_m', 0) for p in params_list])
        
        html_content += f"""
    <div class="section">
        <h2>3. CV 参数统计</h2>
        <table class="metrics-table">
            <tr><th>参数</th><th>均值</th><th>公式</th></tr>
            <tr><td>低阈值 t<sub>l</sub></td><td>{t_l_mean:.2f}</td>
                <td>t<sub>l</sub> = α<sub>l</sub> · σ(p<sub>1</sub>) + β<sub>l</sub></td></tr>
            <tr><td>高阈值 t<sub>h</sub></td><td>{t_h_mean:.2f}</td>
                <td>t<sub>h</sub> = α<sub>h</sub> · σ(p<sub>2</sub>) + β<sub>h</sub> + t<sub>l</sub></td></tr>
            <tr><td>内核大小 k<sub>m</sub></td><td>{k_m_mean:.2f}</td>
                <td>k<sub>m</sub> = ⌊α<sub>k</sub> · σ(p<sub>3</sub>) + β<sub>k</sub>⌉</td></tr>
        </table>
    </div>
"""
    
    # 添加图像部分
    html_content += """
    <div class="section">
        <h2>4. 轮廓可视化</h2>
        <div class="image-grid">
"""
    
    # 查找输出目录中的图像
    for i in range(1, 7):
        img_path = f'contour_sample_{i}.png'
        if (output_dir / img_path).exists():
            html_content += f"""
            <div class="image-card">
                <img src="{img_path}" alt="样本 {i}">
                <p>样本 {i}</p>
            </div>
"""
    
    html_content += """
        </div>
    </div>
    
    <div class="section">
        <h2>5. 参数分布</h2>
        <div class="image-grid">
            <div class="image-card">
                <img src="parameter_distribution.png" alt="参数分布">
            </div>
            <div class="image-card">
                <img src="parameter_correlation.png" alt="参数相关性">
            </div>
        </div>
    </div>
</body>
</html>
"""
    
    # 保存 HTML
    html_path = output_dir / 'report.html'
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='DL-CV ParamNet 可视化工具')
    
    parser.add_argument('--mode', type=str, default='single',
                        choices=['single', 'batch', 'params', 'report'],
                        help='可视化模式')
    parser.add_argument('--input', type=str, help='输入图像路径')
    parser.add_argument('--contour', type=str, help='轮廓掩码路径')
    parser.add_argument('--params_file', type=str, help='参数 JSON 文件')
    parser.add_argument('--output', type=str, default='./visualizations',
                        help='输出目录')
    parser.add_argument('--ground_truth', type=str, help='地面真值路径')
    
    args = parser.parse_args()
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    if args.mode == 'single' and args.input and args.contour:
        import cv2
        
        image = cv2.imread(args.input, cv2.IMREAD_GRAYSCALE)
        contour = cv2.imread(args.contour, cv2.IMREAD_GRAYSCALE)
        
        gt = None
        if args.ground_truth:
            gt = cv2.imread(args.ground_truth, cv2.IMREAD_GRAYSCALE)
        
        params = None
        if args.params_file:
            with open(args.params_file, 'r') as f:
                params = json.load(f)
        
        viz = ContourVisualizer()
        viz.visualize_single(
            image, contour, params, gt,
            save_path=str(output_dir / 'visualization.png')
        )
    
    elif args.mode == 'params' and args.params_file:
        with open(args.params_file, 'r') as f:
            params_dict = json.load(f)
        
        if isinstance(params_dict, dict) and not all(isinstance(v, dict) for v in params_dict.values()):
            params_list = [params_dict]
        else:
            params_list = list(params_dict.values())
        
        viz = ParameterVisualizer()
        viz.plot_parameter_distribution(
            params_list,
            save_path=str(output_dir / 'parameter_distribution.png')
        )
        viz.plot_parameter_correlation(
            params_list,
            save_path=str(output_dir / 'parameter_correlation.png')
        )
    
    else:
        print("请提供必要的参数。使用 --help 查看帮助。")


if __name__ == '__main__':
    main()
