import cv2
import os
from glob import glob


def canny_fixed_threshold_experiment(
    image_path,
    output_root,
    blur_ksize=3,
    canny_low=50,
    canny_high=150,
    morph_ksize=3,
    min_area=20,
    min_width=3,
    min_height=3,
    max_width_ratio=0.9,
    dilate_iter=1,
    debug=False
):
    os.makedirs(output_root, exist_ok=True)

    # 读取灰度图
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"[跳过] 无法读取图像: {image_path}")
        return None

    h, w = img.shape

    # 保证核大小是奇数
    if blur_ksize % 2 == 0:
        blur_ksize += 1
    if morph_ksize % 2 == 0:
        morph_ksize += 1

    # 1. 高斯滤波
    blur = cv2.GaussianBlur(img, (blur_ksize, blur_ksize), 0)

    # 2. Canny 边缘检测
    edges = cv2.Canny(blur, canny_low, canny_high)

    # 3. 闭运算
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (morph_ksize, morph_ksize))
    closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

    # 4. 轻微膨胀
    dilate_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    binary = cv2.dilate(closed, dilate_kernel, iterations=dilate_iter)

    # 5. 提取外轮廓
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # 6. 画框
    vis_boxes = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    candidate_boxes = []

    for cnt in contours:
        x, y, bw, bh = cv2.boundingRect(cnt)
        area = bw * bh

        if area < min_area:
            continue
        if bw < min_width or bh < min_height:
            continue
        if bw > int(w * max_width_ratio):
            continue

        candidate_boxes.append((x, y, bw, bh))
        cv2.rectangle(vis_boxes, (x, y), (x + bw, y + bh), (0, 255, 0), 1)

    # 按 y 坐标排序
    candidate_boxes = sorted(candidate_boxes, key=lambda b: (b[1], b[0]))

    # 文件名
    base_name = os.path.splitext(os.path.basename(image_path))[0]

    # 直接保存到同一个输出目录
    box_img_path = os.path.join(output_root, f"{base_name}_boxes.png")
    txt_path = os.path.join(output_root, f"{base_name}_boxes.txt")

    cv2.imwrite(box_img_path, vis_boxes)

    with open(txt_path, "w", encoding="utf-8") as f:
        for i, (x, y, bw, bh) in enumerate(candidate_boxes):
            f.write(f"{i+1}: x={x}, y={y}, w={bw}, h={bh}\n")

    if debug:
        print(f"[完成] {base_name} -> {len(candidate_boxes)} 个候选框")

    return {
        "name": base_name,
        "num_boxes": len(candidate_boxes),
        "boxes": candidate_boxes
    }


def batch_run(
    input_dir,
    output_root,
    exts=("*.bmp", "*.png", "*.jpg", "*.jpeg", "*.tif", "*.tiff"),
    blur_ksize=3,
    canny_low=50,
    canny_high=150,
    morph_ksize=3,
    min_area=20,
    min_width=3,
    min_height=3,
    max_width_ratio=0.9,
    dilate_iter=1,
    debug=True
):
    os.makedirs(output_root, exist_ok=True)

    image_paths = []
    for ext in exts:
        image_paths.extend(glob(os.path.join(input_dir, ext)))

    image_paths = sorted(image_paths)

    if len(image_paths) == 0:
        print(f"[提示] 文件夹中没有找到图片: {input_dir}")
        return

    summary_path = os.path.join(output_root, "summary.csv")
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("image_name,num_boxes\n")

        for image_path in image_paths:
            result = canny_fixed_threshold_experiment(
                image_path=image_path,
                output_root=output_root,
                blur_ksize=blur_ksize,
                canny_low=canny_low,
                canny_high=canny_high,
                morph_ksize=morph_ksize,
                min_area=min_area,
                min_width=min_width,
                min_height=min_height,
                max_width_ratio=max_width_ratio,
                dilate_iter=dilate_iter,
                debug=debug
            )

            if result is not None:
                f.write(f"{result['name']},{result['num_boxes']}\n")

    print("\n全部完成")
    print(f"输入目录: {input_dir}")
    print(f"输出目录: {output_root}")
    print(f"汇总文件: {summary_path}")


if __name__ == "__main__":
    input_dir = r"/home/sk/dl_cv_paramnet/data/val/images"
    output_root = r"/home/sk/dl_cv_paramnet/batch_canny_results"

    batch_run(
        input_dir=input_dir,
        output_root=output_root,
        blur_ksize=3,
        canny_low=50,
        canny_high=150,
        morph_ksize=3,
        min_area=20,
        min_width=3,
        min_height=3,
        max_width_ratio=0.9,
        dilate_iter=1,
        debug=True
    )
