"""
评估指标模块

包含：
1. 边界 F1 分数 (BF-Score)
2. 交并比 (IoU)
3. Dice 系数
4. 伪地面真值重建误差
5. 计算效率指标
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple, Optional, List
import time
from scipy import ndimage


class BoundaryF1Score:
    """
    边界 F1 分数 (Boundary F1 Score, BF-Score)
    
    衡量预测轮廓掩码与地面真值的边缘匹配精度
    
    公式：
    - Precision: P = |∂C ∩ ∂G_δ| / |∂C|
    - Recall: R = |∂C ∩ ∂G_δ| / |∂G|
    - F1 = 2 · P · R / (P + R)
    
    其中 ∂G_δ 是地面真值边界扩展 δ 像素的集合
    """
    
    def __init__(self, tolerance: int = 2):
        """
        Args:
            tolerance: 边界匹配容差（像素）δ
        """
        self.tolerance = tolerance
    
    def extract_boundary(self, mask: np.ndarray) -> np.ndarray:
        """
        提取二值掩码的边界
        
        使用形态学梯度：边界 = 膨胀 - 腐蚀
        """
        kernel = np.ones((3, 3), dtype=np.uint8)
        dilated = ndimage.binary_dilation(mask, kernel)
        eroded = ndimage.binary_erosion(mask, kernel)
        boundary = dilated.astype(np.float32) - eroded.astype(np.float32)
        return boundary
    
    def dilate_boundary(self, boundary: np.ndarray, delta: int) -> np.ndarray:
        """
        扩展边界 δ 像素
        """
        if delta == 0:
            return boundary
        
        kernel = np.ones((2*delta+1, 2*delta+1), dtype=np.uint8)
        dilated = ndimage.binary_dilation(boundary > 0, kernel)
        return dilated.astype(np.float32)
    
    def __call__(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        threshold: float = 0.5
    ) -> Dict[str, float]:
        """
        计算 BF-Score
        
        Args:
            pred: 预测轮廓 ∈ [0, 1]^{B×1×H×W}
            target: 地面真值 ∈ {0, 1}^{B×1×H×W}
            threshold: 二值化阈值
        
        Returns:
            包含 precision, recall, f1 的字典
        """
        # 转换为 numpy
        pred_np = (pred > threshold).float().cpu().numpy()
        target_np = target.cpu().numpy()
        
        batch_size = pred_np.shape[0]
        
        precisions = []
        recalls = []
        f1_scores = []
        
        for i in range(batch_size):
            pred_mask = pred_np[i, 0]
            target_mask = target_np[i, 0]
            
            # 提取边界
            pred_boundary = self.extract_boundary(pred_mask > 0.5)
            target_boundary = self.extract_boundary(target_mask > 0.5)
            
            # 扩展地面真值边界
            target_boundary_dilated = self.dilate_boundary(target_boundary, self.tolerance)
            pred_boundary_dilated = self.dilate_boundary(pred_boundary, self.tolerance)
            
            # 计算匹配
            pred_boundary_points = pred_boundary.sum()
            target_boundary_points = target_boundary.sum()
            
            if pred_boundary_points == 0 or target_boundary_points == 0:
                precisions.append(0.0)
                recalls.append(0.0)
                f1_scores.append(0.0)
                continue
            
            # Precision: 预测边界中有多少在地面真值边界附近
            matched_pred = (pred_boundary * target_boundary_dilated).sum()
            precision = matched_pred / pred_boundary_points
            
            # Recall: 地面真值边界中有多少在预测边界附近
            matched_target = (target_boundary * pred_boundary_dilated).sum()
            recall = matched_target / target_boundary_points
            
            # F1
            if precision + recall > 0:
                f1 = 2 * precision * recall / (precision + recall)
            else:
                f1 = 0.0
            
            precisions.append(precision)
            recalls.append(recall)
            f1_scores.append(f1)
        
        return {
            'precision': np.mean(precisions),
            'recall': np.mean(recalls),
            'f1': np.mean(f1_scores)
        }


class IoU:
    """
    交并比 (Intersection over Union)
    
    IoU = |C ∩ G| / |C ∪ G|
    """
    
    def __call__(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        threshold: float = 0.5,
        smooth: float = 1e-6
    ) -> float:
        """
        计算 IoU
        
        Args:
            pred: 预测轮廓 ∈ [0, 1]^{B×1×H×W}
            target: 地面真值 ∈ {0, 1}^{B×1×H×W}
            threshold: 二值化阈值
            smooth: 平滑项防止除零
        
        Returns:
            IoU 值
        """
        # 二值化预测
        pred_binary = (pred > threshold).float()
        target_binary = (target > threshold).float()
        
        # 计算交集和并集
        intersection = (pred_binary * target_binary).sum()
        union = pred_binary.sum() + target_binary.sum() - intersection
        
        iou = (intersection + smooth) / (union + smooth)
        
        return iou.item()


class DiceCoefficient:
    """
    Dice 系数 (Dice Similarity Coefficient)
    
    Dice = 2 · |C ∩ G| / (|C| + |G|)
    """
    
    def __call__(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        threshold: float = 0.5,
        smooth: float = 1e-6
    ) -> float:
        """
        计算 Dice 系数
        """
        pred_binary = (pred > threshold).float()
        target_binary = (target > threshold).float()
        
        intersection = (pred_binary * target_binary).sum()
        
        dice = (2 * intersection + smooth) / (pred_binary.sum() + target_binary.sum() + smooth)
        
        return dice.item()


class ReconstructionError:
    """
    伪地面真值重建误差
    
    Error_rec = (1/N) Σ_b [||C_b - S(I_b)||_1 + γ ||∇C_b - ∇I_b||_2^2]
    """
    
    def __init__(self, gamma: float = 0.5):
        self.gamma = gamma
        
        # Sobel 算子
        self.sobel_x = torch.tensor([
            [-1, 0, 1],
            [-2, 0, 2],
            [-1, 0, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        
        self.sobel_y = torch.tensor([
            [-1, -2, -1],
            [0, 0, 0],
            [1, 2, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
    
    def compute_sobel_pseudo_gt(
        self,
        x: torch.Tensor,
        threshold: float = 0.2
    ) -> torch.Tensor:
        """计算 Sobel 伪地面真值"""
        device = x.device
        sobel_x = self.sobel_x.to(device)
        sobel_y = self.sobel_y.to(device)
        
        x_padded = F.pad(x, (1, 1, 1, 1), mode='replicate')
        grad_x = F.conv2d(x_padded, sobel_x)
        grad_y = F.conv2d(x_padded, sobel_y)
        
        grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        
        # 归一化
        batch_size = grad_mag.shape[0]
        grad_mag_flat = grad_mag.view(batch_size, -1)
        grad_max = grad_mag_flat.max(dim=1, keepdim=True)[0].view(batch_size, 1, 1, 1)
        grad_norm = grad_mag / (grad_max + 1e-8)
        
        pseudo_gt = (grad_norm > threshold).float()
        
        return pseudo_gt
    
    def compute_gradient(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """计算图像梯度"""
        device = x.device
        sobel_x = self.sobel_x.to(device)
        sobel_y = self.sobel_y.to(device)
        
        x_padded = F.pad(x, (1, 1, 1, 1), mode='replicate')
        grad_x = F.conv2d(x_padded, sobel_x)
        grad_y = F.conv2d(x_padded, sobel_y)
        
        return grad_x, grad_y
    
    def __call__(
        self,
        pred_contours: torch.Tensor,
        input_images: torch.Tensor,
        sobel_threshold: float = 0.2
    ) -> Dict[str, float]:
        """
        计算重建误差
        
        Args:
            pred_contours: 预测轮廓
            input_images: 输入图像
            sobel_threshold: Sobel 边缘阈值
        
        Returns:
            包含各误差分量的字典
        """
        # 计算伪地面真值
        pseudo_gt = self.compute_sobel_pseudo_gt(input_images, sobel_threshold)
        
        # L1 误差
        l1_error = F.l1_loss(pred_contours, pseudo_gt).item()
        
        # 梯度误差
        pred_grad_x, pred_grad_y = self.compute_gradient(pred_contours)
        gt_grad_x, gt_grad_y = self.compute_gradient(input_images)
        
        grad_error_x = F.mse_loss(pred_grad_x, gt_grad_x).item()
        grad_error_y = F.mse_loss(pred_grad_y, gt_grad_y).item()
        grad_error = grad_error_x + grad_error_y
        
        # 总误差
        total_error = l1_error + self.gamma * grad_error
        
        return {
            'total': total_error,
            'l1': l1_error,
            'gradient': grad_error
        }


class ComputationalEfficiency:
    """
    计算效率指标
    
    测量推理时间和参数量
    """
    
    def __init__(self, device: str = 'cuda'):
        self.device = device
    
    def measure_inference_time(
        self,
        model: nn.Module,
        input_shape: Tuple[int, ...] = (1, 1, 256, 256),
        num_runs: int = 100,
        warmup_runs: int = 10
    ) -> Dict[str, float]:
        """
        测量推理时间
        
        Args:
            model: 模型
            input_shape: 输入形状
            num_runs: 测试运行次数
            warmup_runs: 预热运行次数
        
        Returns:
            包含推理时间统计的字典
        """
        model.eval()
        device = next(model.parameters()).device
        
        # 创建测试输入
        x = torch.randn(input_shape).to(device)
        
        # 预热
        with torch.no_grad():
            for _ in range(warmup_runs):
                _ = model(x)
        
        # 同步 CUDA
        if 'cuda' in str(device):
            torch.cuda.synchronize()
        
        # 测量时间
        times = []
        with torch.no_grad():
            for _ in range(num_runs):
                start = time.time()
                _ = model(x)
                
                if 'cuda' in str(device):
                    torch.cuda.synchronize()
                
                end = time.time()
                times.append(end - start)
        
        times = np.array(times)
        
        return {
            'mean': times.mean(),
            'std': times.std(),
            'min': times.min(),
            'max': times.max(),
            'fps': 1.0 / times.mean()
        }
    
    def count_parameters(self, model: nn.Module) -> Dict[str, int]:
        """
        统计模型参数量
        """
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        
        return {
            'total': total_params,
            'trainable': trainable_params,
            'non_trainable': total_params - trainable_params
        }


class MetricsCalculator:
    """
    综合指标计算器
    
    整合所有评估指标
    """
    
    def __init__(
        self,
        boundary_tolerance: int = 2,
        sobel_threshold: float = 0.2,
        gamma: float = 0.5
    ):
        self.bf_score = BoundaryF1Score(tolerance=boundary_tolerance)
        self.iou = IoU()
        self.dice = DiceCoefficient()
        self.rec_error = ReconstructionError(gamma=gamma)
        self.efficiency = ComputationalEfficiency()
        self.sobel_threshold = sobel_threshold
    
    def compute_all(
        self,
        pred: torch.Tensor,
        target: Optional[torch.Tensor],
        input_images: torch.Tensor,
        threshold: float = 0.5
    ) -> Dict[str, float]:
        """
        计算所有指标
        
        Args:
            pred: 预测轮廓
            target: 地面真值（如果有）
            input_images: 输入图像
            threshold: 二值化阈值
        
        Returns:
            所有指标的字典
        """
        results = {}
        
        # 如果有地面真值，计算监督指标
        if target is not None:
            # BF-Score
            bf_results = self.bf_score(pred, target, threshold)
            results['bf_precision'] = bf_results['precision']
            results['bf_recall'] = bf_results['recall']
            results['bf_f1'] = bf_results['f1']
            
            # IoU
            results['iou'] = self.iou(pred, target, threshold)
            
            # Dice
            results['dice'] = self.dice(pred, target, threshold)
        
        # 重建误差（无监督指标）
        rec_results = self.rec_error(pred, input_images, self.sobel_threshold)
        results['rec_total'] = rec_results['total']
        results['rec_l1'] = rec_results['l1']
        results['rec_gradient'] = rec_results['gradient']
        
        return results
    
    def compute_model_efficiency(
        self,
        model: nn.Module,
        input_shape: Tuple[int, ...] = (1, 1, 256, 256)
    ) -> Dict[str, float]:
        """
        计算模型效率指标
        """
        # 参数量
        params = self.efficiency.count_parameters(model)
        
        # 推理时间
        timing = self.efficiency.measure_inference_time(model, input_shape)
        
        return {
            'total_params': params['total'],
            'trainable_params': params['trainable'],
            'inference_time_mean': timing['mean'],
            'inference_time_std': timing['std'],
            'fps': timing['fps']
        }


def evaluate_model(
    model: nn.Module,
    dataloader,
    device: str = 'cuda',
    has_ground_truth: bool = False,
    sobel_threshold: float = 0.2
) -> Dict[str, float]:
    """
    评估模型
    
    Args:
        model: 模型
        dataloader: 数据加载器
        device: 设备
        has_ground_truth: 是否有地面真值
        sobel_threshold: Sobel 阈值
    
    Returns:
        评估结果字典
    """
    model.eval()
    metrics = MetricsCalculator(sobel_threshold=sobel_threshold)
    
    all_results = {
        'rec_total': [],
        'rec_l1': [],
        'rec_gradient': []
    }
    
    if has_ground_truth:
        all_results.update({
            'bf_precision': [],
            'bf_recall': [],
            'bf_f1': [],
            'iou': [],
            'dice': []
        })
    
    with torch.no_grad():
        for batch in dataloader:
            if len(batch) == 2:
                images, _ = batch
                targets = None
            elif len(batch) == 3:
                images, targets, _ = batch
            else:
                images = batch[0]
                targets = batch[1] if len(batch) > 1 and has_ground_truth else None
            
            images = images.to(device)
            if targets is not None:
                targets = targets.to(device)
            
            # 前向传播
            outputs = model(images)
            pred_contours = outputs['contours']
            
            # 计算指标
            batch_results = metrics.compute_all(
                pred_contours,
                targets,
                images
            )
            
            for key, value in batch_results.items():
                if key in all_results:
                    all_results[key].append(value)
    
    # 计算平均值
    final_results = {
        key: np.mean(values) for key, values in all_results.items()
    }
    
    return final_results


if __name__ == "__main__":
    # 测试代码
    print("测试评估指标模块...")
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = 4
    
    # 创建测试数据
    pred = torch.rand(batch_size, 1, 64, 64).to(device)
    target = (torch.rand(batch_size, 1, 64, 64) > 0.7).float().to(device)
    input_images = torch.rand(batch_size, 1, 64, 64).to(device)
    
    # 测试 BF-Score
    print("\n测试 BF-Score...")
    bf_score = BoundaryF1Score(tolerance=2)
    bf_results = bf_score(pred, target)
    print(f"  Precision: {bf_results['precision']:.4f}")
    print(f"  Recall: {bf_results['recall']:.4f}")
    print(f"  F1: {bf_results['f1']:.4f}")
    
    # 测试 IoU
    print("\n测试 IoU...")
    iou_metric = IoU()
    iou_value = iou_metric(pred, target)
    print(f"  IoU: {iou_value:.4f}")
    
    # 测试 Dice
    print("\n测试 Dice...")
    dice_metric = DiceCoefficient()
    dice_value = dice_metric(pred, target)
    print(f"  Dice: {dice_value:.4f}")
    
    # 测试重建误差
    print("\n测试重建误差...")
    rec_error = ReconstructionError(gamma=0.5)
    rec_results = rec_error(pred, input_images)
    print(f"  Total Error: {rec_results['total']:.4f}")
    print(f"  L1 Error: {rec_results['l1']:.4f}")
    print(f"  Gradient Error: {rec_results['gradient']:.4f}")
    
    # 测试综合计算器
    print("\n测试综合指标计算器...")
    calculator = MetricsCalculator()
    all_metrics = calculator.compute_all(pred, target, input_images)
    print("  所有指标:")
    for key, value in all_metrics.items():
        print(f"    {key}: {value:.4f}")
    
    print("\n评估指标模块测试完成！")
