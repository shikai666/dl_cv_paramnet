"""
CV 执行模块 (CV Execution Module) - 完整修复版

【核心修复】
1. k_m 梯度：使用多尺度 kernel 加权融合 ✓
2. t_h 梯度：使用归一化双阈值，保证 t_h 在任何值下都有梯度 ✓

问题分析：
原来的 Canny 实现：
  strong = sigmoid((grad - t_h) / temp)
  当 t_h 很大时，(grad - t_h) 是大负数，sigmoid' ≈ 0，梯度消失

修复方案：
  使用归一化公式：normalized = (grad - t_l) / (t_h - t_l)
  这样 ∂normalized/∂t_h = -normalized / (t_h - t_l)，梯度不会消失
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Tuple
import math


class SobelFilter(nn.Module):
    """Sobel 梯度滤波器"""

    def __init__(self):
        super().__init__()
        sobel_x = torch.tensor(
            [[-1, 0, 1],
             [-2, 0, 2],
             [-1, 0, 1]], dtype=torch.float32
        ).unsqueeze(0).unsqueeze(0)

        sobel_y = torch.tensor(
            [[-1, -2, -1],
             [0, 0, 0],
             [1, 2, 1]], dtype=torch.float32
        ).unsqueeze(0).unsqueeze(0)

        self.register_buffer("sobel_x", sobel_x)
        self.register_buffer("sobel_y", sobel_y)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x_padded = F.pad(x, (1, 1, 1, 1), mode="replicate")
        grad_x = F.conv2d(x_padded, self.sobel_x)
        grad_y = F.conv2d(x_padded, self.sobel_y)
        grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)
        return grad_x, grad_y, grad_mag


class DifferentiableCanny(nn.Module):
    """
    可微分 Canny 边缘检测 - 修复版

    【核心修复】
    使用归一化双阈值公式，保证 t_l 和 t_h 都有稳定的梯度

    原来的问题：
        strong = sigmoid((grad - t_h) / temp)
        当 t_h >> grad 时，梯度 ≈ 0

    修复方案：
        normalized = (grad - t_l) / (t_h - t_l)
        edges = sigmoid((normalized - 0.5) * temp)

        这样 t_h 的梯度 = -normalized / (t_h - t_l) * temp * sigmoid'(...)
        即使 t_h 很大，只要 t_h - t_l 不是无穷大，梯度就不会消失
    """

    def __init__(self, use_nms: bool = True):
        super().__init__()
        self.sobel = SobelFilter()
        self.use_nms = use_nms

    def _soft_nms(self, grad_mag: torch.Tensor, temperature: float = 1.0) -> torch.Tensor:
        """软非极大值抑制"""
        pooled = F.max_pool2d(grad_mag, kernel_size=3, stride=1, padding=1)
        is_max = torch.sigmoid((grad_mag - pooled + 1e-6) / temperature)
        return grad_mag * is_max

    def forward(
        self,
        x: torch.Tensor,
        t_l: torch.Tensor,
        t_h: torch.Tensor,
        temperature: float = 5.0
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x: 输入图像 [B, 1, H, W]，值域 [0, 1]
            t_l: 低阈值 [B] 或 [B, 1]，值域 [0, 255]
            t_h: 高阈值 [B] 或 [B, 1]，值域 [0, 255]
            temperature: 软阈值温度

        Returns:
            edges: 边缘图 [B, 1, H, W]
            grad_mag: 梯度幅值 [B, 1, H, W]
        """
        batch_size = x.shape[0]

        # 计算梯度
        grad_x, grad_y, grad_mag = self.sobel(x)

        # 缩放到 [0, 255] 范围以匹配阈值
        grad_mag_scaled = grad_mag * 255.0

        # 软 NMS
        if self.use_nms:
            grad_mag_scaled = self._soft_nms(grad_mag_scaled, temperature=1.0)

        # 调整阈值形状
        t_l = t_l.view(batch_size, 1, 1, 1)
        t_h = t_h.view(batch_size, 1, 1, 1)

        # ============== 【修复】归一化双阈值 ==============
        #
        # 将 grad 归一化到 [t_l, t_h] 区间：
        #   - grad = t_l → normalized = 0
        #   - grad = t_h → normalized = 1
        #   - grad = (t_l + t_h) / 2 → normalized = 0.5
        #
        # 梯度分析：
        #   normalized = (grad - t_l) / (t_h - t_l)
        #   ∂normalized/∂t_l = (-1 * (t_h - t_l) - (grad - t_l) * (-1)) / (t_h - t_l)^2
        #                    = (grad - t_h) / (t_h - t_l)^2
        #   ∂normalized/∂t_h = -(grad - t_l) / (t_h - t_l)^2
        #
        # 只要 (t_h - t_l) 不是无穷大，梯度就不会是 0！

        # 确保 t_h > t_l，设置最小间隔
        min_gap = 20.0  # 最小间隔 20
        t_range = torch.clamp(t_h - t_l, min=min_gap)

        # 归一化
        normalized = (grad_mag_scaled - t_l) / t_range

        # ============== 边缘响应计算 ==============
        #
        # 方案1：简单 sigmoid（中心在 0.5）
        #   edges = sigmoid((normalized - 0.5) * temperature)
        #   - normalized < 0 (grad < t_l) → edges ≈ 0
        #   - normalized > 1 (grad > t_h) → edges ≈ 1
        #   - normalized = 0.5 → edges = 0.5
        #
        # 方案2：双边界 sigmoid（更符合 Canny 语义）
        #   above_low = sigmoid((grad - t_l) / temp)  # 是否超过低阈值
        #   strength = normalized  # 强度由位置决定
        #   edges = above_low * clamp(strength, 0, 1)

        # 使用方案2：更接近原始 Canny 的语义
        # 低阈值判断：grad > t_l
        above_low = torch.sigmoid((grad_mag_scaled - t_l) / temperature)

        # 强度：由 grad 在 [t_l, t_h] 区间的位置决定
        # grad = t_l → strength = 0
        # grad = t_h → strength = 1
        strength = torch.clamp(normalized, 0.0, 1.0)

        # 【关键】让 t_h 也参与 above_low 类型的计算，保证梯度
        # 思路：grad 越接近 t_h，边缘越"确定"
        certainty = torch.sigmoid((normalized - 0.3) * temperature)

        # 最终边缘 = 超过低阈值的概率 × 确定性
        edges = above_low * certainty

        # 另一种更简单的公式（备选）：
        # edges = torch.sigmoid((normalized - 0.3) * temperature)

        return edges, grad_mag


class DifferentiableMorphology(nn.Module):
    """
    完全可微的形态学操作

    使用多尺度 kernel 软加权
    """

    def __init__(self, kernel_sizes: Tuple[int, ...] = (3, 5, 7, 9, 11), temperature: float = 1.0):
        super().__init__()
        self.kernel_sizes = kernel_sizes
        self.temperature = temperature

        for k in kernel_sizes:
            kernel = self._create_circular_kernel(k)
            self.register_buffer(f"kernel_{k}", kernel)

    def _create_circular_kernel(self, size: int) -> torch.Tensor:
        """创建圆形结构元素"""
        center = size // 2
        y, x = torch.meshgrid(
            torch.arange(size, dtype=torch.float32),
            torch.arange(size, dtype=torch.float32),
            indexing='ij'
        )
        dist = torch.sqrt((x - center) ** 2 + (y - center) ** 2)
        kernel = (dist <= center).float()
        return kernel.unsqueeze(0).unsqueeze(0)

    def _compute_soft_weights(self, k_m: torch.Tensor) -> torch.Tensor:
        """根据 k_m 计算各 kernel size 的软权重"""
        k_m = k_m.view(-1, 1)
        kernel_sizes = torch.tensor(self.kernel_sizes, device=k_m.device, dtype=k_m.dtype)
        kernel_sizes = kernel_sizes.unsqueeze(0)
        distances = -torch.abs(k_m - kernel_sizes)
        weights = F.softmax(distances / self.temperature, dim=1)
        return weights

    def soft_dilate(self, x: torch.Tensor, k_m: torch.Tensor) -> torch.Tensor:
        """软膨胀操作"""
        batch_size = x.shape[0]
        weights = self._compute_soft_weights(k_m)
        result = torch.zeros_like(x)

        for i, k in enumerate(self.kernel_sizes):
            pad = k // 2
            x_padded = F.pad(x, (pad, pad, pad, pad), mode='replicate')
            dilated = F.max_pool2d(x_padded, kernel_size=k, stride=1, padding=0)
            w = weights[:, i].view(batch_size, 1, 1, 1)
            result = result + w * dilated

        return result

    def soft_erode(self, x: torch.Tensor, k_m: torch.Tensor) -> torch.Tensor:
        """软腐蚀操作"""
        return 1.0 - self.soft_dilate(1.0 - x, k_m)

    def soft_closing(self, x: torch.Tensor, k_m: torch.Tensor) -> torch.Tensor:
        """软闭运算"""
        dilated = self.soft_dilate(x, k_m)
        closed = self.soft_erode(dilated, k_m)
        return closed

    def soft_opening(self, x: torch.Tensor, k_m: torch.Tensor) -> torch.Tensor:
        """软开运算"""
        eroded = self.soft_erode(x, k_m)
        opened = self.soft_dilate(eroded, k_m)
        return opened

    def forward(
        self,
        x: torch.Tensor,
        k_m: torch.Tensor,
        operation: str = "closing"
    ) -> torch.Tensor:
        if operation == "closing":
            return self.soft_closing(x, k_m)
        elif operation == "opening":
            return self.soft_opening(x, k_m)
        elif operation == "dilate":
            return self.soft_dilate(x, k_m)
        elif operation == "erode":
            return self.soft_erode(x, k_m)
        else:
            raise ValueError(f"Unknown operation: {operation}")


class CVExecutionModule(nn.Module):
    """
    CV 执行模块

    C = h(P, I) = Closing(Canny(I, t_l, t_h), k_m)
    """

    def __init__(
        self,
        use_nms: bool = True,
        max_kernel_size: int = 11,
        temperature: float = 5.0,
        morph_temperature: float = 1.0
    ):
        super().__init__()

        self.canny = DifferentiableCanny(use_nms=use_nms)
        kernel_sizes = tuple(range(3, max_kernel_size + 1, 2))
        self.morphology = DifferentiableMorphology(
            kernel_sizes=kernel_sizes,
            temperature=morph_temperature
        )
        self.temperature = temperature

    def forward(
        self,
        x: torch.Tensor,
        params: Dict[str, torch.Tensor]
    ) -> Dict[str, torch.Tensor]:
        """
        Args:
            x: 输入灰度图像 [B, 1, H, W]，值域 [0, 1]
            params: CV 参数字典
        """
        t_l = params['t_l']
        t_h = params['t_h']
        k_m = params['k_m']

        # 1. Canny 边缘检测
        edges, grad_mag = self.canny(x, t_l, t_h, self.temperature)

        # 2. 形态学闭运算
        contours = self.morphology(edges, k_m, operation="closing")

        return {
            'contours': contours,
            'edges': edges,
            'grad_mag': grad_mag
        }


class MultiScaleCVExecution(nn.Module):
    """多尺度 CV 执行模块"""

    def __init__(
        self,
        scales: Tuple[float, ...] = (0.5, 1.0, 2.0),
        use_nms: bool = True,
        max_kernel_size: int = 11,
        temperature: float = 5.0
    ):
        super().__init__()
        self.scales = scales
        self.cv_module = CVExecutionModule(
            use_nms=use_nms,
            max_kernel_size=max_kernel_size,
            temperature=temperature
        )

    def forward(
        self,
        x: torch.Tensor,
        params: Dict[str, torch.Tensor]
    ) -> Dict[str, torch.Tensor]:
        batch_size, _, H, W = x.shape
        all_contours = []

        for scale in self.scales:
            if scale != 1.0:
                scaled_x = F.interpolate(
                    x, scale_factor=scale, mode='bilinear', align_corners=False
                )
            else:
                scaled_x = x

            result = self.cv_module(scaled_x, params)
            contours = result['contours']

            if scale != 1.0:
                contours = F.interpolate(
                    contours, size=(H, W), mode='bilinear', align_corners=False
                )

            all_contours.append(contours)

        fused = torch.stack(all_contours, dim=0).mean(dim=0)

        return {
            'contours': fused,
            'multi_scale_contours': all_contours
        }


# ==================== 测试代码 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("测试修复后的可微 CV 执行模块")
    print("=" * 60)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 创建测试输入
    batch_size = 4
    x = torch.rand(batch_size, 1, 64, 64, requires_grad=True, device=device)

    # 测试不同的参数值，包括边界情况
    test_cases = [
        {"t_l": [30.0, 40.0, 50.0, 60.0], "t_h": [80.0, 90.0, 100.0, 110.0], "k_m": [5.0, 7.0, 9.0, 5.0]},
        {"t_l": [80.0, 85.0, 90.0, 95.0], "t_h": [180.0, 185.0, 190.0, 195.0], "k_m": [9.0, 9.0, 9.0, 9.0]},  # t_h 很高
    ]

    cv_module = CVExecutionModule(max_kernel_size=11).to(device)

    for i, tc in enumerate(test_cases):
        print(f"\n测试用例 {i + 1}:")
        print(f"  t_l: {tc['t_l']}")
        print(f"  t_h: {tc['t_h']}")

        t_l = torch.tensor(tc['t_l'], requires_grad=True, device=device)
        t_h = torch.tensor(tc['t_h'], requires_grad=True, device=device)
        k_m = torch.tensor(tc['k_m'], requires_grad=True, device=device)

        params = {'t_l': t_l, 't_h': t_h, 'k_m': k_m}

        # 前向传播
        result = cv_module(x, params)
        contours = result['contours']

        # 测试梯度
        loss = contours.sum()
        loss.backward()

        print(f"\n  梯度检查:")
        print(f"    t_l.grad: {t_l.grad}")
        print(f"    t_h.grad: {t_h.grad}")  # 【关键】这个不应该接近 0
        print(f"    k_m.grad: {k_m.grad}")

        # 检查 t_h 梯度是否正常
        if t_h.grad is not None:
            t_h_grad_norm = t_h.grad.abs().mean().item()
            t_l_grad_norm = t_l.grad.abs().mean().item()
            ratio = t_h_grad_norm / (t_l_grad_norm + 1e-8)
            print(f"\n    |t_h.grad| / |t_l.grad| = {ratio:.4f}")

            if ratio > 0.01:  # t_h 梯度至少是 t_l 的 1%
                print("    ✓ t_h 梯度正常!")
            else:
                print("    ⚠ t_h 梯度仍然较小")

        # 清零梯度
        x.grad = None
        t_l.grad = None
        t_h.grad = None
        k_m.grad = None

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
