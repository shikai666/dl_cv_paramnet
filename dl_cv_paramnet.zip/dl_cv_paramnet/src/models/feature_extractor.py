"""
特征提取器模块 (Feature Extractor)

数学描述：
令 f_θ: ℝ^{H×W×1} → ℝ^D 为特征提取函数
F = f_θ(I) = φ_L ∘ φ_{L-1} ∘ ... ∘ φ_1(Preprocess(I))

其中每层 φ_l 是残差块：φ_l(x) = x + ConvBNReLU(x)

注意力机制：
F' = F ⊙ σ(W_a · GAP(F) + b_a)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models
from typing import Optional


class HistogramEqualization(nn.Module):
    """
    可微近似的直方图均衡化
    
    原始定义：HistEq(I)_{i,j} = 255 · Σ_{k=0}^{I_{i,j}} p(k)
    其中 p(k) 是归一化灰度直方图
    
    由于标准直方图均衡化不可微，这里使用可微近似
    """
    
    def __init__(self, num_bins: int = 256):
        super().__init__()
        self.num_bins = num_bins
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        输入: x ∈ [0, 1]^{B×1×H×W}
        输出: 均衡化后的图像
        """
        batch_size = x.shape[0]
        device = x.device
        
        # 对每个图像单独处理
        outputs = []
        for i in range(batch_size):
            img = x[i]  # 1×H×W
            
            # 计算 CDF（使用软直方图近似）
            flat = img.flatten()
            
            # 排序并计算经验 CDF
            sorted_vals, _ = torch.sort(flat)
            n = len(sorted_vals)
            
            # 创建映射：通过排名归一化
            ranks = torch.searchsorted(sorted_vals, flat.contiguous())
            equalized = ranks.float() / n
            
            outputs.append(equalized.reshape(img.shape))
        
        return torch.stack(outputs, dim=0)


class ChannelAttention(nn.Module):
    """
    通道注意力机制
    
    F' = F ⊙ σ(W_a · GAP(F) + b_a)
    
    其中：
    - GAP: 全局平均池化
    - W_a ∈ ℝ^{D×D}, b_a ∈ ℝ^D 是可学习参数
    - σ 是 sigmoid 函数
    - ⊙ 表示逐元素乘法
    """
    
    def __init__(self, in_channels: int, reduction: int = 16):
        """
        Args:
            in_channels: 输入通道数 D
            reduction: 降维比例（用于减少参数量）
        """
        super().__init__()
        
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        
        # 两层 MLP 实现通道注意力（SENet 风格）
        self.fc = nn.Sequential(
            nn.Linear(in_channels, in_channels // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(in_channels // reduction, in_channels, bias=False),
            nn.Sigmoid()
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: 特征图 ∈ ℝ^{B×D×H×W}
        Returns:
            加权特征图 F' ∈ ℝ^{B×D×H×W}
        """
        b, c, _, _ = x.size()
        
        # 全局平均池化: B×D×H×W → B×D×1×1
        y = self.avg_pool(x).view(b, c)
        
        # 通道权重: B×D
        y = self.fc(y).view(b, c, 1, 1)
        
        # 加权: F' = F ⊙ attention_weights
        return x * y.expand_as(x)


class FeatureExtractor(nn.Module):
    """
    特征提取器
    
    基于预训练 CNN（如 ResNet-18）提取图像特征
    输入: 灰度图像 I ∈ [0,255]^{H×W×1}
    输出: 特征向量 F' ∈ ℝ^D
    """
    
    def __init__(
        self,
        backbone: str = "resnet18",
        feature_dim: int = 512,
        pretrained: bool = True,
        use_attention: bool = True,
        use_hist_eq: bool = True
    ):
        """
        Args:
            backbone: 骨干网络类型
            feature_dim: 输出特征维度 D
            pretrained: 是否使用预训练权重
            use_attention: 是否使用通道注意力
            use_hist_eq: 是否使用直方图均衡化预处理
        """
        super().__init__()
        
        self.use_hist_eq = use_hist_eq
        self.use_attention = use_attention
        self.feature_dim = feature_dim
        
        # 预处理模块
        if use_hist_eq:
            self.hist_eq = HistogramEqualization()
        
        # 选择骨干网络
        if backbone == "resnet18":
            base_model = models.resnet18(pretrained=pretrained)
            in_features = 512
        elif backbone == "resnet34":
            base_model = models.resnet34(pretrained=pretrained)
            in_features = 512
        elif backbone == "resnet50":
            base_model = models.resnet50(pretrained=pretrained)
            in_features = 2048
        else:
            raise ValueError(f"不支持的骨干网络: {backbone}")
        
        # 修改第一层卷积以适应单通道输入
        # 原始: Conv2d(3, 64, kernel_size=7, stride=2, padding=3)
        # 修改: Conv2d(1, 64, kernel_size=7, stride=2, padding=3)
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        
        # 如果使用预训练权重，对第一层进行初始化
        if pretrained:
            # 将 RGB 三通道权重平均到单通道
            pretrained_weight = base_model.conv1.weight.data
            self.conv1.weight.data = pretrained_weight.mean(dim=1, keepdim=True)
        
        # 提取 ResNet 的其余层
        self.bn1 = base_model.bn1
        self.relu = base_model.relu
        self.maxpool = base_model.maxpool
        self.layer1 = base_model.layer1
        self.layer2 = base_model.layer2
        self.layer3 = base_model.layer3
        self.layer4 = base_model.layer4
        
        # 全局平均池化
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        
        # 通道注意力模块
        if use_attention:
            self.attention = ChannelAttention(in_features)
        
        # 特征维度调整（如果需要）
        if in_features != feature_dim:
            self.fc = nn.Linear(in_features, feature_dim)
        else:
            self.fc = nn.Identity()
        
        self.in_features = in_features
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        前向传播
        
        Args:
            x: 输入图像 I ∈ ℝ^{B×1×H×W}，像素值范围 [0, 1]
        
        Returns:
            特征向量 F' ∈ ℝ^{B×D}
        """
        # 预处理：直方图均衡化
        if self.use_hist_eq:
            x = self.hist_eq(x)
        
        # ResNet 特征提取
        # φ_1: 初始卷积
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        # φ_2 ~ φ_5: 残差块
        x = self.layer1(x)  # φ_2
        x = self.layer2(x)  # φ_3
        x = self.layer3(x)  # φ_4
        x = self.layer4(x)  # φ_5: 输出 B×512×H'×W' (ResNet-18)
        
        # 通道注意力
        if self.use_attention:
            x = self.attention(x)  # F' = F ⊙ σ(W_a · GAP(F) + b_a)
        
        # 全局平均池化
        x = self.avgpool(x)  # B×D×1×1
        x = torch.flatten(x, 1)  # B×D
        
        # 特征维度调整
        x = self.fc(x)  # B×feature_dim
        
        return x
    
    def get_feature_maps(self, x: torch.Tensor) -> dict:
        """
        获取中间特征图（用于可视化）
        
        Returns:
            包含各层特征图的字典
        """
        features = {}
        
        if self.use_hist_eq:
            x = self.hist_eq(x)
            features['hist_eq'] = x.clone()
        
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        features['conv1'] = x.clone()
        
        x = self.maxpool(x)
        x = self.layer1(x)
        features['layer1'] = x.clone()
        
        x = self.layer2(x)
        features['layer2'] = x.clone()
        
        x = self.layer3(x)
        features['layer3'] = x.clone()
        
        x = self.layer4(x)
        features['layer4'] = x.clone()
        
        if self.use_attention:
            x = self.attention(x)
            features['attention'] = x.clone()
        
        return features


class ProjectionHead(nn.Module):
    """
    投影头（用于对比学习）
    
    Proj(x) = W_p^{(2)} · ρ(W_p^{(1)} x + b_p^{(1)}) + b_p^{(2)}
    
    其中 ρ = ReLU
    """
    
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 256,
        output_dim: int = 128
    ):
        """
        Args:
            input_dim: 输入维度（展平后的轮廓掩码维度）
            hidden_dim: 隐藏层维度
            output_dim: 输出嵌入维度
        """
        super().__init__()
        
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, output_dim)
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: 展平的轮廓掩码 ∈ ℝ^{B×(H×W)}
        Returns:
            嵌入向量 z ∈ ℝ^{B×output_dim}
        """
        return self.net(x)


if __name__ == "__main__":
    # 测试代码
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 创建特征提取器
    extractor = FeatureExtractor(
        backbone="resnet18",
        feature_dim=512,
        pretrained=False,
        use_attention=True,
        use_hist_eq=True
    ).to(device)
    
    # 测试输入
    x = torch.randn(4, 1, 256, 256).to(device)
    
    # 前向传播
    features = extractor(x)
    print(f"输入形状: {x.shape}")
    print(f"输出特征形状: {features.shape}")
    
    # 获取中间特征
    feature_maps = extractor.get_feature_maps(x)
    for name, feat in feature_maps.items():
        print(f"{name}: {feat.shape}")
