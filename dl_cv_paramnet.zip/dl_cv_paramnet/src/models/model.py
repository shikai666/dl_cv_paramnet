"""
DL-CV ParamNet 完整模型

整合特征提取器、参数预测器和 CV 执行模块
实现端到端的文字轮廓检测
"""

import torch
import torch.nn as nn
from typing import Dict, Optional, Tuple

from .feature_extractor import FeatureExtractor, ProjectionHead
from .parameter_predictor import ParameterPredictor, ParameterRegularizer
from .cv_execution import CVExecutionModule, MultiScaleCVExecution


class DLCVParamNet(nn.Module):
    """
    DL-CV ParamNet: 基于自监督对比学习的深度学习控制 CV 参数化框架

    架构组成：
    1. 特征提取器 f_θ: 从灰度图像提取高级特征
    2. 参数预测器 g_φ: 预测 CV 操作参数
    3. CV 执行模块 h: 执行 Canny + 形态学操作
    4. 投影头 (训练时): 将轮廓映射到对比学习嵌入空间
    """

    def __init__(
        self,
        # 特征提取器参数
        backbone: str = "resnet18",
        feature_dim: int = 512,
        pretrained: bool = True,
        use_attention: bool = True,
        use_hist_eq: bool = True,
        # 参数预测器参数
        predictor_hidden_dim: int = 256,
        alpha_l: float = 100.0,
        beta_l: float = 0.0,
        alpha_h: float = 100.0,
        beta_h: float = 50.0,
        alpha_k: float = 10.0,
        beta_k: float = 3.0,
        # CV 执行参数
        use_nms: bool = True,
        max_kernel_size: int = 15,
        cv_temperature: float = 5.0,
        # 投影头参数
        projection_dim: int = 128,
        # 图像尺寸（用于投影头）
        image_size: Tuple[int, int] = (256, 256)
    ):
        super().__init__()

        self.image_size = image_size

        # 1. 特征提取器
        self.feature_extractor = FeatureExtractor(
            backbone=backbone,
            feature_dim=feature_dim,
            pretrained=pretrained,
            use_attention=use_attention,
            use_hist_eq=use_hist_eq
        )

        # 2. 参数预测器
        self.param_predictor = ParameterPredictor(
            input_dim=feature_dim,
            hidden_dim=predictor_hidden_dim,
            num_params=3,
            alpha_l=alpha_l,
            beta_l=beta_l,
            alpha_h=alpha_h,
            beta_h=beta_h,
            alpha_k=alpha_k,
            beta_k=beta_k
        )

        # 3. CV 执行模块
        self.cv_module = CVExecutionModule(
            use_nms=use_nms,
            max_kernel_size=max_kernel_size,
            temperature=cv_temperature
        )

        # 4. 投影头（用于对比学习）
        contour_dim = image_size[0] * image_size[1]
        self.projection_head = ProjectionHead(
            input_dim=contour_dim,
            hidden_dim=predictor_hidden_dim,
            output_dim=projection_dim
        )

        # 5. 参数正则化器（可选）
        self.param_regularizer = ParameterRegularizer()

    def forward(
        self,
        x: torch.Tensor,
        return_intermediates: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        前向传播

        Args:
            x: 输入灰度图像 ∈ ℝ^{B×1×H×W}，值范围 [0, 1]
            return_intermediates: 是否返回中间结果

        Returns:
            包含输出的字典：
            - 'contours': 轮廓掩码 C ∈ [0, 1]^{B×1×H×W}
            - 'params': CV 参数字典
            - 'embedding': 对比学习嵌入 (训练时)
            - 其他中间结果 (如果 return_intermediates=True)
        """
        batch_size = x.shape[0]

        # 1. 特征提取
        features = self.feature_extractor(x)  # B×D

        # 2. 参数预测
        params = self.param_predictor(features)  # 包含 t_l, t_h, k_m

        # 3. CV 执行
        cv_results = self.cv_module(x, params)
        contours = cv_results['contours']  # B×1×H×W

        # 4. 投影嵌入（用于对比学习）
        contours_flat = contours.view(batch_size, -1)  # B×(H×W)
        embedding = self.projection_head(contours_flat)  # B×projection_dim

        # 构建输出
        output = {
            'contours': contours,
            'params': params,
            'embedding': embedding,
            'features': features
        }

        if return_intermediates:
            output.update({
                'edges': cv_results['edges'],
                'grad_mag': cv_results['grad_mag'],
                'closed': cv_results['closed']
            })

        return output

    def get_pseudo_ground_truth(
        self,
        x: torch.Tensor,
        threshold: float = 0.2
    ) -> torch.Tensor:
        """
        获取 Sobel 伪地面真值

        Args:
            x: 输入图像
            threshold: 二值化阈值

        Returns:
            伪地面真值边缘图
        """
        return self.cv_module.get_pseudo_ground_truth(x, threshold)

    def predict_params(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        仅预测 CV 参数（不执行 CV）

        用于参数分析和可视化
        """
        features = self.feature_extractor(x)
        params = self.param_predictor(features)
        return params

    def get_param_regularization_loss(
        self,
        params: Dict[str, torch.Tensor]
    ) -> torch.Tensor:
        """
        获取参数正则化损失
        """
        return self.param_regularizer(params)


class DLCVParamNetMultiScale(nn.Module):
    """
    多尺度 DL-CV ParamNet

    处理文字大小变异的扩展版本

    C = NMS(∪_s Upsample(h(P_s, Resize(I, s)), 1/s))
    """

    def __init__(
        self,
        scales: Tuple[float, ...] = (0.5, 1.0, 2.0),
        share_backbone: bool = True,
        **kwargs
    ):
        """
        Args:
            scales: 处理的尺度列表
            share_backbone: 是否共享特征提取器
            **kwargs: 传递给基础模型的参数
        """
        super().__init__()

        self.scales = scales
        self.share_backbone = share_backbone

        if share_backbone:
            # 共享特征提取器
            self.feature_extractor = FeatureExtractor(
                backbone=kwargs.get('backbone', 'resnet18'),
                feature_dim=kwargs.get('feature_dim', 512),
                pretrained=kwargs.get('pretrained', True),
                use_attention=kwargs.get('use_attention', True),
                use_hist_eq=kwargs.get('use_hist_eq', True)
            )

            # 每个尺度独立的参数预测器
            self.param_predictors = nn.ModuleDict({
                f"scale_{s}": ParameterPredictor(
                    input_dim=kwargs.get('feature_dim', 512),
                    hidden_dim=kwargs.get('predictor_hidden_dim', 256)
                )
                for s in scales
            })
        else:
            # 每个尺度独立的模型
            self.models = nn.ModuleDict({
                f"scale_{s}": DLCVParamNet(**kwargs)
                for s in scales
            })

        # 多尺度 CV 执行
        self.multi_scale_cv = MultiScaleCVExecution(
            scales=scales,
            use_nms=kwargs.get('use_nms', True),
            max_kernel_size=kwargs.get('max_kernel_size', 15),
            temperature=kwargs.get('cv_temperature', 5.0)
        )

        # 投影头
        image_size = kwargs.get('image_size', (256, 256))
        self.projection_head = ProjectionHead(
            input_dim=image_size[0] * image_size[1],
            hidden_dim=kwargs.get('predictor_hidden_dim', 256),
            output_dim=kwargs.get('projection_dim', 128)
        )

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        多尺度前向传播
        """
        batch_size, _, H, W = x.shape

        params_dict = {}

        for scale in self.scales:
            # 缩放图像
            if scale != 1.0:
                new_h, new_w = int(H * scale), int(W * scale)
                x_scaled = nn.functional.interpolate(
                    x, size=(new_h, new_w), mode='bilinear', align_corners=False
                )
            else:
                x_scaled = x

            if self.share_backbone:
                # 提取特征
                features = self.feature_extractor(x_scaled)
                # 预测参数
                params = self.param_predictors[f"scale_{scale}"](features)
            else:
                output = self.models[f"scale_{scale}"](x_scaled)
                params = output['params']

            params_dict[scale] = params

        # 多尺度 CV 执行
        contours = self.multi_scale_cv(x, params_dict)

        # 投影嵌入
        contours_flat = contours.view(batch_size, -1)
        embedding = self.projection_head(contours_flat)

        return {
            'contours': contours,
            'params_dict': params_dict,
            'embedding': embedding
        }


def create_model(config) -> DLCVParamNet:
    """
    根据配置创建模型

    Args:
        config: 配置对象

    Returns:
        DLCVParamNet 模型实例
    """
    model = DLCVParamNet(
        backbone=config.model.backbone,
        feature_dim=config.model.feature_dim,
        pretrained=config.model.pretrained,
        use_attention=config.model.use_attention,
        use_hist_eq=config.data.use_hist_eq,
        predictor_hidden_dim=config.model.predictor_hidden_dim,
        alpha_l=config.model.alpha_l,
        beta_l=config.model.beta_l,
        alpha_h=config.model.alpha_h,
        beta_h=config.model.beta_h,
        alpha_k=config.model.alpha_k,
        beta_k=config.model.beta_k,
        projection_dim=config.model.projection_dim,
        image_size=(config.data.image_height, config.data.image_width)
    )

    return model


if __name__ == "__main__":
    # 测试代码
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 创建模型
    model = DLCVParamNet(
        backbone="resnet18",
        feature_dim=512,
        pretrained=False,
        use_attention=True,
        image_size=(128, 128)
    ).to(device)

    # 测试输入
    x = torch.rand(4, 1, 128, 128).to(device)

    # 前向传播
    output = model(x, return_intermediates=True)

    print("模型输出:")
    for key, val in output.items():
        if isinstance(val, torch.Tensor):
            print(f"  {key}: shape={val.shape}")
        elif isinstance(val, dict):
            print(f"  {key}:")
            for k, v in val.items():
                if isinstance(v, torch.Tensor):
                    print(f"    {k}: shape={v.shape}")

    # 测试梯度
    loss = output['contours'].sum()
    loss.backward()
    print("\n梯度测试通过！")

    # 打印模型参数量
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\n总参数量: {total_params:,}")
    print(f"可训练参数量: {trainable_params:,}")
