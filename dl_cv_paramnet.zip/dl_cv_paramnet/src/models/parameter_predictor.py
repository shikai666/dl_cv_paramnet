"""
参数预测器模块 (Parameter Predictor)

数学描述：
令 g_φ: ℝ^D → ℝ^K 为参数预测函数

P = g_φ(F') = W_2 · ρ(W_1 · F' + b_1) + b_2

参数映射到物理范围：
- t_l = α_l · σ(p_1) + β_l
- t_h = t_l + (t_max - t_l) · σ(p_2)   ← 【修复】相对参数化，保证梯度
- k_m = α_k · σ(p_3) + β_k

其中 σ(x) = 1/(1 + e^{-x})
"""

import torch
import torch.nn as nn
from typing import Tuple, Dict


class ParameterPredictor(nn.Module):
    """
    参数预测器

    将特征向量映射到 CV 操作参数
    输入: 特征向量 F' ∈ ℝ^D
    输出: CV 参数 P = [t_l, t_h, k_m]
    """

    def __init__(
        self,
        input_dim: int = 512,
        hidden_dim: int = 256,
        num_params: int = 3,
        alpha_l: float = 100.0,
        beta_l: float = 0.0,
        alpha_h: float = 100.0,  # 保留兼容性，但不再直接使用
        beta_h: float = 50.0,    # 保留兼容性，但不再直接使用
        alpha_k: float = 10.0,
        beta_k: float = 3.0,
        # 【新增】t_h 的上界
        t_max: float = 200.0,
        # sigmoid 输入约束（防止饱和导致梯度≈0）
        p_clip: float = 4.0,
        # 是否对特征做 LayerNorm（稳定 MLP 输入尺度）
        use_layernorm: bool = True
    ):
        """
        Args:
            input_dim: 输入特征维度 D
            hidden_dim: 隐藏层维度 M
            num_params: CV 参数数量 K
            alpha_l, beta_l: 低阈值映射参数
            alpha_h, beta_h: 高阈值映射参数（保留兼容性）
            alpha_k, beta_k: 内核大小映射参数
            t_max: t_h 的上界
        """
        super().__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.num_params = num_params

        # 超参数
        self.alpha_l = alpha_l
        self.beta_l = beta_l
        self.alpha_h = alpha_h  # 保留但不使用
        self.beta_h = beta_h    # 保留但不使用
        self.alpha_k = alpha_k
        self.beta_k = beta_k
        self.t_max = t_max      # 【新增】

        self.p_clip = float(p_clip) if p_clip is not None else None
        self.use_layernorm = bool(use_layernorm)
        # 对输入特征做归一化，降低 raw_params 绝对值漂移的概率
        self.feature_norm = nn.LayerNorm(input_dim) if self.use_layernorm else None

        # MLP: P = W_2 · ρ(W_1 · F' + b_1) + b_2
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),  # W_1, b_1
            nn.ReLU(inplace=True),             # ρ = ReLU
            nn.Linear(hidden_dim, num_params)  # W_2, b_2
        )

        # 初始化权重
        self._init_weights()

    def _init_weights(self):
        """初始化权重 - 让初始 raw_params 接近 0，避免 sigmoid 一开始就进入饱和区"""
        for m in self.mlp.modules():
            if isinstance(m, nn.Linear):
                # 较小 gain 使输出更靠近 0，sigmoid(0)=0.5，梯度最大
                nn.init.xavier_uniform_(m.weight, gain=0.5)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)

    def forward(self, features: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        前向传播

        Args:
            features: 特征向量 F' ∈ ℝ^{B×D}

        Returns:
            包含 CV 参数的字典：
            - 'raw': 原始预测 [p_1, p_2, p_3]
            - 't_l': 低阈值
            - 't_h': 高阈值
            - 'k_m': 内核大小（浮点数，需要取整）
            - 'k_m_int': 内核大小（整数）
        """
        # 0) 可选：对特征做归一化，稳定 MLP 输入尺度
        if self.feature_norm is not None:
            features = self.feature_norm(features)

        # 1) MLP 预测原始参数（p1,p2,p3）
        raw_params = self.mlp(features)  # B × K

        # 2) 约束 sigmoid 的输入范围，避免 p 绝对值过大导致 sigmoid 饱和、梯度≈0
        if self.p_clip is not None and self.p_clip > 0:
            # soft-clip: p = c * p / (c + |p|)
            c = self.p_clip
            raw_params = c * raw_params / (c + raw_params.abs() + 1e-6)

        # 分离各参数
        p1 = raw_params[:, 0]  # 用于 t_l
        p2 = raw_params[:, 1]  # 用于 t_h
        p3 = raw_params[:, 2]  # 用于 k_m

        # ============== 参数映射 ==============

        # t_l = α_l · σ(p_1) + β_l  →  t_l ∈ [0, 100]
        t_l = self.alpha_l * torch.sigmoid(p1) + self.beta_l

        # 【修复】t_h 使用相对参数化，天然保证 t_h >= t_l 且有梯度
        # t_h = t_l + (t_max - t_l) · σ(p_2)  →  t_h ∈ [t_l, t_max]
        #
        # 原来的问题：t_h = α_h · σ(p_2) + β_h + t_l
        #   当 σ(p_2) 接近 0 或 1 时，对 p_2 的梯度几乎为 0
        #
        # 新参数化的优点：
        #   σ(p_2) = 0   →  t_h = t_l           (最小值)
        #   σ(p_2) = 0.5 →  t_h = (t_l + t_max)/2  (中点，梯度最大)
        #   σ(p_2) = 1   →  t_h = t_max         (最大值)
        #   无论 p_2 取什么值，∂t_h/∂p_2 = (t_max - t_l) · σ'(p_2) 始终 > 0
        t_h = t_l + (self.t_max - t_l) * torch.sigmoid(p2)

        # k_m = α_k · σ(p_3) + β_k  →  k_m ∈ [3, 13]
        k_m = self.alpha_k * torch.sigmoid(p3) + self.beta_k

        # 取整为整数（用于实际 CV 操作）
        # 使用 STE (Straight-Through Estimator) 保持可微
        k_m_int = self._round_ste(k_m)

        # 确保内核大小为奇数（形态学操作要求）
        k_m_int = self._ensure_odd(k_m_int)

        return {
            'raw': raw_params,
            't_l': t_l,
            't_h': t_h,
            'k_m': k_m,
            'k_m_int': k_m_int
        }

    def _round_ste(self, x: torch.Tensor) -> torch.Tensor:
        """
        直通估计器 (Straight-Through Estimator) 的取整操作

        前向：取整
        反向：恒等梯度
        """
        return x + (x.round() - x).detach()

    def _ensure_odd(self, x: torch.Tensor) -> torch.Tensor:
        """
        确保值为奇数

        如果是偶数，则加 1
        """
        is_even = (x.round() % 2 == 0).float()
        return x + is_even

    def get_param_stats(self, features: torch.Tensor) -> Dict[str, Tuple[float, float, float]]:
        """
        获取参数统计信息（用于监控和可视化）

        Returns:
            每个参数的 (min, mean, max) 统计
        """
        params = self.forward(features)

        stats = {}
        for key in ['t_l', 't_h', 'k_m']:
            val = params[key]
            stats[key] = (
                val.min().item(),
                val.mean().item(),
                val.max().item()
            )

        return stats


class MultiScaleParameterPredictor(nn.Module):
    """
    多尺度参数预测器

    为不同尺度的图像预测不同的 CV 参数
    用于处理文字大小变异
    """

    def __init__(
        self,
        input_dim: int = 512,
        hidden_dim: int = 256,
        scales: Tuple[float, ...] = (0.5, 1.0, 2.0),
        **kwargs
    ):
        """
        Args:
            input_dim: 输入特征维度
            hidden_dim: 隐藏层维度
            scales: 尺度列表
            **kwargs: 传递给 ParameterPredictor 的其他参数
        """
        super().__init__()

        self.scales = scales

        # 为每个尺度创建独立的预测器
        self.predictors = nn.ModuleDict({
            f"scale_{s}": ParameterPredictor(
                input_dim=input_dim,
                hidden_dim=hidden_dim,
                **kwargs
            )
            for s in scales
        })

    def forward(
        self,
        features_dict: Dict[float, torch.Tensor]
    ) -> Dict[float, Dict[str, torch.Tensor]]:
        """
        Args:
            features_dict: {scale: features} 字典

        Returns:
            {scale: params} 字典
        """
        results = {}
        for scale in self.scales:
            if scale in features_dict:
                results[scale] = self.predictors[f"scale_{scale}"](features_dict[scale])
        return results


class ParameterRegularizer(nn.Module):
    """
    参数正则化模块

    提供额外的正则化损失，确保预测参数在合理范围内
    """

    def __init__(
        self,
        t_l_range: Tuple[float, float] = (10.0, 80.0),
        t_h_range: Tuple[float, float] = (80.0, 200.0),
        k_m_range: Tuple[float, float] = (3.0, 11.0)
    ):
        super().__init__()

        self.t_l_range = t_l_range
        self.t_h_range = t_h_range
        self.k_m_range = k_m_range

    def forward(self, params: Dict[str, torch.Tensor]) -> torch.Tensor:
        """
        计算参数正则化损失

        鼓励参数落在期望范围内
        """
        loss = 0.0

        # 低阈值正则化
        t_l = params['t_l']
        t_l_low_penalty = torch.relu(self.t_l_range[0] - t_l).mean()
        t_l_high_penalty = torch.relu(t_l - self.t_l_range[1]).mean()
        loss += t_l_low_penalty + t_l_high_penalty

        # 高阈值正则化
        t_h = params['t_h']
        t_h_low_penalty = torch.relu(self.t_h_range[0] - t_h).mean()
        t_h_high_penalty = torch.relu(t_h - self.t_h_range[1]).mean()
        loss += t_h_low_penalty + t_h_high_penalty

        # 内核大小正则化
        k_m = params['k_m']
        k_m_low_penalty = torch.relu(self.k_m_range[0] - k_m).mean()
        k_m_high_penalty = torch.relu(k_m - self.k_m_range[1]).mean()
        loss += k_m_low_penalty + k_m_high_penalty

        return loss


if __name__ == "__main__":
    # 测试代码
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 创建参数预测器
    predictor = ParameterPredictor(
        input_dim=512,
        hidden_dim=256,
        num_params=3
    ).to(device)

    # 测试输入
    features = torch.randn(4, 512).to(device)

    # 前向传播
    params = predictor(features)

    print("参数预测结果:")
    for key, val in params.items():
        if isinstance(val, torch.Tensor):
            print(f"  {key}: shape={val.shape}, range=[{val.min():.2f}, {val.max():.2f}]")

    # 获取统计信息
    stats = predictor.get_param_stats(features)
    print("\n参数统计:")
    for key, (min_val, mean_val, max_val) in stats.items():
        print(f"  {key}: min={min_val:.2f}, mean={mean_val:.2f}, max={max_val:.2f}")

    # 【新增】测试梯度 - 验证 t_h 对 p2 有梯度
    print("\n梯度测试:")
    predictor.zero_grad()
    params = predictor(features)
    loss = params['t_l'].sum() + params['t_h'].sum() + params['k_m'].sum()
    loss.backward()

    # 打印最后一层权重的每行梯度范数
    last_layer = predictor.mlp[2]
    if last_layer.weight.grad is not None:
        grad = last_layer.weight.grad
        row_norms = [grad[i].norm().item() for i in range(3)]
        print(f"  mlp.2.weight row_norm (t_l, t_h, k_m) = {row_norms}")

        # 验证 t_h 梯度不再是极小值
        if row_norms[1] > 0.001:
            print("  ✓ t_h 梯度正常！")
        else:
            print("  ✗ t_h 梯度仍然很小，需要检查")

    print("\n梯度测试通过！")
