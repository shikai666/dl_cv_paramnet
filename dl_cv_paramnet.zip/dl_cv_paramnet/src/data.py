"""
数据加载和增强模块

针对里耶秦简灰度图像的数据处理
支持几何增强（旋转、缩放）用于对比学习
"""

import os
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as T
import torchvision.transforms.functional as TF
from PIL import Image, ImageFile
import numpy as np
from typing import Tuple, Optional, List, Callable, Dict
import random

# ===== 方案A：容错读取截断图（避免 DataLoader 直接崩）=====
# 若你更想“严格剔除坏图”，可以把 True 改成 False，然后依靠 try/except 跳过
ImageFile.LOAD_TRUNCATED_IMAGES = True
# ===========================================================


class GeometricTransform:
    """
    几何变换增强

    用于自监督对比学习的正样本生成
    变换集合 T = {旋转 [-θ, θ], 缩放 [s_min, s_max]}

    避免噪声增强以匹配干净灰度图特性
    """

    def __init__(
        self,
        rotation_range: Tuple[float, float] = (-15.0, 15.0),
        scale_range: Tuple[float, float] = (0.8, 1.2),
        flip_prob: float = 0.5,
        target_size: Optional[Tuple[int, int]] = None
    ):
        """
        Args:
            rotation_range: 旋转角度范围 (min_deg, max_deg)
            scale_range: 缩放比例范围 (min_scale, max_scale)
            flip_prob: 水平翻转概率
            target_size: 目标图像尺寸 (H, W)，如果为 None 则保持原尺寸
        """
        self.rotation_range = rotation_range
        self.scale_range = scale_range
        self.flip_prob = flip_prob
        self.target_size = target_size

    def __call__(self, image: Image.Image) -> Image.Image:
        """
        应用随机几何变换

        Args:
            image: PIL 图像

        Returns:
            增强后的 PIL 图像
        """
        angle = random.uniform(self.rotation_range[0], self.rotation_range[1])
        image = TF.rotate(image, angle, fill=255)

        scale = random.uniform(self.scale_range[0], self.scale_range[1])
        w, h = image.size
        new_w, new_h = int(w * scale), int(h * scale)
        image = TF.resize(image, (new_h, new_w))

        if random.random() < self.flip_prob:
            image = TF.hflip(image)

        if self.target_size is not None:
            image = TF.resize(image, self.target_size)
            w, h = image.size
            if w < self.target_size[1] or h < self.target_size[0]:
                image = TF.center_crop(image, self.target_size)

        return image


class ContrastiveTransform:
    """
    对比学习变换

    生成同一图像的两个不同增强版本作为正样本对
    """

    def __init__(
        self,
        rotation_range: Tuple[float, float] = (-15.0, 15.0),
        scale_range: Tuple[float, float] = (0.8, 1.2),
        target_size: Tuple[int, int] = (256, 256)
    ):
        self.transform = GeometricTransform(
            rotation_range=rotation_range,
            scale_range=scale_range,
            flip_prob=0.5,
            target_size=target_size
        )

        self.to_tensor = T.Compose([
            T.ToTensor()
        ])

    def __call__(self, image: Image.Image) -> Tuple[torch.Tensor, torch.Tensor]:
        image1 = self.transform(image.copy())
        image2 = self.transform(image.copy())

        tensor1 = self.to_tensor(image1)
        tensor2 = self.to_tensor(image2)

        return tensor1, tensor2


class QinBambooSlipDataset(Dataset):
    """
    里耶秦简灰度图像数据集

    假设图像为从 PDF 扫描文档提取的灰度图像
    """

    def __init__(
        self,
        root_dir: str,
        transform: Optional[Callable] = None,
        target_size: Tuple[int, int] = (256, 256),
        mode: str = 'train',
        extensions: Tuple[str, ...] = ('.png', '.jpg', '.jpeg', '.tif', '.tiff', '.bmp')
    ):
        self.root_dir = root_dir
        self.target_size = target_size
        self.mode = mode

        self.image_paths = self._collect_images(root_dir, extensions)

        if len(self.image_paths) == 0:
            print(f"警告: 在 {root_dir} 中未找到图像文件")

        if transform is not None:
            self.transform = transform
        elif mode == 'train':
            self.transform = ContrastiveTransform(
                rotation_range=(-15.0, 15.0),
                scale_range=(0.8, 1.2),
                target_size=target_size
            )
        else:
            self.transform = T.Compose([
                T.Resize(target_size),
                T.ToTensor()
            ])

        self.is_contrastive = mode == 'train' and isinstance(self.transform, ContrastiveTransform)

        # 记录坏文件（仅用于调试输出）
        self._bad_count = 0

    def _collect_images(
        self,
        root_dir: str,
        extensions: Tuple[str, ...]
    ) -> List[str]:
        image_paths = []

        if not os.path.exists(root_dir):
            return image_paths

        for root, dirs, files in os.walk(root_dir):
            for file in files:
                if file.lower().endswith(extensions):
                    image_paths.append(os.path.join(root, file))

        return sorted(image_paths)

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int):
        """
        获取数据项（容错版）

        Returns:
            训练模式: (image1, image2, idx)
            其他模式: (image, idx)
        """
        # ===== 方案A核心：遇到坏图/截断图，随机换一张，最多重试 N 次 =====
        max_retry = 20
        cur_idx = int(idx)

        for _ in range(max_retry):
            image_path = self.image_paths[cur_idx]
            try:
                # 强制用 context manager，避免文件句柄泄漏
                with Image.open(image_path) as im:
                    # 有些截断图在 convert/load 时会报错；这里提前 load
                    im.load()
                    if im.mode != 'L':
                        im = im.convert('L')
                    image = im.copy()

                if self.is_contrastive:
                    image1, image2 = self.transform(image)
                    return image1, image2, cur_idx
                else:
                    image_t = self.transform(image)
                    return image_t, cur_idx

            except Exception as e:
                # 记录并换一个 index（避免 DataLoader worker 崩）
                self._bad_count += 1
                # 控制台不要刷屏：每 50 次坏图提示一次
                if self._bad_count % 50 == 0:
                    print(f"[Data] 已跳过损坏图像 {self._bad_count} 张，最近文件: {image_path}，错误: {e}")

                # 随机换一张继续
                cur_idx = random.randint(0, len(self.image_paths) - 1)

        raise RuntimeError(f"Too many corrupted images encountered. idx={idx}")

        # ================================================================


class SyntheticDataset(Dataset):
    """
    合成数据集（用于测试和调试）

    生成简单的合成图像，包含模拟的文字轮廓
    """

    def __init__(
        self,
        num_samples: int = 1000,
        image_size: Tuple[int, int] = (256, 256),
        mode: str = 'train'
    ):
        self.num_samples = num_samples
        self.image_size = image_size
        self.mode = mode

        if mode == 'train':
            self.transform = ContrastiveTransform(
                rotation_range=(-15.0, 15.0),
                scale_range=(0.8, 1.2),
                target_size=image_size
            )
        else:
            self.transform = T.ToTensor()

        self.is_contrastive = mode == 'train'

    def _generate_synthetic_image(self) -> Image.Image:
        H, W = self.image_size

        image = np.ones((H, W), dtype=np.uint8) * 240

        num_chars = random.randint(5, 15)
        for _ in range(num_chars):
            x1 = random.randint(10, W - 40)
            y1 = random.randint(10, H - 40)
            w = random.randint(15, 35)
            h = random.randint(20, 50)
            intensity = random.randint(20, 80)
            image[y1:y1 + h, x1:x1 + w] = intensity

        noise = np.random.normal(0, 5, (H, W))
        image = np.clip(image + noise, 0, 255).astype(np.uint8)

        return Image.fromarray(image, mode='L')

    def __len__(self) -> int:
        return self.num_samples

    def __getitem__(self, idx: int):
        image = self._generate_synthetic_image()

        if self.is_contrastive:
            image1, image2 = self.transform(image)
            return image1, image2, idx
        else:
            image_tensor = self.transform(image)
            return image_tensor, idx


def create_dataloaders(
    config,
    use_synthetic: bool = False
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    创建数据加载器
    """
    target_size = (config.data.image_height, config.data.image_width)

    if use_synthetic:
        train_dataset = SyntheticDataset(
            num_samples=1000,
            image_size=target_size,
            mode='train'
        )
        val_dataset = SyntheticDataset(
            num_samples=200,
            image_size=target_size,
            mode='val'
        )
        test_dataset = SyntheticDataset(
            num_samples=200,
            image_size=target_size,
            mode='test'
        )
    else:
        train_dataset = QinBambooSlipDataset(
            root_dir=config.data.train_dir,
            target_size=target_size,
            mode='train'
        )
        val_dataset = QinBambooSlipDataset(
            root_dir=config.data.val_dir,
            target_size=target_size,
            mode='val'
        )
        test_dataset = QinBambooSlipDataset(
            root_dir=config.data.test_dir,
            target_size=target_size,
            mode='test'
        )

    train_loader = DataLoader(
        train_dataset,
        batch_size=config.training.batch_size,
        shuffle=True,
        num_workers=config.data.num_workers,
        pin_memory=config.data.pin_memory,
        drop_last=True
    )

    val_loader = DataLoader(
        val_dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=config.data.num_workers,
        pin_memory=config.data.pin_memory
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=config.training.batch_size,
        shuffle=False,
        num_workers=config.data.num_workers,
        pin_memory=config.data.pin_memory
    )

    return train_loader, val_loader, test_loader


class HistogramEqualization:
    """
    直方图均衡化（PIL 图像级别）
    """

    def __call__(self, image: Image.Image) -> Image.Image:
        if image.mode != 'L':
            image = image.convert('L')

        img_array = np.array(image)

        hist, bins = np.histogram(img_array.flatten(), bins=256, range=(0, 256))
        cdf = hist.cumsum()
        cdf_normalized = cdf * 255 / cdf[-1]

        equalized = np.interp(img_array.flatten(), bins[:-1], cdf_normalized)
        equalized = equalized.reshape(img_array.shape).astype(np.uint8)

        return Image.fromarray(equalized, mode='L')


if __name__ == "__main__":
    print("测试数据加载模块...")

    train_dataset = SyntheticDataset(
        num_samples=100,
        image_size=(128, 128),
        mode='train'
    )

    val_dataset = SyntheticDataset(
        num_samples=20,
        image_size=(128, 128),
        mode='val'
    )

    print("\n训练数据集:")
    print(f"  样本数: {len(train_dataset)}")
    sample = train_dataset[0]
    print(f"  输出类型: {type(sample)}")
    print(f"  正样本对形状: {sample[0].shape}, {sample[1].shape}")
    print(f"  值范围: [{sample[0].min():.3f}, {sample[0].max():.3f}]")

    print("\n验证数据集:")
    print(f"  样本数: {len(val_dataset)}")
    sample = val_dataset[0]
    print(f"  图像形状: {sample[0].shape}")

    print("\n测试 DataLoader...")
    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
    batch = next(iter(train_loader))
    print(f"  批次内容: {len(batch)} 项")
    print(f"  图像1批次形状: {batch[0].shape}")
    print(f"  图像2批次形状: {batch[1].shape}")

    print("\n数据加载模块测试完成！")
