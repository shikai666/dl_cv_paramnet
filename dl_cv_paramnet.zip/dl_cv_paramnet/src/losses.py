"""
自监督训练损失函数

包含：
1. 对比损失 (NT-Xent / InfoNCE)
2. 重建损失 (L1 + 梯度损失)
3. 组合损失
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple


class NTXentLoss(nn.Module):
    """
    标准 NT-Xent 对比损失 (Normalized Temperature-scaled Cross Entropy)

    参考: SimCLR (Chen et al., 2020)

    数学描述：
    给定 batch 中 N 个样本，每个样本生成两个增强视图，共 2N 个样本。
    对于样本 i，其正样本为 j(i)（同一图像的另一视图），其余 2N-2 个样本为负样本。

    L = (1/2N) Σ_{k=1}^{N} [ℓ(2k-1, 2k) + ℓ(2k, 2k-1)]

    其中：
    ℓ(i, j) = -log[ exp(sim(z_i, z_j)/τ) / Σ_{k=1}^{2N} 𝟙_{[k≠i]} exp(sim(z_i, z_k)/τ) ]

    sim(u, v) = u^T v / (||u||_2 · ||v||_2)  (余弦相似度)
    τ: 温度参数
    """

    def __init__(self, temperature: float = 0.1):
        """
        Args:
            temperature: 温度参数 τ，控制 softmax 的锐度，默认 0.1
        """
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor
    ) -> torch.Tensor:
        """
        计算标准 NT-Xent 损失

        Args:
            z1: 第一组增强视图的嵌入 ∈ ℝ^{N×D}
            z2: 第二组增强视图的嵌入 ∈ ℝ^{N×D}

        Returns:
            对比损失标量
        """
        batch_size = z1.shape[0]
        device = z1.device

        # L2 归一化
        z1 = F.normalize(z1, dim=1)  # N×D
        z2 = F.normalize(z2, dim=1)  # N×D

        # 拼接所有嵌入: [z1_1, ..., z1_N, z2_1, ..., z2_N]
        # 索引 i 的正样本索引为 i+N (如果 i < N) 或 i-N (如果 i >= N)
        z = torch.cat([z1, z2], dim=0)  # (2N)×D

        # 计算余弦相似度矩阵并除以温度
        # sim_matrix[i,j] = sim(z_i, z_j) / τ
        sim_matrix = torch.mm(z, z.t()) / self.temperature  # (2N)×(2N)

        # 创建标签：正样本对的索引
        # 对于 i ∈ [0, N), 正样本索引为 i+N
        # 对于 i ∈ [N, 2N), 正样本索引为 i-N
        labels = torch.cat([
            torch.arange(batch_size, 2 * batch_size),  # [N, N+1, ..., 2N-1]
            torch.arange(batch_size)                    # [0, 1, ..., N-1]
        ], dim=0).to(device)  # (2N)

        # 创建 mask 排除自身 (对角线)
        # logits_mask[i,i] = 0, 其余为 1
        logits_mask = torch.ones(2 * batch_size, 2 * batch_size, device=device)
        logits_mask.fill_diagonal_(0)

        # 应用 mask：将自身相似度设为很大的负数（排除出 softmax）
        sim_matrix = sim_matrix * logits_mask + (1 - logits_mask) * (-1e9)

        # 使用 CrossEntropyLoss 计算损失
        # CrossEntropy 的输入是 logits，它会自动计算 softmax
        # 对于每个样本 i，正样本是 labels[i]，其余是负样本
        loss = F.cross_entropy(sim_matrix, labels)

        return loss


class SimCLRLoss(nn.Module):
    """
    SimCLR 风格的对比损失（与 NTXentLoss 等价，提供另一种实现方式）

    显式计算公式版本，便于理解和调试
    """

    def __init__(self, temperature: float = 0.1):
        super().__init__()
        self.temperature = temperature

    def forward(
        self,
        z1: torch.Tensor,
        z2: torch.Tensor
    ) -> torch.Tensor:
        """
        计算 SimCLR 损失

        Args:
            z1: 第一组增强视图的嵌入 ∈ ℝ^{N×D}
            z2: 第二组增强视图的嵌入 ∈ ℝ^{N×D}

        Returns:
            对比损失标量
        """
        batch_size = z1.shape[0]
        device = z1.device

        # L2 归一化
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)

        # 拼接
        z = torch.cat([z1, z2], dim=0)  # (2N)×D

        # 计算相似度矩阵
        sim_matrix = torch.mm(z, z.t()) / self.temperature  # (2N)×(2N)

        # 创建正样本掩码
        # pos_mask[i, j] = 1 当且仅当 i 和 j 是正样本对
        pos_mask = torch.zeros(2 * batch_size, 2 * batch_size, device=device)
        pos_mask[:batch_size, batch_size:] = torch.eye(batch_size, device=device)
        pos_mask[batch_size:, :batch_size] = torch.eye(batch_size, device=device)

        # 创建负样本掩码（排除自身，包含其他所有样本）
        neg_mask = torch.ones(2 * batch_size, 2 * batch_size, device=device)
        neg_mask.fill_diagonal_(0)  # 排除自身

        # 提取正样本相似度
        pos_sim = (sim_matrix * pos_mask).sum(dim=1)  # (2N)，每行只有一个非零值

        # 计算分母：exp(所有非自身样本的相似度) 之和
        # 注意：分母包含正样本
        exp_sim = torch.exp(sim_matrix) * neg_mask  # (2N)×(2N)
        denominator = exp_sim.sum(dim=1)  # (2N)

        # NT-Xent 损失
        # ℓ(i, j(i)) = -log[ exp(sim(z_i, z_j(i))/τ) / Σ_{k≠i} exp(sim(z_i, z_k)/τ) ]
        loss = -torch.log(torch.exp(pos_sim) / (denominator + 1e-8))

        return loss.mean()


class ReconstructionLoss(nn.Module):
    """
    重建损失

    数学描述：
    L_rec = (1/B) Σ_b [||C_b - S(I_b)||_1 + γ ||∇C_b - ∇I_b||_2^2]

    其中：
    - S(I) = threshold(√((∇_x I)² + (∇_y I)²)) 是 Sobel 伪地面真值
    - γ 是梯度损失权重
    """

    def __init__(
        self,
        gamma: float = 0.5,
        sobel_threshold: float = 0.2
    ):
        """
        Args:
            gamma: 梯度损失权重
            sobel_threshold: Sobel 边缘二值化阈值
        """
        super().__init__()
        self.gamma = gamma
        self.sobel_threshold = sobel_threshold

        # Sobel 算子
        sobel_x = torch.tensor([
            [-1, 0, 1],
            [-2, 0, 2],
            [-1, 0, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)

        sobel_y = torch.tensor([
            [-1, -2, -1],
            [0, 0, 0],
            [1, 2, 1]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)

        self.register_buffer('sobel_x', sobel_x)
        self.register_buffer('sobel_y', sobel_y)

    def compute_sobel_pseudo_gt(self, x: torch.Tensor) -> torch.Tensor:
        """
        计算 Sobel 伪地面真值

        S(I) = threshold(√((∇_x I)² + (∇_y I)²))
        """
        # 计算梯度
        x_padded = F.pad(x, (1, 1, 1, 1), mode='replicate')
        grad_x = F.conv2d(x_padded, self.sobel_x)
        grad_y = F.conv2d(x_padded, self.sobel_y)

        # 梯度幅值
        grad_mag = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-8)

        # 归一化
        batch_size = grad_mag.shape[0]
        grad_mag_flat = grad_mag.view(batch_size, -1)
        grad_max = grad_mag_flat.max(dim=1, keepdim=True)[0].view(batch_size, 1, 1, 1)
        grad_norm = grad_mag / (grad_max + 1e-8)

        # 软阈值（可微）
        pseudo_gt = torch.sigmoid((grad_norm - self.sobel_threshold) * 20)

        return pseudo_gt

    def compute_gradient(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        计算图像梯度
        """
        x_padded = F.pad(x, (1, 1, 1, 1), mode='replicate')
        grad_x = F.conv2d(x_padded, self.sobel_x)
        grad_y = F.conv2d(x_padded, self.sobel_y)
        return grad_x, grad_y

    def forward(
        self,
        pred_contours: torch.Tensor,
        input_images: torch.Tensor,
        pseudo_gt: Optional[torch.Tensor] = None
    ) -> Dict[str, torch.Tensor]:
        """
        计算重建损失

        Args:
            pred_contours: 预测的轮廓掩码 C ∈ [0, 1]^{B×1×H×W}
            input_images: 输入图像 I ∈ [0, 1]^{B×1×H×W}
            pseudo_gt: 预计算的伪地面真值（可选）

        Returns:
            包含各损失分量的字典
        """
        # 计算伪地面真值
        if pseudo_gt is None:
            pseudo_gt = self.compute_sobel_pseudo_gt(input_images)

        # L1 损失：||C - S(I)||_1
        l1_loss = F.l1_loss(pred_contours, pseudo_gt)

        # 梯度损失：||∇C - ∇I||_2^2
        pred_grad_x, pred_grad_y = self.compute_gradient(pred_contours)
        gt_grad_x, gt_grad_y = self.compute_gradient(input_images)

        grad_loss_x = F.mse_loss(pred_grad_x, gt_grad_x)
        grad_loss_y = F.mse_loss(pred_grad_y, gt_grad_y)
        grad_loss = grad_loss_x + grad_loss_y

        # 总重建损失
        total_loss = l1_loss + self.gamma * grad_loss

        return {
            'total': total_loss,
            'l1': l1_loss,
            'gradient': grad_loss,
            'pseudo_gt': pseudo_gt
        }


class SelfSupervisedLoss(nn.Module):
    """
    自监督训练总损失

    L = λ_1 L_cont + λ_2 L_rec

    整合对比损失和重建损失
    """

    def __init__(
        self,
        lambda_cont: float = 1.0,
        lambda_rec: float = 0.8,
        temperature: float = 0.1,
        gamma: float = 0.5,
        sobel_threshold: float = 0.2
    ):
        """
        Args:
            lambda_cont: 对比损失权重 λ_1
            lambda_rec: 重建损失权重 λ_2
            temperature: 对比学习温度 τ
            gamma: 梯度损失权重 γ
            sobel_threshold: Sobel 边缘阈值
        """
        super().__init__()

        self.lambda_cont = lambda_cont
        self.lambda_rec = lambda_rec

        self.contrastive_loss = NTXentLoss(temperature=temperature)
        self.reconstruction_loss = ReconstructionLoss(
            gamma=gamma,
            sobel_threshold=sobel_threshold
        )

    def forward(
        self,
        output1: Dict[str, torch.Tensor],
        output2: Dict[str, torch.Tensor],
        input_images: torch.Tensor
    ) -> Dict[str, torch.Tensor]:
        """
        计算总损失

        Args:
            output1: 第一组增强图像的模型输出
            output2: 第二组增强图像的模型输出
            input_images: 原始输入图像（用于重建损失）

        Returns:
            包含各损失分量的字典
        """
        # 对比损失
        z1 = output1['embedding']
        z2 = output2['embedding']
        cont_loss = self.contrastive_loss(z1, z2)

        # 重建损失（对两组增强分别计算）
        rec_output1 = self.reconstruction_loss(output1['contours'], input_images)
        rec_output2 = self.reconstruction_loss(output2['contours'], input_images)

        rec_loss = (rec_output1['total'] + rec_output2['total']) / 2
        l1_loss = (rec_output1['l1'] + rec_output2['l1']) / 2
        grad_loss = (rec_output1['gradient'] + rec_output2['gradient']) / 2

        # 总损失
        total_loss = self.lambda_cont * cont_loss + self.lambda_rec * rec_loss

        return {
            'total': total_loss,
            'contrastive': cont_loss,
            'reconstruction': rec_loss,
            'l1': l1_loss,
            'gradient': grad_loss
        }


class ConsistencyLoss(nn.Module):
    """
    一致性损失

    确保同一图像的不同增强版本产生相似的轮廓
    """

    def __init__(self):
        super().__init__()

    def forward(
        self,
        contours1: torch.Tensor,
        contours2: torch.Tensor,
        transform_params: Optional[Dict] = None
    ) -> torch.Tensor:
        """
        计算一致性损失

        如果提供了变换参数，会先对 contours2 进行逆变换
        """
        # 如果有变换参数，进行逆变换对齐
        if transform_params is not None:
            contours2 = self._inverse_transform(contours2, transform_params)

        # 计算 L1 差异
        loss = F.l1_loss(contours1, contours2)

        return loss

    def _inverse_transform(
        self,
        x: torch.Tensor,
        params: Dict
    ) -> torch.Tensor:
        """
        应用逆变换（简化实现）
        """
        # 这里可以根据实际的增强变换实现逆变换
        # 简化起见，直接返回原张量
        return x


class EdgeAwareLoss(nn.Module):
    """
    边缘感知损失

    在边缘区域给予更高权重
    """

    def __init__(self, edge_weight: float = 2.0):
        super().__init__()
        self.edge_weight = edge_weight

        # Laplacian 算子检测边缘
        laplacian = torch.tensor([
            [0, 1, 0],
            [1, -4, 1],
            [0, 1, 0]
        ], dtype=torch.float32).unsqueeze(0).unsqueeze(0)
        self.register_buffer('laplacian', laplacian)

    def forward(
        self,
        pred: torch.Tensor,
        target: torch.Tensor,
        input_image: torch.Tensor
    ) -> torch.Tensor:
        """
        计算边缘感知损失
        """
        # 检测输入图像的边缘
        img_padded = F.pad(input_image, (1, 1, 1, 1), mode='replicate')
        edges = torch.abs(F.conv2d(img_padded, self.laplacian))

        # 归一化边缘权重
        edge_weights = 1.0 + (self.edge_weight - 1.0) * edges / (edges.max() + 1e-8)

        # 加权 L1 损失
        loss = (edge_weights * torch.abs(pred - target)).mean()

        return loss


if __name__ == "__main__":
    # 测试代码
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    batch_size = 4
    embed_dim = 128

    # 测试标准 NT-Xent 损失
    print("=" * 60)
    print("测试标准 NT-Xent 损失")
    print("=" * 60)

    nt_xent = NTXentLoss(temperature=0.1)
    z1 = torch.randn(batch_size, embed_dim).to(device)
    z2 = torch.randn(batch_size, embed_dim).to(device)

    # 测试随机嵌入
    cont_loss_random = nt_xent(z1, z2)
    print(f"随机嵌入对比损失: {cont_loss_random.item():.4f}")

    # 测试相似嵌入（应该损失更低）
    z2_similar = z1 + 0.1 * torch.randn_like(z1)
    cont_loss_similar = nt_xent(z1, z2_similar)
    print(f"相似嵌入对比损失: {cont_loss_similar.item():.4f}")

    # 测试相同嵌入（应该损失最低）
    cont_loss_same = nt_xent(z1, z1.clone())
    print(f"相同嵌入对比损失: {cont_loss_same.item():.4f}")

    print(f"\n验证: 相同 < 相似 < 随机: {cont_loss_same.item() < cont_loss_similar.item() < cont_loss_random.item()}")

    # 测试 SimCLR 损失（应与 NT-Xent 结果相近）
    print("\n" + "=" * 60)
    print("测试 SimCLR 损失（对比验证）")
    print("=" * 60)

    simclr = SimCLRLoss(temperature=0.1)
    simclr_loss = simclr(z1, z2)
    print(f"SimCLR 损失: {simclr_loss.item():.4f}")
    print(f"NT-Xent 损失: {cont_loss_random.item():.4f}")
    print(f"两者差异: {abs(simclr_loss.item() - cont_loss_random.item()):.6f}")

    # 测试重建损失
    print("\n" + "=" * 60)
    print("测试重建损失")
    print("=" * 60)

    rec_loss_fn = ReconstructionLoss(gamma=0.5)
    pred_contours = torch.rand(batch_size, 1, 64, 64).to(device)
    input_images = torch.rand(batch_size, 1, 64, 64).to(device)
    rec_output = rec_loss_fn(pred_contours, input_images)
    print(f"总重建损失: {rec_output['total'].item():.4f}")
    print(f"  - L1 损失: {rec_output['l1'].item():.4f}")
    print(f"  - 梯度损失: {rec_output['gradient'].item():.4f}")

    # 测试自监督总损失
    print("\n" + "=" * 60)
    print("测试自监督总损失")
    print("=" * 60)

    ss_loss = SelfSupervisedLoss(
        lambda_cont=1.0,
        lambda_rec=0.8,
        temperature=0.1,
        gamma=0.5
    )
    output1 = {
        'embedding': z1,
        'contours': pred_contours
    }
    output2 = {
        'embedding': z2,
        'contours': torch.rand(batch_size, 1, 64, 64).to(device)
    }
    total_output = ss_loss(output1, output2, input_images)
    print(f"总损失: {total_output['total'].item():.4f}")
    print(f"  - 对比损失: {total_output['contrastive'].item():.4f}")
    print(f"  - 重建损失: {total_output['reconstruction'].item():.4f}")

    # 测试梯度反向传播
    print("\n" + "=" * 60)
    print("测试梯度反向传播")
    print("=" * 60)

    total_output['total'].backward()
    print("梯度计算成功！")

    print("\n" + "=" * 60)
    print("所有测试通过！")
    print("=" * 60)
