"""
DL-CV ParamNet 配置文件 - 修复版

修复内容：
1. 添加 t_max, p_clip, use_layernorm 参数
2. 添加 get_config, save_config, load_config 函数
"""

import os
import json
from dataclasses import dataclass, field, asdict
from typing import List, Tuple, Optional


@dataclass
class ModelConfig:
    """模型架构配置"""
    # 特征提取器配置
    backbone: str = "resnet18"  # 可选: resnet18, resnet34, resnet50
    feature_dim: int = 512  # 特征维度 D
    pretrained: bool = True  # 是否使用预训练权重

    # 注意力机制配置
    use_attention: bool = True
    use_hist_eq: bool = True  # 是否使用直方图均衡化

    # 参数预测器配置
    predictor_hidden_dim: int = 256  # MLP 中间维度 M
    num_cv_params: int = 3  # CV 参数数量 K (t_l, t_h, k_m)

    # CV 参数映射超参数
    alpha_l: float = 100.0  # 低阈值缩放
    beta_l: float = 0.0     # 低阈值偏移
    alpha_h: float = 100.0  # 高阈值缩放（保留兼容性）
    beta_h: float = 50.0    # 高阈值偏移（保留兼容性）
    alpha_k: float = 10.0   # 内核大小缩放
    beta_k: float = 3.0     # 内核大小偏移

    # 【新增】参数预测器高级配置
    t_max: float = 200.0        # t_h 的上界
    p_clip: float = 4.0         # sigmoid 输入约束（防止饱和）
    use_layernorm: bool = True  # 是否对特征做 LayerNorm

    # 投影头配置（用于对比学习）
    projection_dim: int = 128  # 投影嵌入维度


@dataclass
class TrainingConfig:
    """训练配置"""
    # 基本训练参数
    batch_size: int = 32
    num_epochs: int = 100
    learning_rate: float = 1e-4
    weight_decay: float = 1e-5

    # 损失权重
    lambda_cont: float = 1.0   # 对比损失权重 λ1
    lambda_rec: float = 0.8    # 重建损失权重 λ2
    gamma: float = 0.5         # 梯度损失权重 γ
    temperature: float = 0.1   # 对比学习温度 τ

    # 数据增强参数
    rotation_range: Tuple[float, float] = (-15.0, 15.0)  # 旋转角度范围
    scale_range: Tuple[float, float] = (0.8, 1.2)        # 缩放范围

    # 优化器配置
    optimizer: str = "adam"
    scheduler: str = "cosine"  # 学习率调度器
    warmup_epochs: int = 5

    # 梯度裁剪
    grad_clip: float = 1.0

    # 检查点保存
    save_interval: int = 10
    checkpoint_dir: str = "./checkpoints"

    # 早停配置
    early_stopping_patience: int = 20


@dataclass
class DataConfig:
    """数据配置"""
    data_dir: str = "./data"
    train_dir: str = "./data/train/images"
    val_dir: str = "./data/val/images"
    test_dir: str = "./data/test/images"

    # 图像尺寸
    image_height: int = 256
    image_width: int = 256

    # 数据加载
    num_workers: int = 4
    pin_memory: bool = True

    # 预处理
    use_hist_eq: bool = True  # 是否使用直方图均衡化


@dataclass
class EvalConfig:
    """评估配置"""
    # 边界匹配容差（像素）
    boundary_tolerance: int = 2

    # Sobel 阈值（用于伪地面真值）
    sobel_threshold: float = 0.2

    # 可视化
    num_vis_samples: int = 10
    vis_output_dir: str = "./visualizations"


@dataclass
class Config:
    """总配置"""
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    data: DataConfig = field(default_factory=DataConfig)
    eval: EvalConfig = field(default_factory=EvalConfig)

    # 设备配置
    device: str = "cuda"  # cuda 或 cpu
    seed: int = 42

    # 日志配置
    log_dir: str = "./logs"
    experiment_name: str = "dl_cv_paramnet"


def get_config() -> Config:
    """获取默认配置"""
    return Config()


def save_config(config: Config, path: str):
    """保存配置到文件"""
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)

    # 转换为字典
    config_dict = asdict(config)

    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config_dict, f, indent=2, ensure_ascii=False)


def load_config(path: str) -> Config:
    """从文件加载配置"""
    with open(path, 'r', encoding='utf-8') as f:
        config_dict = json.load(f)

    # 递归构建配置对象
    return Config(
        model=ModelConfig(**config_dict.get('model', {})),
        training=TrainingConfig(**config_dict.get('training', {})),
        data=DataConfig(**config_dict.get('data', {})),
        eval=EvalConfig(**config_dict.get('eval', {})),
        device=config_dict.get('device', 'cuda'),
        seed=config_dict.get('seed', 42),
        log_dir=config_dict.get('log_dir', './logs'),
        experiment_name=config_dict.get('experiment_name', 'dl_cv_paramnet')
    )
