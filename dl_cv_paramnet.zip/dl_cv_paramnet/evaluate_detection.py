import os
import glob
import csv
import xml.etree.ElementTree as ET


def compute_iou(box1, box2):
    """
    box format: [xmin, ymin, xmax, ymax]
    """
    x1_min, y1_min, x1_max, y1_max = box1
    x2_min, y2_min, x2_max, y2_max = box2

    inter_xmin = max(x1_min, x2_min)
    inter_ymin = max(y1_min, y2_min)
    inter_xmax = min(x1_max, x2_max)
    inter_ymax = min(y1_max, y2_max)

    inter_w = max(0, inter_xmax - inter_xmin)
    inter_h = max(0, inter_ymax - inter_ymin)
    inter_area = inter_w * inter_h

    area1 = max(0, x1_max - x1_min) * max(0, y1_max - y1_min)
    area2 = max(0, x2_max - x2_min) * max(0, y2_max - y2_min)

    union_area = area1 + area2 - inter_area
    if union_area == 0:
        return 0.0
    return inter_area / union_area


def parse_xml_boxes(xml_path):
    """
    兼容常见 VOC/XML 标注格式:
    <object>
        <bndbox>
            <xmin>...</xmin>
            <ymin>...</ymin>
            <xmax>...</xmax>
            <ymax>...</ymax>
        </bndbox>
    </object>
    """
    if not os.path.exists(xml_path):
        return []

    tree = ET.parse(xml_path)
    root = tree.getroot()

    boxes = []

    # 常见 Pascal VOC 格式
    for obj in root.findall(".//object"):
        bndbox = obj.find("bndbox")
        if bndbox is None:
            continue

        xmin = int(float(bndbox.findtext("xmin", default="0")))
        ymin = int(float(bndbox.findtext("ymin", default="0")))
        xmax = int(float(bndbox.findtext("xmax", default="0")))
        ymax = int(float(bndbox.findtext("ymax", default="0")))

        if xmax > xmin and ymax > ymin:
            boxes.append([xmin, ymin, xmax, ymax])

    # 兼容有些 xml 直接就是 bndbox 列表
    if len(boxes) == 0:
        for bndbox in root.findall(".//bndbox"):
            xmin = int(float(bndbox.findtext("xmin", default="0")))
            ymin = int(float(bndbox.findtext("ymin", default="0")))
            xmax = int(float(bndbox.findtext("xmax", default="0")))
            ymax = int(float(bndbox.findtext("ymax", default="0")))

            if xmax > xmin and ymax > ymin:
                boxes.append([xmin, ymin, xmax, ymax])

    return boxes


def parse_pred_boxes(txt_path):
    """
    读取你前面生成的 boxes.txt:
    1: x=10, y=20, w=30, h=40
    """
    if not os.path.exists(txt_path):
        return []

    boxes = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            try:
                # 去掉前面的编号
                if ":" in line:
                    line = line.split(":", 1)[1].strip()

                parts = [p.strip() for p in line.split(",")]
                kv = {}
                for p in parts:
                    k, v = p.split("=")
                    kv[k.strip()] = int(float(v.strip()))

                x = kv["x"]
                y = kv["y"]
                w = kv["w"]
                h = kv["h"]

                xmin = x
                ymin = y
                xmax = x + w
                ymax = y + h

                if xmax > xmin and ymax > ymin:
                    boxes.append([xmin, ymin, xmax, ymax])

            except Exception:
                print(f"[警告] 预测框解析失败: {txt_path} -> {line}")

    return boxes


def match_boxes(gt_boxes, pred_boxes, iou_thresh=0.5):
    """
    一对一匹配：
    每个 GT 最多匹配一个预测框；
    每个预测框最多匹配一个 GT。
    贪心按最大 IoU 匹配。
    """
    matched_gt = set()
    matched_pred = set()

    matches = []

    for pred_idx, pred_box in enumerate(pred_boxes):
        best_iou = 0.0
        best_gt_idx = -1

        for gt_idx, gt_box in enumerate(gt_boxes):
            if gt_idx in matched_gt:
                continue

            iou = compute_iou(pred_box, gt_box)
            if iou > best_iou:
                best_iou = iou
                best_gt_idx = gt_idx

        if best_iou >= iou_thresh and best_gt_idx != -1:
            matched_pred.add(pred_idx)
            matched_gt.add(best_gt_idx)
            matches.append((pred_idx, best_gt_idx, best_iou))

    tp = len(matches)
    fp = len(pred_boxes) - tp
    fn = len(gt_boxes) - tp

    return tp, fp, fn, matches


def safe_div(a, b):
    return a / b if b != 0 else 0.0


def compute_metrics(tp, fp, fn):
    precision = safe_div(tp, tp + fp)
    recall = safe_div(tp, tp + fn)
    f1 = safe_div(2 * precision * recall, precision + recall) if (precision + recall) > 0 else 0.0
    return precision, recall, f1


def evaluate_dataset(gt_xml_dir, pred_root_dir, output_dir, iou_thresh=0.5):
    os.makedirs(output_dir, exist_ok=True)

    xml_paths = sorted(glob.glob(os.path.join(gt_xml_dir, "*.xml")))
    if len(xml_paths) == 0:
        print(f"[错误] 没有找到 XML 文件: {gt_xml_dir}")
        return

    per_image_csv = os.path.join(output_dir, "per_image_metrics.csv")
    summary_txt = os.path.join(output_dir, "summary_metrics.txt")

    total_tp = 0
    total_fp = 0
    total_fn = 0
    num_images_used = 0

    with open(per_image_csv, "w", newline="", encoding="utf-8") as f_csv:
        writer = csv.writer(f_csv)
        writer.writerow([
            "image_name", "num_gt", "num_pred", "TP", "FP", "FN",
            "Precision", "Recall", "F1"
        ])

        for xml_path in xml_paths:
            base_name = os.path.splitext(os.path.basename(xml_path))[0]

            # 你的预测结果路径结构：
            # batch_canny_results/图名/图名_boxes.txt
            pred_txt_path = os.path.join(pred_root_dir, base_name, f"{base_name}_boxes.txt")

            if not os.path.exists(pred_txt_path):
                print(f"[跳过] 缺少预测框文件: {pred_txt_path}")
                continue

            gt_boxes = parse_xml_boxes(xml_path)
            pred_boxes = parse_pred_boxes(pred_txt_path)

            tp, fp, fn, _ = match_boxes(gt_boxes, pred_boxes, iou_thresh=iou_thresh)
            precision, recall, f1 = compute_metrics(tp, fp, fn)

            writer.writerow([
                base_name,
                len(gt_boxes),
                len(pred_boxes),
                tp,
                fp,
                fn,
                round(precision, 6),
                round(recall, 6),
                round(f1, 6)
            ])

            total_tp += tp
            total_fp += fp
            total_fn += fn
            num_images_used += 1

            print(
                f"[完成] {base_name} | GT={len(gt_boxes)} Pred={len(pred_boxes)} "
                f"TP={tp} FP={fp} FN={fn} "
                f"P={precision:.4f} R={recall:.4f} F1={f1:.4f}"
            )

    overall_precision, overall_recall, overall_f1 = compute_metrics(total_tp, total_fp, total_fn)

    with open(summary_txt, "w", encoding="utf-8") as f:
        f.write(f"评估图片数量: {num_images_used}\n")
        f.write(f"IoU 阈值: {iou_thresh}\n")
        f.write(f"Total TP: {total_tp}\n")
        f.write(f"Total FP: {total_fp}\n")
        f.write(f"Total FN: {total_fn}\n")
        f.write(f"Precision: {overall_precision:.6f}\n")
        f.write(f"Recall: {overall_recall:.6f}\n")
        f.write(f"F1-score: {overall_f1:.6f}\n")

    print("\n========== 总体结果 ==========")
    print(f"评估图片数量: {num_images_used}")
    print(f"IoU 阈值: {iou_thresh}")
    print(f"Total TP: {total_tp}")
    print(f"Total FP: {total_fp}")
    print(f"Total FN: {total_fn}")
    print(f"Precision: {overall_precision:.6f}")
    print(f"Recall: {overall_recall:.6f}")
    print(f"F1-score: {overall_f1:.6f}")
    print(f"\n逐图结果: {per_image_csv}")
    print(f"汇总结果: {summary_txt}")


if __name__ == "__main__":
    # ======== 改成你的真实路径 ========
    gt_xml_dir = r"/home/sk/dl_cv_paramnet/data/val/xmls"
    pred_root_dir = r"/home/sk/dl_cv_paramnet/batch_canny_results"
    output_dir = r"/home/sk/dl_cv_paramnet/eval_results_canny"
    # =================================

    evaluate_dataset(
        gt_xml_dir=gt_xml_dir,
        pred_root_dir=pred_root_dir,
        output_dir=output_dir,
        iou_thresh=0.5
    )
