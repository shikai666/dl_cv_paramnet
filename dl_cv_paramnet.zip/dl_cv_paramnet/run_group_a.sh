#!/usr/bin/env bash
# A组实验一键运行脚本
# 用法：bash run_group_a.sh

set -e

python scripts/train_group_a.py \
  --mode both \
  --exp_name paper_a \
  --device cuda \
  --epochs 100 \
  --batch_size 32
