#!/usr/bin/env python
"""
DL-CV ParamNet 主入口脚本

使用方法:
    python run.py train --config configs/default.json
    python run.py evaluate --checkpoint checkpoints/best.pth
    python run.py inference --checkpoint checkpoints/best.pth --input image.png
    python run.py prepare --input data/raw --output data/processed
    python run.py test
"""

import sys
import os
import argparse

# 添加项目路径
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(PROJECT_ROOT, 'src')
SCRIPTS_DIR = os.path.join(PROJECT_ROOT, 'scripts')

# 确保路径在最前面
sys.path.insert(0, SRC_DIR)
sys.path.insert(0, SCRIPTS_DIR)
sys.path.insert(0, PROJECT_ROOT)


def main():
    parser = argparse.ArgumentParser(
        description='DL-CV ParamNet - 基于自监督对比学习的深度学习控制CV参数化架构',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
命令说明:
  train       训练模型
  evaluate    评估模型
  inference   推理（单图/批量）
  prepare     准备数据集
  ablation    运行消融实验
  visualize   可视化结果
  test        运行测试

示例:
  python run.py train --config configs/default.json --epochs 100
  python run.py train --synthetic --epochs 10  # 使用合成数据快速测试
  python run.py evaluate --checkpoint checkpoints/best.pth --synthetic
  python run.py inference --checkpoint checkpoints/best.pth --input image.png
  python run.py prepare synthetic --output data/processed --num_samples 1000
        """
    )
    
    parser.add_argument('command', choices=[
        'train', 'evaluate', 'inference', 'prepare', 'ablation', 'visualize', 'test'
    ], help='要执行的命令')
    
    # 解析第一个参数确定命令
    args, remaining = parser.parse_known_args()
    
    # 切换到项目根目录
    os.chdir(PROJECT_ROOT)
    
    if args.command == 'train':
        from scripts.train import main as train_main
        sys.argv = ['train.py'] + remaining
        train_main()
    
    elif args.command == 'evaluate':
        from scripts.evaluate import main as eval_main
        sys.argv = ['evaluate.py'] + remaining
        eval_main()
    
    elif args.command == 'inference':
        from scripts.inference import main as infer_main
        sys.argv = ['inference.py'] + remaining
        infer_main()
    
    elif args.command == 'prepare':
        from scripts.prepare_data import main as prepare_main
        sys.argv = ['prepare_data.py'] + remaining
        prepare_main()
    
    elif args.command == 'ablation':
        from scripts.ablation import main as ablation_main
        sys.argv = ['ablation.py'] + remaining
        ablation_main()
    
    elif args.command == 'visualize':
        from scripts.visualization import main as viz_main
        sys.argv = ['visualization.py'] + remaining
        viz_main()
    
    elif args.command == 'test':
        from scripts.test_all import run_all_tests
        sys.exit(run_all_tests())


if __name__ == '__main__':
    main()
