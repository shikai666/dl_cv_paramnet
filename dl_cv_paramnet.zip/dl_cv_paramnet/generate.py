import os
import glob
import cv2
import numpy as np


def find_green_boxes_from_overlay(
    image_path,
    min_area=10,
    min_width=2,
    min_height=2,
    max_width_ratio=0.95,
    debug=False
):
    img = cv2.imread(image_path)
    if img is None:
        print(f"[跳过] 无法读取图像: {image_path}")
        return []

    h, w = img.shape[:2]

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    lower_green = np.array([35, 40, 40], dtype=np.uint8)
    upper_green = np.array([90, 255, 255], dtype=np.uint8)

    mask = cv2.inRange(hsv, lower_green, upper_green)

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    candidate_boxes = []
    for cnt in contours:
        x, y, bw, bh = cv2.boundingRect(cnt)
        area = bw * bh

        if area < min_area:
            continue
        if bw < min_width or bh < min_height:
            continue
        if bw > int(w * max_width_ratio):
            continue

        candidate_boxes.append((x, y, bw, bh))

    candidate_boxes = remove_nested_and_duplicate_boxes(candidate_boxes)
    candidate_boxes = sorted(candidate_boxes, key=lambda b: (b[1], b[0]))

    if debug:
        print(f"[调试] {os.path.basename(image_path)} -> 提取到 {len(candidate_boxes)} 个框")

    return candidate_boxes


def remove_nested_and_duplicate_boxes(boxes, iou_thresh=0.9):
    if not boxes:
        return []

    def box_iou_xywh(a, b):
        ax1, ay1, aw, ah = a
        bx1, by1, bw, bh = b
        ax2, ay2 = ax1 + aw, ay1 + ah
        bx2, by2 = bx1 + bw, by1 + bh

        inter_x1 = max(ax1, bx1)
        inter_y1 = max(ay1, by1)
        inter_x2 = min(ax2, bx2)
        inter_y2 = min(ay2, by2)

        inter_w = max(0, inter_x2 - inter_x1)
        inter_h = max(0, inter_y2 - inter_y1)
        inter_area = inter_w * inter_h

        area_a = aw * ah
        area_b = bw * bh
        union = area_a + area_b - inter_area

        if union <= 0:
            return 0.0
        return inter_area / union

    def is_inside(a, b, margin=1):
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        return (
            ax >= bx - margin and
            ay >= by - margin and
            ax + aw <= bx + bw + margin and
            ay + ah <= by + bh + margin
        )

    boxes = sorted(boxes, key=lambda x: x[2] * x[3], reverse=True)

    keep = []
    for box in boxes:
        discard = False
        for kept in keep:
            if box_iou_xywh(box, kept) >= iou_thresh:
                discard = True
                break
            if is_inside(box, kept):
                discard = True
                break
        if not discard:
            keep.append(box)

    return keep


def save_boxes_txt(txt_path, boxes):
    with open(txt_path, "w", encoding="utf-8") as f:
        for i, (x, y, w, h) in enumerate(boxes, start=1):
            f.write(f"{i}: x={x}, y={y}, w={w}, h={h}\n")


def draw_boxes_preview(image_path, boxes, save_path):
    img = cv2.imread(image_path)
    if img is None:
        return

    vis = img.copy()
    for x, y, w, h in boxes:
        cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 0, 255), 1)

    cv2.imwrite(save_path, vis)


def batch_generate_txt(
    folder_path,
    overlay_suffix="_overlay",
    image_exts=("*.png", "*.bmp", "*.jpg", "*.jpeg"),
    debug=True,
    save_preview=True
):
    if not os.path.exists(folder_path):
        print(f"[错误] 文件夹不存在: {folder_path}")
        return

    overlay_images = []
    for ext in image_exts:
        overlay_images.extend(glob.glob(os.path.join(folder_path, ext)))

    overlay_images = [
        p for p in overlay_images
        if os.path.splitext(os.path.basename(p))[0].endswith(overlay_suffix)
    ]
    overlay_images = sorted(list(set(overlay_images)))

    if len(overlay_images) == 0:
        print(f"[提示] 没有找到 *{overlay_suffix} 的图片: {folder_path}")
        return

    print(f"[开始] 共找到 {len(overlay_images)} 张你的方法图")

    for image_path in overlay_images:
        filename = os.path.basename(image_path)
        name_no_ext = os.path.splitext(filename)[0]

        # 25_overlay -> 25
        base_name = name_no_ext[:-len(overlay_suffix)]
        if base_name.endswith("_"):
            base_name = base_name[:-1]

        boxes = find_green_boxes_from_overlay(
            image_path=image_path,
            min_area=10,
            min_width=2,
            min_height=2,
            max_width_ratio=0.95,
            debug=debug
        )

        # 改成你的方法专用命名
        txt_path = os.path.join(folder_path, f"{base_name}_overlay.txt")
        save_boxes_txt(txt_path, boxes)

        if save_preview:
            preview_path = os.path.join(folder_path, f"{base_name}_overlay_preview.png")
            draw_boxes_preview(image_path, boxes, preview_path)

        print(f"[完成] {filename} -> {os.path.basename(txt_path)} | 框数: {len(boxes)}")

    print("\n全部完成。")


if __name__ == "__main__":
    folder_path = r"/home/sk/dl_cv_paramnet/contrast"

    batch_generate_txt(
        folder_path=folder_path,
        overlay_suffix="_overlay",
        debug=True,
        save_preview=True
    )
